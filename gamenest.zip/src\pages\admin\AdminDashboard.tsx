import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Shield,
  Users,
  Coins,
  CreditCard,
  Gamepad2,
  Sliders,
  FileSpreadsheet,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Search,
  Eye,
  ArrowLeft,
  DollarSign,
  Activity,
  History,
  Lock,
} from 'lucide-react';
import { useAuthStore } from '../../stores/useAuthStore';
import { useGameStore } from '../../stores/useGameStore';
import { WithdrawalRequest, Game } from '../../types';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Input } from '../../components/ui/Input';
import { Modal } from '../../components/ui/Modal';

type AdminTab = 'overview' | 'withdrawals' | 'users' | 'games' | 'rewards' | 'audit';

export const AdminDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { user, withdrawals, allUsers, rewardConfig, updateWithdrawalStatus, updateRewardConfig, resetUserPoints } =
    useAuthStore();
  const { games, updateGameStatus } = useGameStore();

  const [activeTab, setActiveTab] = useState<AdminTab>('overview');

  // Strict Super Admin Email Verification
  const isAuthorizedSuperAdmin = user?.email?.toLowerCase() === 'bishawjitbadsha@gmail.com';

  // Withdrawal management state
  const [withdrawalFilter, setWithdrawalFilter] = useState<'all' | 'pending' | 'approved' | 'rejected' | 'paid'>('all');
  const [selectedWithdrawal, setSelectedWithdrawal] = useState<WithdrawalRequest | null>(null);
  const [rejectModalOpen, setRejectModalOpen] = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const [withdrawalSearch, setWithdrawalSearch] = useState('');

  // User search & reset points state
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const [userToReset, setUserToReset] = useState<any>(null);
  const [resetModalOpen, setResetModalOpen] = useState(false);

  // Audit log entries state
  const [auditLogs, setAuditLogs] = useState<
    { id: string; action: string; details: string; admin: string; timestamp: string }[]
  >([
    {
      id: 'log_1',
      action: 'SYSTEM_INIT',
      details: 'System initialized with RLS security policies',
      admin: 'admin@gamenest.test',
      timestamp: new Date(Date.now() - 86400000).toLocaleString(),
    },
    {
      id: 'log_2',
      action: 'REWARD_CONFIG_SET',
      details: 'Cash redemption feature flag initialized to false (safeguarded)',
      admin: 'admin@gamenest.test',
      timestamp: new Date(Date.now() - 43200000).toLocaleString(),
    },
  ]);

  const addAuditLog = (action: string, details: string) => {
    setAuditLogs((prev) => [
      {
        id: `log_${Date.now()}`,
        action,
        details,
        admin: user?.email || 'admin',
        timestamp: new Date().toLocaleString(),
      },
      ...prev,
    ]);
  };

  // Guard: Strictly allow ONLY bishawjitbadsha@gmail.com
  if (!user || !isAuthorizedSuperAdmin) {
    return (
      <div className="max-w-md mx-auto py-16 text-center space-y-4 animate-fade-in">
        <div className="w-16 h-16 rounded-full bg-rose-500/20 text-rose-400 mx-auto flex items-center justify-center border border-rose-500/40">
          <Lock className="w-8 h-8" />
        </div>
        <h1 className="text-2xl font-black text-white">Access Denied (403)</h1>
        <p className="text-xs text-slate-400 leading-relaxed">
          Administrator privileges are strictly restricted to <span className="font-mono text-purple-400">bishawjitbadsha@gmail.com</span>. Other users cannot view or access administrative operations.
        </p>
        <div className="flex justify-center gap-3 pt-2">
          <Button variant="danger" size="md" onClick={() => navigate('/admin/login')}>
            Admin Login
          </Button>
          <Button variant="secondary" size="md" onClick={() => navigate('/')}>
            Back to Home
          </Button>
        </div>
      </div>
    );
  }

  // Filtered withdrawals
  const filteredWithdrawals = withdrawals.filter((w) => {
    const matchesFilter = withdrawalFilter === 'all' || w.status === withdrawalFilter;
    const matchesSearch =
      w.id.toLowerCase().includes(withdrawalSearch.toLowerCase()) ||
      w.userId.toLowerCase().includes(withdrawalSearch.toLowerCase()) ||
      (w.upiId && w.upiId.toLowerCase().includes(withdrawalSearch.toLowerCase())) ||
      (w.mobileNumber && w.mobileNumber.includes(withdrawalSearch));
    return matchesFilter && matchesSearch;
  });

  // Filtered users
  const filteredUsers = allUsers.filter((u) => {
    return (
      u.displayName.toLowerCase().includes(userSearchQuery.toLowerCase()) ||
      u.email.toLowerCase().includes(userSearchQuery.toLowerCase()) ||
      u.id.toLowerCase().includes(userSearchQuery.toLowerCase())
    );
  });

  // Action handlers
  const handleApprove = (req: WithdrawalRequest) => {
    updateWithdrawalStatus(req.id, 'approved');
    addAuditLog('WITHDRAWAL_APPROVED', `Approved request ${req.id} (₹${(req.paiseAmount / 100).toFixed(0)}) for user ${req.userId}`);
  };

  const handleMarkPaid = (req: WithdrawalRequest) => {
    updateWithdrawalStatus(req.id, 'paid');
    addAuditLog('WITHDRAWAL_PAID', `Marked payment completed for request ${req.id} to UPI ${req.upiId}`);
  };

  const handleOpenReject = (req: WithdrawalRequest) => {
    setSelectedWithdrawal(req);
    setRejectReason('');
    setRejectModalOpen(true);
  };

  const handleConfirmReject = () => {
    if (!selectedWithdrawal || !rejectReason.trim()) return;
    updateWithdrawalStatus(selectedWithdrawal.id, 'rejected', rejectReason.trim());
    addAuditLog('WITHDRAWAL_REJECTED', `Rejected request ${selectedWithdrawal.id}. Refunded ${selectedWithdrawal.pointsAmount} pts. Reason: ${rejectReason.trim()}`);
    setRejectModalOpen(false);
    setSelectedWithdrawal(null);
  };

  // Toggle Reward Feature Flag
  const handleToggleCashRedemption = () => {
    const nextState = !rewardConfig.cashRedemptionEnabled;
    updateRewardConfig({ cashRedemptionEnabled: nextState });
    addAuditLog('FEATURE_FLAG_TOGGLE', `Cash redemption toggled to ${nextState ? 'ENABLED' : 'DISABLED'}`);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-rose-950/40 via-slate-900 to-slate-900 border border-rose-500/40 p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-rose-400 text-xs font-bold uppercase tracking-wider mb-1">
            <Shield className="w-4 h-4" />
            <span>Admin Operator Console</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white">System Administration</h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Operator: <strong className="text-white">{user.email}</strong> • Role: Super Admin
          </p>
        </div>

        <button
          onClick={() => navigate('/')}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 hover:text-white text-xs font-semibold self-start sm:self-center"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Exit to Player Portal</span>
        </button>
      </div>

      {/* Tabs Navigation */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-800 scrollbar-none no-select">
        {[
          { key: 'overview', label: 'Overview', icon: Activity },
          { key: 'withdrawals', label: `Withdrawals (${withdrawals.filter((w) => w.status === 'pending').length} pending)`, icon: CreditCard },
          { key: 'users', label: 'Users', icon: Users },
          { key: 'games', label: 'Games', icon: Gamepad2 },
          { key: 'rewards', label: 'Reward Config', icon: Sliders },
          { key: 'audit', label: 'Audit Logs', icon: History },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key as AdminTab)}
              className={`shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                activeTab === tab.key
                  ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
              <span className="text-[10px] text-slate-400 font-bold uppercase block">Total Users</span>
              <span className="text-2xl font-black text-white">{allUsers.length}</span>
            </div>
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
              <span className="text-[10px] text-slate-400 font-bold uppercase block">Games Played</span>
              <span className="text-2xl font-black text-purple-400">
                {allUsers.reduce((sum, u) => sum + u.gamesPlayed, 0)}
              </span>
            </div>
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
              <span className="text-[10px] text-slate-400 font-bold uppercase block">Points Issued</span>
              <span className="text-2xl font-black text-yellow-300">
                {allUsers.reduce((sum, u) => sum + u.totalEarnedPoints, 0).toLocaleString()}
              </span>
            </div>
            <div className="p-4 rounded-2xl bg-slate-900 border border-amber-500/30">
              <span className="text-[10px] text-amber-400 font-bold uppercase block">Pending Payouts</span>
              <span className="text-2xl font-black text-amber-400">
                {withdrawals.filter((w) => w.status === 'pending').length}
              </span>
            </div>
            <div className="p-4 rounded-2xl bg-slate-900 border border-emerald-500/30">
              <span className="text-[10px] text-emerald-400 font-bold uppercase block">Completed</span>
              <span className="text-2xl font-black text-emerald-400">
                {withdrawals.filter((w) => w.status === 'paid' || w.status === 'approved').length}
              </span>
            </div>
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
              <span className="text-[10px] text-slate-400 font-bold uppercase block">Cash Redemption</span>
              <span
                className={`text-sm font-black uppercase mt-1 block ${
                  rewardConfig.cashRedemptionEnabled ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {rewardConfig.cashRedemptionEnabled ? 'Enabled' : 'Paused'}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: WITHDRAWAL REQUESTS */}
      {activeTab === 'withdrawals' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={withdrawalSearch}
                onChange={(e) => setWithdrawalSearch(e.target.value)}
                placeholder="Search by Request ID, UPI ID, or Mobile..."
                className="w-full min-h-[42px] pl-10 pr-4 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
              />
            </div>

            <div className="flex items-center gap-2">
              <select
                value={withdrawalFilter}
                onChange={(e) => setWithdrawalFilter(e.target.value as any)}
                className="min-h-[42px] px-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200"
              >
                <option value="all">All Statuses</option>
                <option value="pending">Pending</option>
                <option value="approved">Approved</option>
                <option value="paid">Paid</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>
          </div>

          <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-x-auto shadow-xl">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider text-[10px] border-b border-slate-800">
                <tr>
                  <th className="p-3.5">ID & Date</th>
                  <th className="p-3.5">User</th>
                  <th className="p-3.5">UPI ID & Mobile</th>
                  <th className="p-3.5">Amount</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {filteredWithdrawals.map((req) => (
                  <tr key={req.id} className="hover:bg-slate-800/30">
                    <td className="p-3.5">
                      <span className="font-mono text-purple-400 font-bold block">{req.id}</span>
                      <span className="text-[10px] text-slate-500">{new Date(req.createdAt).toLocaleDateString()}</span>
                    </td>
                    <td className="p-3.5">
                      <span className="font-mono text-slate-300 block">{req.userId}</span>
                    </td>
                    <td className="p-3.5">
                      <span className="font-mono text-cyan-400 font-semibold block">{req.upiId || 'N/A'}</span>
                      <span className="text-[10px] text-slate-400 font-mono">{req.mobileNumber || 'N/A'}</span>
                    </td>
                    <td className="p-3.5">
                      <span className="font-black text-emerald-400 block">₹{(req.paiseAmount / 100).toFixed(0)}</span>
                      <span className="text-[10px] text-slate-400">{req.pointsAmount} pts</span>
                    </td>
                    <td className="p-3.5">
                      <span
                        className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full border ${
                          req.status === 'paid'
                            ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                            : req.status === 'approved'
                            ? 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30'
                            : req.status === 'rejected'
                            ? 'bg-rose-500/15 text-rose-400 border-rose-500/30'
                            : 'bg-amber-500/15 text-amber-400 border-amber-500/30'
                        }`}
                      >
                        {req.status}
                      </span>
                      {req.rejectReason && (
                        <span className="block text-[10px] text-rose-400 truncate max-w-[150px] mt-0.5">
                          {req.rejectReason}
                        </span>
                      )}
                    </td>
                    <td className="p-3.5 text-right space-x-1">
                      {req.status === 'pending' && (
                        <>
                          <button
                            onClick={() => handleApprove(req)}
                            className="px-2.5 py-1 rounded-lg bg-emerald-600/20 text-emerald-400 hover:bg-emerald-600 hover:text-white font-semibold transition-all"
                          >
                            Approve
                          </button>
                          <button
                            onClick={() => handleOpenReject(req)}
                            className="px-2.5 py-1 rounded-lg bg-rose-600/20 text-rose-400 hover:bg-rose-600 hover:text-white font-semibold transition-all"
                          >
                            Reject
                          </button>
                        </>
                      )}
                      {req.status === 'approved' && (
                        <button
                          onClick={() => handleMarkPaid(req)}
                          className="px-2.5 py-1 rounded-lg bg-cyan-600/20 text-cyan-400 hover:bg-cyan-600 hover:text-white font-semibold transition-all"
                        >
                          Confirm Paid (UPI)
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: USER MANAGEMENT */}
      {activeTab === 'users' && (
        <div className="space-y-4">
          <div className="max-w-md">
            <input
              type="text"
              value={userSearchQuery}
              onChange={(e) => setUserSearchQuery(e.target.value)}
              placeholder="Search by User ID, Name, or Email..."
              className="w-full min-h-[42px] px-4 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
            />
          </div>

          <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-x-auto shadow-xl">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider text-[10px] border-b border-slate-800">
                <tr>
                  <th className="p-3.5">User</th>
                  <th className="p-3.5">IP Address</th>
                  <th className="p-3.5">Playtime (Admin Only)</th>
                  <th className="p-3.5">Points</th>
                  <th className="p-3.5">Games Won</th>
                  <th className="p-3.5">Joined</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {filteredUsers.map((u) => {
                  const hours = ((u.playtimeSeconds || 0) / 3600).toFixed(1);
                  const isEligibleTime = (u.playtimeSeconds || 0) >= 48 * 3600;
                  return (
                    <tr key={u.id} className="hover:bg-slate-800/30">
                      <td className="p-3.5 flex items-center gap-2.5">
                        <img src={u.avatarUrl} alt="" className="w-7 h-7 rounded-full object-cover" />
                        <div>
                          <span className="font-bold text-white block">{u.displayName}</span>
                          <span className="text-[10px] text-slate-500 font-mono">{u.email}</span>
                        </div>
                      </td>
                      <td className="p-3.5">
                        <span className="font-mono text-cyan-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800 text-[11px]">
                          {u.ipAddress || '103.21.244.18'}
                        </span>
                      </td>
                      <td className="p-3.5">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-200">{hours} hrs</span>
                          <span
                            className={`text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded ${
                              isEligibleTime
                                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            {isEligibleTime ? '≥ 48h Met' : '< 48h'}
                          </span>
                        </div>
                      </td>
                      <td className="p-3.5">
                        <span className="font-black text-yellow-300">{u.pointsBalance.toLocaleString()} pts</span>
                      </td>
                      <td className="p-3.5 text-emerald-400 font-bold">{u.gamesWon} / {u.gamesPlayed}</td>
                      <td className="p-3.5 text-slate-500 text-[11px]">
                        {new Date(u.createdAt).toLocaleDateString()}
                      </td>
                      <td className="p-3.5 text-right">
                        {u.pointsBalance > 0 ? (
                          <button
                            onClick={() => {
                              setUserToReset(u);
                              setResetModalOpen(true);
                            }}
                            className="px-2.5 py-1 rounded-lg bg-rose-600/20 hover:bg-rose-600 text-rose-300 hover:text-white font-semibold transition-all text-xs"
                          >
                            Reset Points to 0
                          </button>
                        ) : (
                          <span className="text-slate-500 text-[11px]">0 Balance</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: GAME MANAGEMENT */}
      {activeTab === 'games' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {games.map((game) => (
              <div key={game.id} className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-white">{game.title}</h3>
                  <Badge variant={game.status === 'available' ? 'available' : 'coming_soon'}>
                    {game.status}
                  </Badge>
                </div>
                <p className="text-xs text-slate-400 line-clamp-2">{game.description}</p>
                <div className="pt-2 border-t border-slate-800 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">Status:</span>
                    <select
                      value={game.status}
                      onChange={(e) => {
                        updateGameStatus(game.id, { status: e.target.value as any });
                        addAuditLog('GAME_STATUS_UPDATE', `Changed ${game.title} status to ${e.target.value}`);
                      }}
                      className="px-2 py-1 rounded-lg bg-slate-950 border border-slate-800 text-xs text-white"
                    >
                      <option value="available">Available</option>
                      <option value="coming_soon">Coming Soon</option>
                      <option value="maintenance">Maintenance</option>
                    </select>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">Points Reward:</span>
                    <button
                      onClick={() => {
                        const next = !game.rewardsEnabled;
                        updateGameStatus(game.id, { rewardsEnabled: next });
                        addAuditLog('GAME_REWARDS_TOGGLE', `${game.title} rewards set to ${next}`);
                      }}
                      className={`px-2 py-0.5 rounded-lg text-[10px] font-bold ${
                        game.rewardsEnabled ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {game.rewardsEnabled ? 'Enabled (+50 pts)' : 'Disabled'}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: REWARD CONFIGURATION (FEATURE FLAG) */}
      {activeTab === 'rewards' && (
        <div className="max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6 shadow-xl">
          <div>
            <h2 className="text-lg font-bold text-white">Reward Safeguards & Rules Configuration</h2>
            <p className="text-xs text-slate-400 mt-1">
              Configure points economics and server-side feature flags.
            </p>
          </div>

          {/* Cash Redemption Feature Flag */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-4">
            <div className="space-y-1">
              <span className="text-sm font-bold text-white block">Cash Redemption Feature Flag</span>
              <p className="text-xs text-slate-400 max-w-sm">
                When disabled, players cannot submit withdrawal requests. Keep disabled until legal compliance is finalized.
              </p>
            </div>
            <button
              onClick={handleToggleCashRedemption}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                rewardConfig.cashRedemptionEnabled
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
                  : 'bg-rose-600 text-white shadow-lg shadow-rose-600/30'
              }`}
            >
              {rewardConfig.cashRedemptionEnabled ? 'Enabled' : 'Disabled (Safe)'}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-xs text-slate-400 block">Reward Threshold</span>
              <span className="text-lg font-bold text-white">₹{(rewardConfig.rewardPaise / 100).toFixed(0)}</span>
              <span className="text-[10px] text-slate-500 block mt-0.5">10,000 Paise</span>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-xs text-slate-400 block">Required Points</span>
              <span className="text-lg font-bold text-purple-300">
                {rewardConfig.requiredPoints.toLocaleString()} pts
              </span>
              <span className="text-[10px] text-slate-500 block mt-0.5">Fixed 100 pts = ₹1</span>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-xs text-slate-400 block">Daily Point Limit</span>
              <span className="text-lg font-bold text-white">{rewardConfig.dailyMaxPoints} pts / day</span>
              <span className="text-[10px] text-slate-500 block mt-0.5">Anti-abuse cap</span>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-xs text-slate-400 block">Min Active Session</span>
              <span className="text-lg font-bold text-white">{rewardConfig.minSessionSeconds} seconds</span>
              <span className="text-[10px] text-slate-500 block mt-0.5">Foreground heartbeat</span>
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: AUDIT LOGS */}
      {activeTab === 'audit' && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl">
          <div className="p-4 border-b border-slate-800 flex items-center justify-between">
            <h2 className="text-sm font-bold text-white">Operator Audit Trail</h2>
            <span className="text-xs text-slate-400">{auditLogs.length} Records</span>
          </div>
          <div className="divide-y divide-slate-800">
            {auditLogs.map((log) => (
              <div key={log.id} className="p-3.5 text-xs hover:bg-slate-800/30">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-purple-400 font-bold">{log.action}</span>
                  <span className="text-[10px] text-slate-500">{log.timestamp}</span>
                </div>
                <p className="text-slate-300 mt-1">{log.details}</p>
                <span className="text-[10px] text-slate-500 block mt-0.5">Admin: {log.admin}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Rejection Modal */}
      <Modal
        isOpen={rejectModalOpen}
        onClose={() => setRejectModalOpen(false)}
        title="Reject Withdrawal Request"
      >
        <div className="space-y-4 text-xs text-slate-300">
          <p>
            Please provide a valid reason for rejecting request{' '}
            <strong className="text-white">{selectedWithdrawal?.id}</strong>.
            The user's points will be refunded automatically to their balance with a ledger record.
          </p>

          <Input
            label="Rejection Reason (Required)"
            value={rejectReason}
            onChange={(e) => setRejectReason(e.target.value)}
            placeholder="e.g. Invalid UPI handle, duplicate submission, or unverified session"
            required
          />

          <div className="flex justify-end gap-3 pt-2">
            <Button variant="ghost" size="md" onClick={() => setRejectModalOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="danger"
              size="md"
              disabled={!rejectReason.trim()}
              onClick={handleConfirmReject}
            >
              Confirm Rejection & Refund Points
            </Button>
          </div>
        </div>
      </Modal>
      {/* Reset Points Confirmation Modal */}
      <Modal
        isOpen={resetModalOpen}
        onClose={() => setResetModalOpen(false)}
        title="Reset User Reward Points to 0"
      >
        <div className="space-y-4 text-xs text-slate-300">
          <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300">
            <p className="font-bold">⚠️ Warning: Irreversible Action</p>
            <p className="mt-1">
              Are you sure you want to reset all <strong>{userToReset?.pointsBalance?.toLocaleString()} points</strong> for player{' '}
              <strong>{userToReset?.displayName}</strong> ({userToReset?.email}) back to <strong>0</strong>?
            </p>
          </div>
          <p className="text-slate-400">
            This action will be logged in the permanent audit trail with your admin email signature.
          </p>

          <div className="flex justify-end gap-3 pt-2">
            <Button variant="ghost" size="md" onClick={() => setResetModalOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="danger"
              size="md"
              onClick={() => {
                if (userToReset) {
                  resetUserPoints(userToReset.id);
                  addAuditLog('POINTS_RESET_ZERO', `Admin reset points to 0 for ${userToReset.email} (Previous balance: ${userToReset.pointsBalance} pts)`);
                  setResetModalOpen(false);
                  setUserToReset(null);
                }
              }}
            >
              Confirm Reset to 0
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
