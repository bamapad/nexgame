import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Sparkles, Users, Flame, Gamepad2, ArrowRight, Download, FolderArchive, Globe } from 'lucide-react';
import { useGameStore } from '../stores/useGameStore';
import { GameCategory } from '../types';
import { GameCard } from '../components/common/GameCard';
import { PointsSummary } from '../components/common/PointsSummary';
import { AdBanner } from '../components/common/AdBanner';
import { Button } from '../components/ui/Button';

export const Home: React.FC = () => {
  const navigate = useNavigate();
  const { games, selectedCategory, setSelectedCategory, searchQuery, setSearchQuery } = useGameStore();

  const categories: { key: GameCategory; label: string; icon: string }[] = [
    { key: 'all', label: 'All Games', icon: '🎮' },
    { key: 'puzzle', label: 'Puzzles', icon: '🧩' },
    { key: 'classic', label: 'Classic', icon: '⚡' },
    { key: 'multiplayer', label: 'Multiplayer', icon: '👥' },
    { key: 'arcade', label: 'Arcade', icon: '🕹️' },
  ];

  // Filter games based on search and selected category
  const filteredGames = games.filter((g) => {
    const matchesCategory = selectedCategory === 'all' || g.category === selectedCategory;
    const matchesSearch =
      g.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      g.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const popularGames = games.filter((g) => g.popular && g.status === 'available');
  const comingSoonGames = games.filter((g) => g.status === 'coming_soon');

  return (
    <div className="space-y-6 sm:space-y-8 animate-fade-in">
      {/* Points Summary Card */}
      <PointsSummary />

      {/* Hero Featured Game Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 border border-purple-500/40 p-6 sm:p-8 shadow-2xl">
        <div className="relative z-10 max-w-xl space-y-3 sm:space-y-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 border border-purple-400/30 text-xs font-bold tracking-wide">
            <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
            <span>FEATURED HIGHLIGHT</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight leading-tight">
            Combo Block Puzzle & Tic Tac Toe Online
          </h1>

          <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
            Instant casual gameplay optimized for Android, tablet, and desktop. Earn verified points, invite friends with room codes, or play against our unbeatable Extreme Robot.
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <Button
              size="lg"
              variant="electric"
              onClick={() => navigate('/block-puzzle')}
              leftIcon={<Gamepad2 className="w-5 h-5" />}
              className="font-bold"
            >
              Play Block Puzzle
            </Button>
            <Button
              size="lg"
              variant="secondary"
              onClick={() => navigate('/tic-tac-toe')}
              leftIcon={<Users className="w-5 h-5 text-cyan-400" />}
            >
              Tic Tac Toe (1P / 2P)
            </Button>
          </div>
        </div>

        {/* Ambient decorative lighting */}
        <div className="absolute right-0 top-0 bottom-0 w-1/2 bg-gradient-to-l from-cyan-500/10 via-purple-500/10 to-transparent pointer-events-none hidden sm:block" />
      </div>

      {/* 1-Click Project Download Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-900 border border-emerald-500/30 p-4 sm:p-5 flex flex-col md:flex-row items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 flex-shrink-0">
            <Download className="w-5 h-5 animate-bounce" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm sm:text-base font-bold text-white">Download GameNest Project ZIP</h2>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-bold uppercase">
                Ready to Deploy
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              1-click download directly to your computer. Ready for GitHub upload or instant drag & drop onto Netlify.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          <a
            href="/gamenest.zip"
            download="gamenest.zip"
            className="flex-1 md:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-lg shadow-purple-600/30 transition-all active:scale-95"
          >
            <FolderArchive className="w-4 h-4" />
            <span>GitHub ZIP (All-in-One)</span>
          </a>
          <a
            href="/gamenest-netlify-direct.zip"
            download="gamenest-netlify-direct.zip"
            className="flex-1 md:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/30 transition-all active:scale-95"
          >
            <Globe className="w-4 h-4" />
            <span>Netlify Direct ZIP</span>
          </a>
        </div>
      </div>

      {/* Search and Category Filters */}
      <div className="space-y-3">
        {/* Search bar */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search games, puzzles, or multiplayer..."
            className="w-full min-h-[48px] rounded-2xl bg-slate-900 border border-slate-800 focus:border-purple-500 pl-11 pr-4 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-purple-500/30 transition-all"
          />
        </div>

        {/* Category Pills (Horizontal scroll on mobile) */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none no-select">
          {categories.map((cat) => (
            <button
              key={cat.key}
              onClick={() => setSelectedCategory(cat.key)}
              className={`shrink-0 flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all min-h-[40px] ${
                selectedCategory === cat.key
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              <span>{cat.icon}</span>
              <span>{cat.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Popular Games Section */}
      <section className="space-y-3 sm:space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Flame className="w-5 h-5 text-orange-400" />
            <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">Popular Games</h2>
          </div>
          <button
            onClick={() => navigate('/games')}
            className="flex items-center gap-1 text-xs sm:text-sm text-purple-400 hover:text-purple-300 font-semibold transition-colors"
          >
            <span>View All</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Responsive Grid: 2 per row on wide mobile, 1 on narrow, 3-4 on desktop */}
        <div className="grid grid-cols-1 xs:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-3.5 sm:gap-5">
          {popularGames.map((game) => (
            <GameCard key={game.id} game={game} />
          ))}
        </div>
      </section>

      {/* Google AdSense Display Unit */}
      <AdBanner />

      {/* Play With Friends Section (Phase 5 Showcase) */}
      <section className="rounded-2xl bg-gradient-to-r from-blue-950/40 via-slate-900 to-slate-900 border border-blue-500/30 p-5 sm:p-6 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-cyan-400 uppercase tracking-wider">
              <Users className="w-4 h-4" />
              <span>Real-Time Multiplayer</span>
            </div>
            <h3 className="text-lg sm:text-xl font-extrabold text-white">Play Tic Tac Toe With Friends</h3>
            <p className="text-xs sm:text-sm text-slate-400 max-w-lg">
              Generate a unique 6-character room code, share with your buddy on WhatsApp or browser, and challenge each other in live real-time matches!
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <Button
              size="md"
              variant="electric"
              onClick={() => navigate('/tic-tac-toe')}
              leftIcon={<Users className="w-4 h-4" />}
            >
              Start Room
            </Button>
          </div>
        </div>
      </section>

      {/* Coming Soon Section (Phase 6: Fruit Crash Preview) */}
      <section className="space-y-3 sm:space-y-4">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-purple-400" />
          <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">Coming Soon to GameNest</h2>
        </div>

        <div className="grid grid-cols-1 xs:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-3.5 sm:gap-5">
          {comingSoonGames.map((game) => (
            <GameCard key={game.id} game={game} />
          ))}
        </div>
      </section>
    </div>
  );
};
