import { describe, it, expect } from 'vitest';
import { isSupabaseConfigured } from '../lib/supabase';

describe('Supabase Backend Configuration & Verification', () => {
  it('verifies that Supabase environment variables are properly formatted', () => {
    const url = import.meta.env.VITE_SUPABASE_URL;
    const key = import.meta.env.VITE_SUPABASE_ANON_KEY;

    expect(url).toBeDefined();
    expect(key).toBeDefined();
    expect(url).toMatch(/^https:\/\/[a-z0-9]+\.supabase\.co/);
    expect(key).toMatch(/^[a-zA-Z0-9_\-]+$/);
  });

  it('verifies isSupabaseConfigured flag evaluates to true', () => {
    expect(isSupabaseConfigured).toBe(true);
  });
});
