import React, { useState } from 'react';
import { ShieldCheck, AlertCircle, Sparkles } from 'lucide-react';
import { signInWithGoogle } from '../../lib/supabaseAuth';
import { isSupabaseConfigured } from '../../lib/supabase';
import { useAuthStore } from '../../stores/useAuthStore';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const { login } = useAuthStore();
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleGoogleSignIn = async () => {
    setError(null);
    setLoading(true);

    try {
      if (isSupabaseConfigured) {
        // Initiates standard Google OAuth via Supabase
        await signInWithGoogle();
      } else {
        // Fallback for offline local dev mode
        login('player@gmail.com', 'Google Player');
        setLoading(false);
        onClose();
      }
    } catch (err: any) {
      setError(err.message || 'Google sign-in could not be completed.');
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Sign in with Google"
      description="Join GameNest to accumulate verified casual gameplay points."
    >
      <div className="space-y-5 py-2">
        {error && (
          <div className="p-3.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        {/* Highlight Banner */}
        <div className="p-3.5 rounded-2xl bg-gradient-to-r from-purple-950/40 via-indigo-950/40 to-slate-900 border border-purple-500/30 flex items-start gap-3">
          <div className="w-8 h-8 rounded-xl bg-purple-600/20 text-purple-400 flex items-center justify-center shrink-0 mt-0.5">
            <Sparkles className="w-4 h-4 text-yellow-300" />
          </div>
          <div className="text-xs text-slate-300 space-y-1">
            <p className="font-bold text-white">Fair Play & Fast Sign-In</p>
            <p className="text-slate-400 leading-relaxed">
              New accounts start with <strong>0 points</strong> and earn points gradually through verified active gameplay.
            </p>
          </div>
        </div>

        {/* Official Google Sign-In Button (Adhering to Google Identity Branding Policy) */}
        <button
          type="button"
          onClick={handleGoogleSignIn}
          disabled={loading}
          className="w-full min-h-[50px] px-4 py-3 rounded-2xl bg-white hover:bg-slate-100 text-slate-800 font-semibold text-sm sm:text-base flex items-center justify-center gap-3 shadow-lg shadow-black/20 hover:shadow-black/30 transition-all active:scale-[0.98] border border-slate-300"
        >
          {loading ? (
            <div className="flex items-center gap-2 text-slate-600 text-sm">
              <svg className="animate-spin h-5 w-5 text-slate-600" viewBox="0 0 24 24" fill="none">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
              </svg>
              <span>Connecting to Google...</span>
            </div>
          ) : (
            <>
              {/* Google 4-Color SVG Logo */}
              <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
                />
                <path
                  fill="#34A853"
                  d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.36 24 12 24z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.98 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                />
                <path
                  fill="#EA4335"
                  d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.36 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                />
              </svg>
              <span>Continue with Google</span>
            </>
          )}
        </button>

        {/* Google API & Privacy Policy Notice */}
        <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400 space-y-1">
          <p className="flex items-center gap-1.5 text-slate-300 font-semibold">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Google API User Data Policy Compliance</span>
          </p>
          <p className="leading-relaxed">
            GameNest strictly follows Google's API Services User Data Policy. We only access your basic profile (display name & email address) for user authentication. Zero private contacts or extra permissions are requested.
          </p>
        </div>
      </div>
    </Modal>
  );
};
