import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Gamepad2, Coins, User as UserIcon, Shield, Sparkles } from 'lucide-react';
import { useAuthStore } from '../../stores/useAuthStore';
import { AuthModal } from '../common/AuthModal';

export const Header: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [isAuthOpen, setIsAuthOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-[#0b0f19]/90 backdrop-blur-md px-3 sm:px-6 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2">
        {/* Brand Logo */}
        <Link
          to="/"
          className="flex items-center gap-2 group transition-transform active:scale-95"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-500 p-0.5 shadow-md shadow-purple-600/30 group-hover:shadow-cyan-500/30 transition-all flex items-center justify-center">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <Gamepad2 className="w-5 h-5 text-cyan-400 group-hover:text-purple-400 transition-colors" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1">
              <span className="font-extrabold text-lg sm:text-xl tracking-tight bg-gradient-to-r from-white via-slate-100 to-purple-300 bg-clip-text text-transparent">
                GameNest
              </span>
              <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            </div>
            <span className="text-[10px] text-slate-400 block -mt-1 tracking-wider uppercase font-semibold">
              Casual Arcade
            </span>
          </div>
        </Link>

        {/* Center Nav for Desktop */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-300">
          <Link to="/" className="hover:text-purple-400 transition-colors">
            Home
          </Link>
          <Link to="/games" className="hover:text-purple-400 transition-colors">
            All Games
          </Link>
          <Link to="/wallet" className="hover:text-purple-400 transition-colors">
            Points Wallet
          </Link>
          <Link to="/redeem" className="hover:text-purple-400 transition-colors">
            Redeem ₹100
          </Link>
          {user?.isAdmin && user.email?.toLowerCase() === 'bishawjitbadsha@gmail.com' && (
            <Link
              to="/admin"
              className="flex items-center gap-1 text-rose-400 hover:text-rose-300 transition-colors font-semibold px-2 py-1 rounded-lg bg-rose-500/10 border border-rose-500/20"
            >
              <Shield className="w-3.5 h-3.5" />
              Admin
            </Link>
          )}
        </nav>

        {/* Right side: Points Balance & User Profile */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Points Pill (Clickable -> opens Wallet) */}
          <button
            onClick={() => navigate('/wallet')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-purple-950/60 border border-purple-500/40 hover:border-purple-400 text-purple-200 transition-all active:scale-95 group shadow-sm shadow-purple-900/50"
            title="View Points Wallet"
          >
            <div className="w-5 h-5 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 flex items-center justify-center text-slate-950 shadow-inner">
              <Coins className="w-3.5 h-3.5" />
            </div>
            <span className="font-bold text-xs sm:text-sm text-yellow-300 group-hover:text-yellow-200">
              {user ? user.pointsBalance.toLocaleString() : '0'}
            </span>
            <span className="text-[10px] text-purple-300 font-medium hidden xs:inline">pts</span>
          </button>

          {/* Profile Button */}
          {user ? (
            <Link
              to="/profile"
              className="flex items-center gap-2 p-1 pl-1.5 pr-2 rounded-full bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/80 transition-all text-xs font-medium text-slate-200"
            >
              <img
                src={user.avatarUrl}
                alt={user.displayName}
                className="w-7 h-7 rounded-full object-cover ring-1 ring-purple-500/50"
              />
              <span className="hidden sm:inline font-semibold max-w-[90px] truncate">
                {user.displayName}
              </span>
            </Link>
          ) : (
            <button
              onClick={() => setIsAuthOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold shadow-md shadow-purple-600/30 transition-all active:scale-95"
            >
              <UserIcon className="w-3.5 h-3.5" />
              <span>Sign In</span>
            </button>
          )}
        </div>
      </div>

      {/* Supabase Authentication Modal */}
      <AuthModal isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} />
    </header>
  );
};
