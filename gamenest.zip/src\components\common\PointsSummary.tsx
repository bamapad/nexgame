import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Coins, Trophy, ArrowRight, ShieldAlert } from 'lucide-react';
import { useAuthStore } from '../../stores/useAuthStore';
import { Button } from '../ui/Button';

export const PointsSummary: React.FC = () => {
  const navigate = useNavigate();
  const { user, rewardConfig } = useAuthStore();

  const currentPoints = user ? user.pointsBalance : 0;
  const targetPoints = rewardConfig.requiredPoints; // 10,000
  const progressPercent = Math.min(100, Math.round((currentPoints / targetPoints) * 100));

  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-purple-950/40 to-slate-900 border border-purple-500/30 p-4 sm:p-5 shadow-xl">
      {/* Background ambient glow */}
      <div className="absolute -right-8 -top-8 w-36 h-36 bg-purple-600/20 rounded-full blur-2xl pointer-events-none" />
      <div className="absolute -left-8 -bottom-8 w-36 h-36 bg-cyan-600/20 rounded-full blur-2xl pointer-events-none" />

      <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Left Column: Points stats */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-yellow-500/20 text-yellow-400 border border-yellow-500/40 flex items-center justify-center">
              <Coins className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs uppercase tracking-wider font-bold text-purple-300">
                Reward Points Balance
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                  {currentPoints.toLocaleString()}
                </span>
                <span className="text-xs font-semibold text-slate-400">/ {targetPoints.toLocaleString()} pts</span>
              </div>
            </div>
          </div>

          {/* Progress bar towards ₹100 reward */}
          <div className="w-full max-w-md space-y-1">
            <div className="flex items-center justify-between text-[11px] text-slate-400 font-medium">
              <span>Goal: ₹{(rewardConfig.rewardPaise / 100).toFixed(0)} Reward</span>
              <span className="text-purple-300 font-bold">{progressPercent}% Achieved</span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-purple-500 to-cyan-400 rounded-full transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Right Column: CTA button and status */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
          {!rewardConfig.cashRedemptionEnabled ? (
            <div className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900/90 border border-amber-500/30 text-amber-300 text-xs font-medium">
              <ShieldAlert className="w-4 h-4 shrink-0 text-amber-400" />
              <span>Redemption locked (Compliance verification in progress)</span>
            </div>
          ) : null}

          <Button
            size="md"
            variant="electric"
            onClick={() => navigate('/redeem')}
            rightIcon={<ArrowRight className="w-4 h-4" />}
            className="shrink-0 font-bold"
          >
            Redeem Rewards
          </Button>

          <Button
            size="md"
            variant="secondary"
            onClick={() => navigate('/wallet')}
            leftIcon={<Trophy className="w-4 h-4 text-yellow-400" />}
            className="shrink-0"
          >
            Ledger
          </Button>
        </div>
      </div>
    </div>
  );
};
