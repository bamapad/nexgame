import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  RotateCcw,
  Pause,
  Play,
  Trophy,
  Sparkles,
  Flame,
  Volume2,
  VolumeX,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import {
  Grid,
  BlockShape,
  createEmptyGrid,
  canPlacePiece,
  placePiece,
  checkAndClearLines,
  hasValidMovesRemaining,
  getRandomShapeBatch,
} from '../game-logic/block-puzzle';
import { useAuthStore } from '../stores/useAuthStore';
import { sounds } from '../lib/soundEffects';
import { Button } from '../components/ui/Button';
import { Modal } from '../components/ui/Modal';

export const BlockPuzzle: React.FC = () => {
  const navigate = useNavigate();
  const { awardPoints, addPlaytime } = useAuthStore();

  const [grid, setGrid] = useState<Grid>(createEmptyGrid());
  const [availablePieces, setAvailablePieces] = useState<BlockShape[]>([]);
  const [selectedPieceIndex, setSelectedPieceIndex] = useState<number | null>(null);
  const [hoverCell, setHoverCell] = useState<{ r: number; c: number } | null>(null);
  const [score, setScore] = useState(0);
  const [bestScore, setBestScore] = useState(() => {
    return parseInt(localStorage.getItem('gamenest_bp_best_score') || '0', 10);
  });
  const [combo, setCombo] = useState(0);
  const [lastComboNotice, setLastComboNotice] = useState<string | null>(null);
  const [isGameOver, setIsGameOver] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [isMuted, setIsMuted] = useState(sounds.getIsMuted());

  // Track active playtime while playing
  useEffect(() => {
    const interval = setInterval(() => {
      if (document.visibilityState === 'visible' && !isGameOver && !isPaused) {
        addPlaytime(5);
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [isGameOver, isPaused, addPlaytime]);

  // Start fresh game
  const handleStartGame = useCallback(() => {
    const newGrid = createEmptyGrid();
    setGrid(newGrid);
    setScore(0);
    setCombo(0);
    setLastComboNotice(null);
    setIsGameOver(false);
    setIsPaused(false);
    const batch = getRandomShapeBatch();
    setAvailablePieces(batch);
    setSelectedPieceIndex(null);
    setHoverCell(null);
  }, []);

  useEffect(() => {
    handleStartGame();
  }, [handleStartGame]);

  // Save best score to localStorage
  useEffect(() => {
    if (score > bestScore) {
      setBestScore(score);
      localStorage.setItem('gamenest_bp_best_score', score.toString());
    }
  }, [score, bestScore]);

  // Sound toggle
  const toggleMute = () => {
    const next = !isMuted;
    sounds.setMuted(next);
    setIsMuted(next);
  };

  // Haptic feedback
  const triggerHaptic = () => {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      navigator.vibrate(15);
    }
  };

  // Selected piece preview helper
  const selectedPiece = useMemo(() => {
    return selectedPieceIndex !== null ? availablePieces[selectedPieceIndex] : null;
  }, [selectedPieceIndex, availablePieces]);

  // Ghost placement cells calculation
  const ghostCells = useMemo(() => {
    if (!selectedPiece || !hoverCell) return null;
    const isValid = canPlacePiece(grid, selectedPiece, hoverCell.r, hoverCell.c);
    const cells: { r: number; c: number }[] = [];

    const numRows = selectedPiece.matrix.length;
    const numCols = selectedPiece.matrix[0].length;

    for (let r = 0; r < numRows; r++) {
      for (let c = 0; c < numCols; c++) {
        if (selectedPiece.matrix[r][c] === 1) {
          cells.push({ r: hoverCell.r + r, c: hoverCell.c + c });
        }
      }
    }
    return { cells, isValid };
  }, [selectedPiece, hoverCell, grid]);

  // Cell placement handler
  const handleCellClick = (r: number, c: number) => {
    if (selectedPieceIndex === null || isGameOver || isPaused) return;

    const piece = availablePieces[selectedPieceIndex];
    if (!piece) return;

    if (canPlacePiece(grid, piece, r, c)) {
      triggerHaptic();
      sounds.playPlaceTile();

      // 1. Place piece
      const updatedGrid = placePiece(grid, piece, r, c);

      // 2. Clear completed rows & columns
      const clearResult = checkAndClearLines(updatedGrid, combo);

      let pointsGained = piece.matrix.flat().filter((x) => x === 1).length * 10;
      let newCombo = combo;

      if (clearResult.linesCleared > 0) {
        newCombo = combo + clearResult.linesCleared;
        pointsGained += clearResult.pointsEarned;
        setCombo(newCombo);
        setLastComboNotice(`+${clearResult.pointsEarned} pts! ${newCombo}x COMBO!`);

        // Play Combo Fanfare sound
        if (newCombo > 1 || clearResult.linesCleared > 1) {
          sounds.playComboBlast(newCombo);
        } else {
          sounds.playLineClear();
        }

        // Lightweight celebration particles
        try {
          confetti({
            particleCount: 20 * clearResult.linesCleared,
            spread: 45,
            origin: { y: 0.6 },
          });
        } catch (e) {}

        // Award platform points
        awardPoints(3 * clearResult.linesCleared, `Cleared ${clearResult.linesCleared} lines in Block Puzzle`);
      } else {
        setCombo(0);
        setLastComboNotice(null);
      }

      setScore((prev) => prev + pointsGained);
      setGrid(clearResult.newGrid);
      setHoverCell(null);

      // 3. Remove placed piece from available pieces
      const remainingPieces = availablePieces.filter((_, idx) => idx !== selectedPieceIndex);
      setSelectedPieceIndex(null);

      // 4. If all 3 pieces are used, draw 3 new pieces
      if (remainingPieces.length === 0) {
        const nextBatch = getRandomShapeBatch();
        setAvailablePieces(nextBatch);
        if (!hasValidMovesRemaining(clearResult.newGrid, nextBatch)) {
          setIsGameOver(true);
        }
      } else {
        setAvailablePieces(remainingPieces);
        if (!hasValidMovesRemaining(clearResult.newGrid, remainingPieces)) {
          setIsGameOver(true);
        }
      }
    }
  };

  return (
    <div className="max-w-xl mx-auto space-y-4 animate-fade-in no-select">
      {/* Top Header Controls */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => navigate('/games')}
          className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Games</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={toggleMute}
            className={`p-2 rounded-xl border transition-colors ${
              isMuted
                ? 'bg-rose-950/40 border-rose-500/40 text-rose-300'
                : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white'
            }`}
            title={isMuted ? 'Unmute Sound' : 'Mute Sound'}
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
          <button
            onClick={() => setIsPaused(true)}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
            title="Pause Game"
          >
            <Pause className="w-4 h-4" />
          </button>
          <button
            onClick={handleStartGame}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
            title="Restart Game"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Score and Combo Status Banner */}
      <div className="grid grid-cols-3 gap-2 rounded-2xl bg-gradient-to-r from-slate-900 via-purple-950/40 to-slate-900 border border-slate-800 p-3 sm:p-4 text-center">
        <div>
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">SCORE</span>
          <span className="text-xl sm:text-2xl font-black text-white">{score}</span>
        </div>

        <div>
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">BEST</span>
          <span className="text-xl sm:text-2xl font-black text-amber-400 flex items-center justify-center gap-1">
            <Trophy className="w-4 h-4" />
            {bestScore}
          </span>
        </div>

        <div>
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">COMBO</span>
          <span className="text-xl sm:text-2xl font-black text-cyan-400 flex items-center justify-center gap-1">
            <Flame className={`w-4 h-4 ${combo > 0 ? 'text-orange-400 fill-orange-400 animate-bounce' : ''}`} />
            {combo}x
          </span>
        </div>
      </div>

      {/* Floating Combo Toast */}
      {lastComboNotice && (
        <div className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-black text-xs sm:text-sm text-center py-2 px-4 rounded-full shadow-lg shadow-purple-600/40 animate-combo-pop border border-purple-400/30">
          💥 {lastComboNotice}
        </div>
      )}

      {/* 8x8 Playable Board */}
      <div className="relative w-full max-w-[360px] sm:max-w-[400px] mx-auto aspect-square p-2.5 sm:p-3 rounded-3xl bg-slate-900 border-2 border-slate-800 shadow-2xl">
        <div className="grid grid-cols-8 grid-rows-8 gap-1 sm:gap-1.5 w-full h-full">
          {grid.map((row, r) =>
            row.map((cellColor, c) => {
              const isGhost = ghostCells?.cells.some((gc) => gc.r === r && gc.c === c);
              const isGhostValid = ghostCells?.isValid;

              return (
                <button
                  key={`${r}-${c}`}
                  onClick={() => handleCellClick(r, c)}
                  onMouseEnter={() => setHoverCell({ r, c })}
                  onMouseLeave={() => setHoverCell(null)}
                  className={`w-full h-full rounded-[6px] transition-transform duration-75 flex items-center justify-center ${
                    cellColor
                      ? 'shadow-md border border-white/20 scale-[0.98]'
                      : isGhost
                      ? isGhostValid
                        ? 'bg-emerald-500/40 border-2 border-emerald-400 scale-95 animate-pulse'
                        : 'bg-rose-500/30 border-2 border-rose-400 scale-95'
                      : 'bg-slate-950/80 hover:bg-slate-800/60 border border-slate-800/40'
                  }`}
                  style={{
                    backgroundColor: cellColor || undefined,
                    boxShadow: cellColor ? `0 0 8px ${cellColor}40` : undefined,
                  }}
                />
              );
            })
          )}
        </div>
      </div>

      {/* Instruction hint for mobile gamers */}
      <p className="text-center text-[11px] text-slate-400 font-medium">
        {selectedPieceIndex === null
          ? '👇 Tap a block below to select, then tap on the grid to blast rows & columns!'
          : '✨ Tap on the grid to position your piece!'}
      </p>

      {/* Available Shape Batch (3 Pieces) */}
      <div className="grid grid-cols-3 gap-2 p-3 bg-slate-900/60 rounded-2xl border border-slate-800">
        {availablePieces.map((piece, idx) => {
          const isSelected = selectedPieceIndex === idx;
          return (
            <button
              key={piece.id}
              onClick={() => {
                const nextIdx = isSelected ? null : idx;
                setSelectedPieceIndex(nextIdx);
                sounds.playPlaceTile();
              }}
              className={`flex items-center justify-center p-2 rounded-xl min-h-[85px] transition-all cursor-pointer ${
                isSelected
                  ? 'bg-purple-600/30 border-2 border-purple-400 shadow-lg shadow-purple-500/20 scale-105'
                  : 'bg-slate-950/80 hover:bg-slate-800/60 border border-slate-800 hover:border-slate-700'
              }`}
            >
              {/* Mini Matrix Preview */}
              <div
                className="grid gap-1"
                style={{
                  gridTemplateColumns: `repeat(${piece.matrix[0].length}, minmax(0, 1fr))`,
                }}
              >
                {piece.matrix.map((row, rIdx) =>
                  row.map((val, cIdx) => (
                    <div
                      key={`${rIdx}-${cIdx}`}
                      className={`w-4 h-4 sm:w-5 sm:h-5 rounded-[4px] ${
                        val === 1 ? 'shadow-sm' : 'opacity-0'
                      }`}
                      style={{
                        backgroundColor: val === 1 ? piece.color : 'transparent',
                      }}
                    />
                  ))
                )}
              </div>
            </button>
          );
        })}
      </div>

      {/* Pause Modal */}
      <Modal isOpen={isPaused} onClose={() => setIsPaused(false)} title="Game Paused">
        <div className="space-y-4 text-center">
          <p className="text-sm text-slate-400">Take a breath! Current Score: {score}.</p>
          <div className="flex items-center justify-center gap-3">
            <Button
              variant="electric"
              size="md"
              onClick={() => setIsPaused(false)}
              leftIcon={<Play className="w-4 h-4" />}
            >
              Resume
            </Button>
            <Button
              variant="secondary"
              size="md"
              onClick={handleStartGame}
              leftIcon={<RotateCcw className="w-4 h-4" />}
            >
              Restart
            </Button>
          </div>
        </div>
      </Modal>

      {/* Game Over Modal */}
      <Modal isOpen={isGameOver} onClose={handleStartGame} title="No Moves Remaining!">
        <div className="space-y-4 text-center">
          <div className="w-14 h-14 rounded-full bg-rose-500/20 text-rose-400 mx-auto flex items-center justify-center text-2xl border border-rose-500/40">
            🧩
          </div>
          <div>
            <h3 className="text-2xl font-black text-white">Game Over</h3>
            <p className="text-sm text-slate-400 mt-1">
              Final Score: <strong className="text-white">{score}</strong>
            </p>
            {score >= bestScore && score > 0 && (
              <p className="text-xs text-amber-400 font-bold mt-1 flex items-center justify-center gap-1">
                <Sparkles className="w-3.5 h-3.5" /> New High Score!
              </p>
            )}
          </div>

          <div className="flex items-center justify-center gap-3 pt-2">
            <Button
              variant="primary"
              size="md"
              onClick={handleStartGame}
              leftIcon={<RotateCcw className="w-4 h-4" />}
            >
              Play Again
            </Button>
            <Button variant="secondary" size="md" onClick={() => navigate('/games')}>
              All Games
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
