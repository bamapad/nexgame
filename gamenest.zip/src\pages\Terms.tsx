import React from 'react';
import { FileText, AlertCircle, ShieldAlert } from 'lucide-react';

export const Terms: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-fade-in text-slate-300">
      {/* Header */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-purple-950/40 to-slate-900 border border-slate-800 p-5 sm:p-6">
        <div className="flex items-center gap-2 text-purple-400 text-xs font-bold uppercase tracking-wider mb-1">
          <FileText className="w-4 h-4" />
          <span>User Agreement</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-white">Terms and Conditions</h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Please review the terms governing use of the GameNest platform and casual games.
        </p>
      </div>

      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-6 text-sm leading-relaxed">
        <section className="space-y-2">
          <h2 className="text-base font-bold text-white">1. Casual Entertainment Only</h2>
          <p>
            GameNest is designed exclusively for casual gaming enjoyment. No purchase, wager, or financial deposit is ever required to play our games.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-400" />
            2. Fair Play & Anti-Cheat Policy
          </h2>
          <p>
            Players must interact with games naturally. The following actions are strictly prohibited and result in permanent ban and forfeiture of points:
          </p>
          <ul className="list-disc list-inside space-y-1 text-xs text-slate-400 pl-2">
            <li>Using automated scripts, bots, macro recorders, or browser extension manipulation.</li>
            <li>Tampering with client-side code, cookies, or HTTP requests to inflate points.</li>
            <li>Opening games in background tabs or headless browsers to farm session time.</li>
            <li>Creating multiple fake accounts to exploit starter bonuses.</li>
          </ul>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-purple-400" />
            3. Points & Reward Disclaimers
          </h2>
          <p>
            Points earned within GameNest are promotional tokens with zero cash value outside the platform. Reward redemption is a discretionary promotional benefit provided subject to legal review and verification. Points are never guaranteed wages, investments, or securities.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-bold text-white">4. Modifications to Service</h2>
          <p className="text-xs text-slate-400">
            GameNest reserves the right to adjust reward thresholds, update game mechanics, or terminate abusive accounts at any time to preserve the integrity of our community.
          </p>
        </section>
      </div>
    </div>
  );
};
