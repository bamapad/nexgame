export type GameStatus = 'available' | 'coming_soon' | 'maintenance';
export type GameCategory = 'all' | 'puzzle' | 'multiplayer' | 'classic' | 'arcade';

export interface Game {
  id: string;
  slug: string;
  title: string;
  description: string;
  category: GameCategory;
  status: GameStatus;
  thumbnail: string;
  banner?: string;
  playersCount: string;
  rating: number;
  featured?: boolean;
  popular?: boolean;
  rewardsEnabled: boolean;
  minPlaySecondsForReward: number;
  pointsReward: number;
}

export interface UserProfile {
  id: string;
  displayName: string;
  email: string;
  avatarUrl: string;
  pointsBalance: number;
  totalEarnedPoints: number;
  totalSpentPoints: number;
  isAdmin: boolean;
  gamesPlayed: number;
  gamesWon: number;
  createdAt: string;
  ipAddress?: string;
  playtimeSeconds?: number;
}

export type TransactionType = 'game_reward' | 'withdrawal' | 'refund' | 'bonus';

export interface PointsTransaction {
  id: string;
  userId: string;
  amount: number; // positive for earned, negative for spent
  type: TransactionType;
  description: string;
  balanceAfter: number;
  createdAt: string;
}

export type WithdrawalStatus = 'pending' | 'approved' | 'rejected' | 'paid';

export interface WithdrawalRequest {
  id: string;
  userId: string;
  pointsAmount: number; // e.g. 10000
  paiseAmount: number;  // 10000 paise = ₹100
  status: WithdrawalStatus;
  mobileNumber?: string;
  upiId?: string;
  rejectReason?: string;
  createdAt: string;
  reviewedAt?: string;
}

export interface RewardConfig {
  cashRedemptionEnabled: boolean;
  rewardPaise: number;         // 10000 = ₹100
  requiredPoints: number;      // 10000 points
  pointsPerGameSession: number; // e.g. 50 points
  minSessionSeconds: number;   // 60 seconds
  dailyMaxPoints: number;      // 500 points per day
}
