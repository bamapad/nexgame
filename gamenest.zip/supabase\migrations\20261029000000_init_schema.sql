-- ============================================================================
-- GAMENEST PRODUCTION DATABASE SCHEMA & ROW LEVEL SECURITY (RLS)
-- Phase 2 Backend Migration (Idempotent: Safe to run multiple times)
-- ============================================================================

-- 1. Enable pgcrypto for UUIDs & cryptographic functions
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================================
-- 2. TABLES DEFINITIONS
-- ============================================================================

-- PROFILES: Linked 1:1 to Supabase auth.users
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    display_name TEXT NOT NULL DEFAULT 'Player',
    email TEXT NOT NULL,
    avatar_url TEXT DEFAULT '',
    points_balance BIGINT NOT NULL DEFAULT 0 CHECK (points_balance >= 0),
    total_earned_points BIGINT NOT NULL DEFAULT 0 CHECK (total_earned_points >= 0),
    total_spent_points BIGINT NOT NULL DEFAULT 0 CHECK (total_spent_points >= 0),
    is_admin BOOLEAN NOT NULL DEFAULT FALSE,
    games_played INT NOT NULL DEFAULT 0 CHECK (games_played >= 0),
    games_won INT NOT NULL DEFAULT 0 CHECK (games_won >= 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- GAMES CATALOG
CREATE TABLE IF NOT EXISTS public.games (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    slug TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    category TEXT NOT NULL CHECK (category IN ('puzzle', 'classic', 'multiplayer', 'arcade')),
    status TEXT NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'coming_soon', 'maintenance')),
    thumbnail TEXT NOT NULL,
    players_count TEXT NOT NULL DEFAULT '1-2 Players',
    rating NUMERIC(2,1) NOT NULL DEFAULT 5.0,
    is_visible BOOLEAN NOT NULL DEFAULT TRUE,
    rewards_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    points_reward INT NOT NULL DEFAULT 50 CHECK (points_reward >= 0),
    min_play_seconds INT NOT NULL DEFAULT 45 CHECK (min_play_seconds >= 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- GAME SESSIONS (Foreground activity heartbeats & anti-botting)
CREATE TABLE IF NOT EXISTS public.game_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    game_id UUID NOT NULL REFERENCES public.games(id) ON DELETE CASCADE,
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'completed', 'abandoned')),
    score INT NOT NULL DEFAULT 0 CHECK (score >= 0),
    duration_seconds INT NOT NULL DEFAULT 0 CHECK (duration_seconds >= 0),
    points_awarded INT NOT NULL DEFAULT 0 CHECK (points_awarded >= 0),
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_heartbeat TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    ended_at TIMESTAMPTZ
);

-- MULTIPLAYER ROOMS (2-Player Tic Tac Toe)
CREATE TABLE IF NOT EXISTS public.multiplayer_rooms (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    room_code VARCHAR(6) UNIQUE NOT NULL,
    game_id UUID NOT NULL REFERENCES public.games(id),
    host_id UUID NOT NULL REFERENCES public.profiles(id),
    guest_id UUID REFERENCES public.profiles(id),
    current_turn CHAR(1) NOT NULL DEFAULT 'X' CHECK (current_turn IN ('X', 'O')),
    board_state JSONB NOT NULL DEFAULT '[null,null,null,null,null,null,null,null,null]'::jsonb,
    status TEXT NOT NULL DEFAULT 'waiting' CHECK (status IN ('waiting', 'in_progress', 'completed', 'abandoned')),
    winner CHAR(1) CHECK (winner IN ('X', 'O', 'D')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '15 minutes')
);

-- GAME MOVES (Sequential move validation for multiplayer)
CREATE TABLE IF NOT EXISTS public.game_moves (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    room_id UUID NOT NULL REFERENCES public.multiplayer_rooms(id) ON DELETE CASCADE,
    player_id UUID NOT NULL REFERENCES public.profiles(id),
    move_number INT NOT NULL CHECK (move_number >= 0),
    symbol CHAR(1) NOT NULL CHECK (symbol IN ('X', 'O')),
    cell_index INT NOT NULL CHECK (cell_index >= 0 AND cell_index <= 8),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- POINTS LEDGER (Immutable audit record)
CREATE TABLE IF NOT EXISTS public.points_ledger (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    amount BIGINT NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('game_reward', 'bonus', 'withdrawal', 'refund', 'admin_adjustment')),
    description TEXT NOT NULL,
    reference_id UUID,
    balance_after BIGINT NOT NULL CHECK (balance_after >= 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- REWARD CONFIGURATION (Controlled by Admin)
CREATE TABLE IF NOT EXISTS public.reward_config (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    cash_redemption_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    reward_paise BIGINT NOT NULL DEFAULT 10000 CHECK (reward_paise > 0),
    required_points BIGINT NOT NULL DEFAULT 10000 CHECK (required_points > 0),
    points_per_game_session INT NOT NULL DEFAULT 50,
    min_session_seconds INT NOT NULL DEFAULT 60,
    daily_max_points INT NOT NULL DEFAULT 500,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_by UUID REFERENCES public.profiles(id)
);

-- WITHDRAWAL REQUESTS
CREATE TABLE IF NOT EXISTS public.withdrawal_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    points_amount BIGINT NOT NULL CHECK (points_amount > 0),
    paise_amount BIGINT NOT NULL CHECK (paise_amount > 0),
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'paid')),
    reject_reason TEXT,
    reviewed_by UUID REFERENCES public.profiles(id),
    reviewed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- WITHDRAWAL PRIVATE DETAILS (Protected from ordinary users)
CREATE TABLE IF NOT EXISTS public.withdrawal_details (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    withdrawal_id UUID UNIQUE NOT NULL REFERENCES public.withdrawal_requests(id) ON DELETE CASCADE,
    mobile_number TEXT NOT NULL,
    upi_id TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ADMIN AUDIT LOGS
CREATE TABLE IF NOT EXISTS public.admin_audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    admin_id UUID NOT NULL REFERENCES public.profiles(id),
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id UUID,
    old_value JSONB,
    new_value JSONB,
    details TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================================
-- 3. INDEXES FOR PERFORMANCE
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_game_sessions_user ON public.game_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_multiplayer_rooms_code ON public.multiplayer_rooms(room_code);
CREATE INDEX IF NOT EXISTS idx_game_moves_room ON public.game_moves(room_id, move_number);
CREATE INDEX IF NOT EXISTS idx_points_ledger_user ON public.points_ledger(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_withdrawal_requests_user ON public.withdrawal_requests(user_id, status);

-- ============================================================================
-- 4. ROW LEVEL SECURITY (RLS) POLICIES
-- ============================================================================

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.games ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.game_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.multiplayer_rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.game_moves ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.points_ledger ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reward_config ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.withdrawal_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.withdrawal_details ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_audit_logs ENABLE ROW LEVEL SECURITY;

-- Helper function: Is user an admin?
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = auth.uid() AND is_admin = TRUE
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop existing policies if re-running to prevent duplicates
DROP POLICY IF EXISTS "Users can read own profile or admin can read all" ON public.profiles;
DROP POLICY IF EXISTS "Users can update own profile display info" ON public.profiles;
DROP POLICY IF EXISTS "Anyone can view visible games" ON public.games;
DROP POLICY IF EXISTS "Admins can manage games" ON public.games;
DROP POLICY IF EXISTS "Users can view own sessions" ON public.game_sessions;
DROP POLICY IF EXISTS "Users can start own session" ON public.game_sessions;
DROP POLICY IF EXISTS "Users can view room if participating or room is waiting" ON public.multiplayer_rooms;
DROP POLICY IF EXISTS "Authenticated users can create rooms" ON public.multiplayer_rooms;
DROP POLICY IF EXISTS "Participants can update room" ON public.multiplayer_rooms;
DROP POLICY IF EXISTS "Users can view own points ledger" ON public.points_ledger;
DROP POLICY IF EXISTS "Anyone authenticated can view reward config" ON public.reward_config;
DROP POLICY IF EXISTS "Admins can update reward config" ON public.reward_config;
DROP POLICY IF EXISTS "Users can view own withdrawal requests" ON public.withdrawal_requests;
DROP POLICY IF EXISTS "Users can submit withdrawal requests" ON public.withdrawal_requests;
DROP POLICY IF EXISTS "Only admins can view private withdrawal details" ON public.withdrawal_details;
DROP POLICY IF EXISTS "Users can insert withdrawal details for own request" ON public.withdrawal_details;
DROP POLICY IF EXISTS "Only admins can view audit logs" ON public.admin_audit_logs;

-- PROFILES POLICIES
CREATE POLICY "Users can read own profile or admin can read all"
    ON public.profiles FOR SELECT
    USING (auth.uid() = id OR public.is_admin());

CREATE POLICY "Users can update own profile display info"
    ON public.profiles FOR UPDATE
    USING (auth.uid() = id)
    WITH CHECK (auth.uid() = id);

-- GAMES POLICIES
CREATE POLICY "Anyone can view visible games"
    ON public.games FOR SELECT
    USING (is_visible = TRUE OR public.is_admin());

CREATE POLICY "Admins can manage games"
    ON public.games FOR ALL
    USING (public.is_admin());

-- GAME SESSIONS POLICIES
CREATE POLICY "Users can view own sessions"
    ON public.game_sessions FOR SELECT
    USING (auth.uid() = user_id OR public.is_admin());

CREATE POLICY "Users can start own session"
    ON public.game_sessions FOR INSERT
    WITH CHECK (auth.uid() = user_id);

-- MULTIPLAYER ROOMS POLICIES
CREATE POLICY "Users can view room if participating or room is waiting"
    ON public.multiplayer_rooms FOR SELECT
    USING (auth.uid() = host_id OR auth.uid() = guest_id OR status = 'waiting');

CREATE POLICY "Authenticated users can create rooms"
    ON public.multiplayer_rooms FOR INSERT
    WITH CHECK (auth.uid() = host_id);

CREATE POLICY "Participants can update room"
    ON public.multiplayer_rooms FOR UPDATE
    USING (auth.uid() = host_id OR auth.uid() = guest_id);

-- POINTS LEDGER POLICIES
CREATE POLICY "Users can view own points ledger"
    ON public.points_ledger FOR SELECT
    USING (auth.uid() = user_id OR public.is_admin());

-- REWARD CONFIG POLICIES
CREATE POLICY "Anyone authenticated can view reward config"
    ON public.reward_config FOR SELECT
    TO authenticated
    USING (TRUE);

CREATE POLICY "Admins can update reward config"
    ON public.reward_config FOR ALL
    USING (public.is_admin());

-- WITHDRAWAL REQUESTS POLICIES
CREATE POLICY "Users can view own withdrawal requests"
    ON public.withdrawal_requests FOR SELECT
    USING (auth.uid() = user_id OR public.is_admin());

CREATE POLICY "Users can submit withdrawal requests"
    ON public.withdrawal_requests FOR INSERT
    WITH CHECK (auth.uid() = user_id);

-- WITHDRAWAL DETAILS POLICIES (STRICT: Admins ONLY)
CREATE POLICY "Only admins can view private withdrawal details"
    ON public.withdrawal_details FOR SELECT
    USING (public.is_admin());

CREATE POLICY "Users can insert withdrawal details for own request"
    ON public.withdrawal_details FOR INSERT
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM public.withdrawal_requests
            WHERE id = withdrawal_id AND user_id = auth.uid()
        )
    );

-- ADMIN AUDIT LOGS POLICIES
CREATE POLICY "Only admins can view audit logs"
    ON public.admin_audit_logs FOR SELECT
    USING (public.is_admin());

-- ============================================================================
-- 5. AUTOMATIC PROFILE CREATION TRIGGER (SUPABASE AUTH)
-- ============================================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (id, display_name, email, avatar_url, points_balance, total_earned_points)
    VALUES (
        NEW.id,
        COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1)),
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'avatar_url', 'https://api.dicebear.com/7.x/bottts/svg?seed=' || NEW.id),
        200, -- 200 starter bonus points
        200
    )
    ON CONFLICT (id) DO NOTHING;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop trigger if already exists and recreate
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============================================================================
-- 6. SEED INITIAL GAMES & REWARD CONFIG
-- ============================================================================
INSERT INTO public.games (slug, title, description, category, status, thumbnail, players_count, rating, rewards_enabled, points_reward)
VALUES
    ('tic-tac-toe', 'Tic Tac Toe Pro', 'Play against smart AI or invite a friend with a 6-character room code.', 'classic', 'available', 'tic-tac-toe', '1-2 Players', 4.8, TRUE, 50),
    ('block-puzzle', 'Combo Block Puzzle', 'Place colorful polyomino shapes, blast full rows & columns, and trigger combo score explosions!', 'puzzle', 'available', 'block-puzzle', 'Single Player', 4.9, TRUE, 75),
    ('fruit-crash', 'Fruit Crash', 'Match juicy fruits, clear explosive cascades, and unlock high-scoring tropical smoothie combos.', 'arcade', 'coming_soon', 'fruit-crash', 'Single Player', 5.0, FALSE, 60)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO public.reward_config (cash_redemption_enabled, reward_paise, required_points, points_per_game_session, min_session_seconds, daily_max_points)
VALUES (FALSE, 10000, 10000, 50, 60, 500)
ON CONFLICT DO NOTHING;
