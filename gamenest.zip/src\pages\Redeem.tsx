import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Coins,
  ShieldCheck,
  AlertTriangle,
  Clock,
  CheckCircle,
  XCircle,
  ArrowRight,
  Info,
  Phone,
  CreditCard,
  Lock,
} from 'lucide-react';
import { useAuthStore } from '../stores/useAuthStore';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Modal } from '../components/ui/Modal';

export const Redeem: React.FC = () => {
  const navigate = useNavigate();
  const { user, withdrawals, rewardConfig, submitWithdrawal } = useAuthStore();

  const [mobileNumber, setMobileNumber] = useState('');
  const [upiId, setUpiId] = useState('');
  const [isConfirmOpen, setIsConfirmOpen] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [validationErrors, setValidationErrors] = useState<{ mobile?: string; upi?: string }>({});

  const currentPoints = user ? user.pointsBalance : 0;
  const targetPoints = rewardConfig.requiredPoints;
  const rupeeAmount = (rewardConfig.rewardPaise / 100).toFixed(0);
  const isEligible = currentPoints >= targetPoints;

  // Filter withdrawals for current user
  const userWithdrawals = withdrawals.filter((w) => w.userId === user?.id);

  // Form input validation
  const validateForm = () => {
    const errors: { mobile?: string; upi?: string } = {};

    const cleanMobile = mobileNumber.trim();
    if (!/^[6-9]\d{9}$/.test(cleanMobile)) {
      errors.mobile = 'Enter a valid 10-digit Indian mobile number (e.g. 9876543210)';
    }

    const cleanUpi = upiId.trim();
    if (!/^[\w.-]+@[\w.-]+$/.test(cleanUpi)) {
      errors.upi = 'Enter a valid UPI ID (e.g. yourname@okhdfcbank or user@paytm)';
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleOpenConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage(null);
    if (!rewardConfig.cashRedemptionEnabled) {
      setStatusMessage({
        type: 'error',
        text: 'Cash redemption is currently locked pending regulatory compliance verification.',
      });
      return;
    }
    if (!isEligible) {
      setStatusMessage({
        type: 'error',
        text: `You need at least ${targetPoints.toLocaleString()} points to redeem ₹${rupeeAmount}.`,
      });
      return;
    }
    if (validateForm()) {
      setIsConfirmOpen(true);
    }
  };

  const handleConfirmSubmit = () => {
    const res = submitWithdrawal(mobileNumber.trim(), upiId.trim());
    setIsConfirmOpen(false);
    if (res.success) {
      setStatusMessage({ type: 'success', text: res.message });
      setMobileNumber('');
      setUpiId('');
    } else {
      setStatusMessage({ type: 'error', text: res.message });
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-fade-in">
      {/* Header */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-purple-950/40 to-slate-900 border border-slate-800 p-5 sm:p-6">
        <div className="flex items-center gap-2 text-purple-400 text-xs font-bold uppercase tracking-wider mb-1">
          <CreditCard className="w-4 h-4" />
          <span>Reward Redemptions</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-white">Redeem ₹{rupeeAmount} Reward</h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Accumulate points through fair gameplay and request verified payout to your UPI ID.
        </p>
      </div>

      {/* Compliance / Status Alert Banner */}
      {!rewardConfig.cashRedemptionEnabled ? (
        <div className="rounded-2xl bg-amber-500/10 border border-amber-500/30 p-4 sm:p-5 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="space-y-1 text-xs sm:text-sm">
            <h3 className="font-bold text-amber-300">Cash Redemption Paused (Compliance Safeguard)</h3>
            <p className="text-slate-300 leading-relaxed">
              As mandated by our platform policies, cash payouts remain disabled behind a server-side feature flag until legal checks and advertising partner integrations are certified. Points earned remain safe in your wallet!
            </p>
          </div>
        </div>
      ) : null}

      {/* Eligibility Card */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Your Points Card */}
        <div className="rounded-2xl bg-slate-900 p-4 sm:p-5 border border-slate-800 space-y-2">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Your Balance</span>
          <div className="text-3xl font-black text-white flex items-baseline gap-1">
            <span>{currentPoints.toLocaleString()}</span>
            <span className="text-xs font-semibold text-purple-400">pts</span>
          </div>
          <p className="text-xs text-slate-400">
            {isEligible
              ? '✅ You have reached the points requirement!'
              : `Need ${(targetPoints - currentPoints).toLocaleString()} more points to redeem.`}
          </p>
        </div>

        {/* Required Points Card */}
        <div className="rounded-2xl bg-slate-900 p-4 sm:p-5 border border-purple-500/30 space-y-2">
          <span className="text-xs font-bold text-purple-300 uppercase tracking-wider">Required For ₹{rupeeAmount}</span>
          <div className="text-3xl font-black text-purple-300 flex items-baseline gap-1">
            <span>{targetPoints.toLocaleString()}</span>
            <span className="text-xs font-semibold text-purple-400">pts</span>
          </div>
          <p className="text-xs text-slate-400">Fixed rate: 100 points = ₹1 (10,000 points = ₹100)</p>
        </div>
      </div>

      {/* Status Messages */}
      {statusMessage && (
        <div
          className={`p-4 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 ${
            statusMessage.type === 'success'
              ? 'bg-emerald-500/15 border border-emerald-500/30 text-emerald-300'
              : 'bg-rose-500/15 border border-rose-500/30 text-rose-300'
          }`}
        >
          {statusMessage.type === 'success' ? (
            <CheckCircle className="w-5 h-5 shrink-0 text-emerald-400" />
          ) : (
            <AlertTriangle className="w-5 h-5 shrink-0 text-rose-400" />
          )}
          <span>{statusMessage.text}</span>
        </div>
      )}

      {/* Redemption Form */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 sm:p-6 shadow-xl space-y-5">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Lock className="w-4 h-4 text-purple-400" />
            <span>Withdrawal Request Form</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Your UPI details are encrypted and accessed solely by administrators to process verified rewards.
          </p>
        </div>

        <form onSubmit={handleOpenConfirm} className="space-y-4">
          <Input
            label="Mobile Number"
            type="tel"
            maxLength={10}
            value={mobileNumber}
            onChange={(e) => setMobileNumber(e.target.value.replace(/\D/g, ''))}
            placeholder="10-digit mobile number (e.g. 9876543210)"
            leftIcon={<Phone className="w-4 h-4" />}
            error={validationErrors.mobile}
            helperText="Used for SMS payment confirmation."
          />

          <Input
            label="UPI ID (VPA)"
            type="text"
            value={upiId}
            onChange={(e) => setUpiId(e.target.value)}
            placeholder="e.g. username@okhdfcbank or 9876543210@paytm"
            leftIcon={<CreditCard className="w-4 h-4" />}
            error={validationErrors.upi}
            helperText="Direct recipient address for instant UPI bank transfer."
          />

          <div className="pt-2">
            <Button
              type="submit"
              size="lg"
              variant={rewardConfig.cashRedemptionEnabled && isEligible ? 'electric' : 'secondary'}
              disabled={!rewardConfig.cashRedemptionEnabled || !isEligible}
              fullWidth
              rightIcon={<ArrowRight className="w-4 h-4" />}
              className="font-bold"
            >
              {!rewardConfig.cashRedemptionEnabled
                ? 'Redemption Disabled by Admin'
                : !isEligible
                ? `Need ${targetPoints.toLocaleString()} Points to Redeem`
                : `Submit ₹${rupeeAmount} Withdrawal Request`}
            </Button>
          </div>
        </form>
      </div>

      {/* Confirmation Modal */}
      <Modal
        isOpen={isConfirmOpen}
        onClose={() => setIsConfirmOpen(false)}
        title="Confirm ₹100 Withdrawal Request"
      >
        <div className="space-y-4 text-sm text-slate-300">
          <p>Please double-check your withdrawal details before confirming:</p>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-400">Points Deducted:</span>
              <strong className="text-white">{targetPoints.toLocaleString()} pts</strong>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Rupee Payout:</span>
              <strong className="text-emerald-400">₹{rupeeAmount}</strong>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">UPI ID:</span>
              <strong className="text-cyan-400 font-mono">{upiId}</strong>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Mobile Number:</span>
              <strong className="text-white font-mono">{mobileNumber}</strong>
            </div>
          </div>

          <p className="text-xs text-slate-400">
            Points will be deducted atomically from your balance. If rejected, points will be automatically refunded with an audit log record.
          </p>

          <div className="flex items-center justify-end gap-3 pt-2">
            <Button variant="ghost" size="md" onClick={() => setIsConfirmOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" size="md" onClick={handleConfirmSubmit}>
              Confirm & Submit
            </Button>
          </div>
        </div>
      </Modal>

      {/* User's Withdrawal History */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl">
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Clock className="w-4 h-4 text-purple-400" />
            <span>Your Withdrawal History</span>
          </h2>
          <span className="text-xs text-slate-400">{userWithdrawals.length} Requests</span>
        </div>

        {userWithdrawals.length > 0 ? (
          <div className="divide-y divide-slate-800/80">
            {userWithdrawals.map((req) => (
              <div
                key={req.id}
                className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-800/20"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs text-purple-400 font-bold">{req.id}</span>
                    <span
                      className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full border ${
                        req.status === 'approved' || req.status === 'paid'
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                          : req.status === 'rejected'
                          ? 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                          : 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                      }`}
                    >
                      {req.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">
                    Submitted on {new Date(req.createdAt).toLocaleDateString()} to UPI: {req.upiId}
                  </p>
                  {req.rejectReason && (
                    <p className="text-xs text-rose-400 mt-1">Reason: {req.rejectReason}</p>
                  )}
                </div>

                <div className="text-left sm:text-right">
                  <span className="text-base font-black text-white">
                    ₹{(req.paiseAmount / 100).toFixed(0)}
                  </span>
                  <span className="block text-xs text-slate-400">{req.pointsAmount} pts</span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-10 text-center text-slate-400 text-xs">
            No withdrawal requests submitted yet.
          </div>
        )}
      </div>
    </div>
  );
};
