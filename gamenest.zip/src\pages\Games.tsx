import React, { useState } from 'react';
import { Search, Gamepad2, Sparkles, Filter } from 'lucide-react';
import { useGameStore } from '../stores/useGameStore';
import { GameCategory } from '../types';
import { GameCard } from '../components/common/GameCard';

export const Games: React.FC = () => {
  const { games, selectedCategory, setSelectedCategory, searchQuery, setSearchQuery } = useGameStore();
  const [statusFilter, setStatusFilter] = useState<'all' | 'available' | 'coming_soon'>('all');

  const categories: { key: GameCategory; label: string; icon: string }[] = [
    { key: 'all', label: 'All', icon: '🎮' },
    { key: 'puzzle', label: 'Puzzle', icon: '🧩' },
    { key: 'classic', label: 'Classic', icon: '⚡' },
    { key: 'multiplayer', label: 'Multiplayer', icon: '👥' },
    { key: 'arcade', label: 'Arcade', icon: '🕹️' },
  ];

  const filteredGames = games.filter((game) => {
    const matchesCat = selectedCategory === 'all' || game.category === selectedCategory;
    const matchesSearch =
      game.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      game.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus =
      statusFilter === 'all' ||
      (statusFilter === 'available' && game.status === 'available') ||
      (statusFilter === 'coming_soon' && game.status === 'coming_soon');
    return matchesCat && matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-purple-950/30 to-slate-900 border border-slate-800 p-5 sm:p-6">
        <div className="flex items-center gap-2 text-purple-400 text-xs font-bold uppercase tracking-wider mb-1">
          <Gamepad2 className="w-4 h-4" />
          <span>Full Catalog</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white">All Games</h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-xl">
          Browse our collection of mobile-optimized casual games. Play solo, challenge friends, and track your scores.
        </p>
      </div>

      {/* Search and Filters Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by title or category..."
            className="w-full min-h-[46px] rounded-xl bg-slate-900 border border-slate-800 pl-11 pr-4 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-purple-500 focus:ring-2 focus:ring-purple-500/30"
          />
        </div>

        {/* Status Dropdown Filter */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 flex items-center gap-1 font-medium hidden sm:flex">
            <Filter className="w-3.5 h-3.5" /> Filter:
          </span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="min-h-[46px] px-3.5 rounded-xl bg-slate-900 border border-slate-800 text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-purple-500"
          >
            <option value="all">All Statuses</option>
            <option value="available">Playable Now</option>
            <option value="coming_soon">Coming Soon</option>
          </select>
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none no-select">
        {categories.map((cat) => (
          <button
            key={cat.key}
            onClick={() => setSelectedCategory(cat.key)}
            className={`shrink-0 flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
              selectedCategory === cat.key
                ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
          >
            <span>{cat.icon}</span>
            <span>{cat.label}</span>
          </button>
        ))}
      </div>

      {/* Games Grid */}
      {filteredGames.length > 0 ? (
        <div className="grid grid-cols-1 xs:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-3.5 sm:gap-5">
          {filteredGames.map((game) => (
            <GameCard key={game.id} game={game} />
          ))}
        </div>
      ) : (
        <div className="py-16 text-center space-y-3 rounded-2xl bg-slate-900/50 border border-slate-800/80">
          <div className="w-12 h-12 rounded-full bg-slate-800 text-slate-400 mx-auto flex items-center justify-center">
            <Sparkles className="w-6 h-6" />
          </div>
          <h3 className="text-base font-semibold text-white">No games found</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Try searching for something else or clearing your category filters.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('all');
              setStatusFilter('all');
            }}
            className="text-xs font-semibold text-purple-400 hover:text-purple-300 underline"
          >
            Reset Filters
          </button>
        </div>
      )}
    </div>
  );
};
