import React, { useEffect } from 'react';

declare global {
  interface Window {
    adsbygoogle?: any[];
  }
}

interface AdBannerProps {
  client?: string; // e.g. "ca-pub-1234567890123456"
  slot?: string;   // e.g. "1234567890"
  format?: 'auto' | 'fluid' | 'rectangle';
  className?: string;
}

export const AdBanner: React.FC<AdBannerProps> = ({
  client = import.meta.env.VITE_ADSENSE_CLIENT_ID || '',
  slot = import.meta.env.VITE_ADSENSE_SLOT_ID || '',
  format = 'auto',
  className = '',
}) => {
  const isAdSenseConfigured = Boolean(client && slot && !client.includes('XXXXXXXX'));

  useEffect(() => {
    if (isAdSenseConfigured && typeof window !== 'undefined') {
      try {
        (window.adsbygoogle = window.adsbygoogle || []).push({});
      } catch (e) {
        console.warn('AdSense push error:', e);
      }
    }
  }, [isAdSenseConfigured]);

  return (
    <div className={`w-full my-4 flex flex-col items-center justify-center ${className}`}>
      {/* Required Google Disclosure */}
      <span className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold mb-1">
        Advertisement
      </span>

      {isAdSenseConfigured ? (
        <ins
          className="adsbygoogle block w-full text-center"
          style={{ display: 'block' }}
          data-ad-client={client}
          data-ad-slot={slot}
          data-ad-format={format}
          data-full-width-responsive="true"
        />
      ) : (
        /* Demo Ad Placeholder while awaiting Google AdSense Approval */
        <div className="w-full max-w-2xl min-h-[90px] rounded-2xl bg-slate-900/80 border border-dashed border-slate-700/80 p-4 flex flex-col items-center justify-center text-center space-y-1">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-300">
            <span>📢 Google AdSense Display Unit (Responsive 728×90 / 300×250)</span>
          </div>
          <p className="text-[11px] text-slate-500 max-w-md">
            This space renders live responsive ads once your site is approved by Google AdSense and your <code className="text-purple-400">ca-pub-XXXXX</code> client ID is configured.
          </p>
        </div>
      )}
    </div>
  );
};
