import { create } from 'zustand';
import { Game, GameCategory } from '../types';

interface GameState {
  games: Game[];
  selectedCategory: GameCategory;
  searchQuery: string;
  activeSessionId: string | null;
  activeSessionSeconds: number;
  
  // Actions
  setSelectedCategory: (cat: GameCategory) => void;
  setSearchQuery: (query: string) => void;
  updateGameStatus: (id: string, updates: Partial<Game>) => void;
  startSession: (gameId: string) => void;
  recordHeartbeat: (seconds: number) => void;
  endSession: () => number; // returns elapsed seconds
}

export const INITIAL_GAMES: Game[] = [
  {
    id: 'game_ttt',
    slug: 'tic-tac-toe',
    title: 'Tic Tac Toe Pro',
    description: 'Play against smart AI or invite a friend with a 6-character room code.',
    category: 'classic',
    status: 'available',
    thumbnail: 'tic-tac-toe',
    playersCount: '1-2 Players',
    rating: 4.8,
    featured: true,
    popular: true,
    rewardsEnabled: true,
    minPlaySecondsForReward: 45,
    pointsReward: 50,
  },
  {
    id: 'game_block_puzzle',
    slug: 'block-puzzle',
    title: 'Combo Block Puzzle',
    description: 'Place colorful polyomino shapes, blast full rows & columns, and trigger combo score explosions!',
    category: 'puzzle',
    status: 'available',
    thumbnail: 'block-puzzle',
    playersCount: 'Single Player',
    rating: 4.9,
    featured: true,
    popular: true,
    rewardsEnabled: true,
    minPlaySecondsForReward: 60,
    pointsReward: 75,
  },
  {
    id: 'game_fruit_crash',
    slug: 'fruit-crash',
    title: 'Fruit Crash Slicer',
    description: 'Slice juicy flying fruits with high-speed neon blade swipes, trigger combos, and dodge explosive bombs!',
    category: 'arcade',
    status: 'available',
    thumbnail: 'fruit-crash',
    playersCount: 'Single Player',
    rating: 5.0,
    featured: true,
    popular: true,
    rewardsEnabled: true,
    minPlaySecondsForReward: 45,
    pointsReward: 5,
  },
];

export const useGameStore = create<GameState>((set, get) => ({
  games: INITIAL_GAMES,
  selectedCategory: 'all',
  searchQuery: '',
  activeSessionId: null,
  activeSessionSeconds: 0,

  setSelectedCategory: (category) => set({ selectedCategory: category }),
  setSearchQuery: (query) => set({ searchQuery: query }),

  updateGameStatus: (id, updates) => {
    set((state) => ({
      games: state.games.map((g) => (g.id === id ? { ...g, ...updates } : g)),
    }));
  },

  startSession: (gameId) => {
    set({
      activeSessionId: `${gameId}_${Date.now()}`,
      activeSessionSeconds: 0,
    });
  },

  recordHeartbeat: (seconds) => {
    set((state) => ({
      activeSessionSeconds: state.activeSessionSeconds + seconds,
    }));
  },

  endSession: () => {
    const elapsed = get().activeSessionSeconds;
    set({
      activeSessionId: null,
      activeSessionSeconds: 0,
    });
    return elapsed;
  },
}));
