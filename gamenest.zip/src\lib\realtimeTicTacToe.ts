import { supabase, isSupabaseConfigured } from './supabase';
import { BoardState, Player } from '../game-logic/tic-tac-toe';

export type MultiplayerRole = 'host' | 'guest';

export interface RoomSyncEvent {
  type: 'player_joined' | 'player_move' | 'player_reset' | 'room_sync' | 'player_leave';
  senderSymbol: Player;
  senderName: string;
  senderRole?: MultiplayerRole;
  cellIndex?: number;
  boardState?: BoardState;
  nextTurn?: Player;
}

export interface RealtimeTTTOptions {
  roomCode: string;
  role: MultiplayerRole;
  symbol: Player;
  name: string;
  onConnected: (opponentName: string) => void;
  onMessage: (event: RoomSyncEvent) => void;
  onOpponentLeft: (opponentName: string) => void;
  onError: (errMsg: string) => void;
}

export class RealtimeTicTacToeManager {
  private channel: any = null;
  private roomCode: string = '';
  private role: MultiplayerRole = 'host';
  private symbol: Player = 'X';
  private name: string = 'Player';
  private opponentName: string = 'Opponent';
  private isConnected: boolean = false;
  private searchTimeout: any = null;
  private heartbeatInterval: any = null;

  private onConnectedCb: ((opponentName: string) => void) | null = null;
  private onMessageCb: ((event: RoomSyncEvent) => void) | null = null;
  private onOpponentLeftCb: ((opponentName: string) => void) | null = null;
  private onErrorCb: ((errMsg: string) => void) | null = null;

  /**
   * Connects to a live 2-player room channel by 6-character code
   */
  public connect(options: RealtimeTTTOptions) {
    this.disconnect();

    this.roomCode = options.roomCode.toUpperCase().trim();
    this.role = options.role;
    this.symbol = options.symbol;
    this.name = options.name || (options.role === 'host' ? 'Host' : 'Guest');
    this.onConnectedCb = options.onConnected;
    this.onMessageCb = options.onMessage;
    this.onOpponentLeftCb = options.onOpponentLeft;
    this.onErrorCb = options.onError;
    this.isConnected = false;

    if (!isSupabaseConfigured || !supabase) {
      if (this.onErrorCb) {
        this.onErrorCb('Supabase credentials not configured. Please check connection.');
      }
      return;
    }

    const channelName = `ttt_room_${this.roomCode}`;

    try {
      this.channel = supabase.channel(channelName, {
        config: {
          broadcast: { ack: true, self: false },
          presence: { key: this.role },
        },
      });

      // 1. Listen for Broadcast Events (Moves, Resets, State Sync)
      this.channel.on('broadcast', { event: 'game_event' }, (msg: any) => {
        if (!msg?.payload) return;
        const event = msg.payload as RoomSyncEvent;

        if (event.type === 'player_joined') {
          // If we are Host and Guest announces joined, acknowledge and share current board
          if (this.role === 'host') {
            this.handleMatchEstablished(event.senderName || 'Guest');
            this.broadcast({
              type: 'room_sync',
              senderSymbol: 'X',
              senderName: this.name,
              senderRole: 'host',
              boardState: Array(9).fill(null),
              nextTurn: 'X',
            });
          }
        } else if (event.type === 'room_sync') {
          // Guest receives host sync
          if (this.role === 'guest') {
            this.handleMatchEstablished(event.senderName || 'Host');
          }
          if (this.onMessageCb) this.onMessageCb(event);
        } else if (event.type === 'player_leave') {
          if (this.onOpponentLeftCb) {
            this.onOpponentLeftCb(event.senderName || 'Opponent');
          }
        } else {
          if (this.onMessageCb) {
            this.onMessageCb(event);
          }
        }
      });

      // 2. Listen for Realtime Presence Events
      this.channel
        .on('presence', { event: 'sync' }, () => {
          this.checkPresenceState();
        })
        .on('presence', { event: 'join' }, ({ key, newPresences }: any) => {
          const opponentRole = this.role === 'host' ? 'guest' : 'host';
          if (key === opponentRole && Array.isArray(newPresences) && newPresences.length > 0) {
            const opp = newPresences[0];
            const oppName = opp?.name || (opponentRole === 'host' ? 'Host' : 'Friend');
            this.handleMatchEstablished(oppName);
          }
        })
        .on('presence', { event: 'leave' }, ({ key, leftPresences }: any) => {
          const opponentRole = this.role === 'host' ? 'guest' : 'host';
          if (key === opponentRole) {
            const opp = leftPresences?.[0];
            const oppName = opp?.name || this.opponentName;
            this.isConnected = false;
            if (this.onOpponentLeftCb) {
              this.onOpponentLeftCb(oppName);
            }
          }
        });

      // 3. Subscribe to the channel
      this.channel.subscribe(async (status: string, err: any) => {
        if (status === 'SUBSCRIBED') {
          // Track our own presence in the room
          try {
            await this.channel.track({
              name: this.name,
              symbol: this.symbol,
              role: this.role,
              onlineAt: Date.now(),
            });
          } catch (e) {
            console.warn('Presence track warning:', e);
          }

          // If Guest, broadcast player_joined announcement
          if (this.role === 'guest') {
            this.broadcast({
              type: 'player_joined',
              senderSymbol: 'O',
              senderName: this.name,
              senderRole: 'guest',
            });

            // Set a timeout: If no host presence after 6 seconds, warn user
            this.searchTimeout = setTimeout(() => {
              if (!this.isConnected) {
                const presence = this.channel?.presenceState() || {};
                if (!presence['host']) {
                  if (this.onErrorCb) {
                    this.onErrorCb(
                      `Room "${this.roomCode}" was not found or the host has disconnected. Please verify the code.`
                    );
                  }
                }
              }
            }, 6000);
          }

          // Immediately check if opponent is already in presence
          this.checkPresenceState();
        } else if (status === 'CHANNEL_ERROR') {
          console.error('Channel error:', err);
          if (this.onErrorCb) {
            this.onErrorCb('Connection error. Retrying connection...');
          }
        }
      });
    } catch (e: any) {
      console.error('Failed to initialize channel:', e);
      if (this.onErrorCb) {
        this.onErrorCb(e?.message || 'Could not connect to multiplayer server.');
      }
    }
  }

  private checkPresenceState() {
    if (!this.channel) return;
    try {
      const state = this.channel.presenceState() || {};
      const opponentRole = this.role === 'host' ? 'guest' : 'host';
      const oppPresences = state[opponentRole];

      if (oppPresences && oppPresences.length > 0) {
        const opp = oppPresences[0];
        const oppName = opp?.name || (opponentRole === 'host' ? 'Host' : 'Friend');
        this.handleMatchEstablished(oppName);
      }
    } catch (e) {
      console.warn('Error reading presence state:', e);
    }
  }

  private handleMatchEstablished(oppName: string) {
    if (this.isConnected) return;
    this.isConnected = true;
    this.opponentName = oppName;

    if (this.searchTimeout) {
      clearTimeout(this.searchTimeout);
      this.searchTimeout = null;
    }

    if (this.onConnectedCb) {
      this.onConnectedCb(oppName);
    }
  }

  /**
   * Broadcasts an event to the other player over WebSockets
   */
  public broadcast(event: RoomSyncEvent) {
    if (!this.channel) return;
    try {
      this.channel.send({
        type: 'broadcast',
        event: 'game_event',
        payload: event,
      });
    } catch (err) {
      console.error('Broadcast failed:', err);
    }
  }

  /**
   * Broadcasts a move
   */
  public sendMove(cellIndex: number, boardState: BoardState, nextTurn: Player) {
    this.broadcast({
      type: 'player_move',
      senderSymbol: this.symbol,
      senderName: this.name,
      senderRole: this.role,
      cellIndex,
      boardState,
      nextTurn,
    });
  }

  /**
   * Broadcasts a board reset / rematch
   */
  public sendReset() {
    this.broadcast({
      type: 'player_reset',
      senderSymbol: this.symbol,
      senderName: this.name,
      senderRole: this.role,
    });
  }

  /**
   * Leaves and cleans up channel
   */
  public disconnect() {
    if (this.searchTimeout) {
      clearTimeout(this.searchTimeout);
      this.searchTimeout = null;
    }
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
    }

    if (this.channel && supabase) {
      try {
        if (this.isConnected) {
          this.broadcast({
            type: 'player_leave',
            senderSymbol: this.symbol,
            senderName: this.name,
            senderRole: this.role,
          });
        }
        this.channel.untrack();
        supabase.removeChannel(this.channel);
      } catch (e) {
        console.warn('Error disconnecting channel:', e);
      }
      this.channel = null;
    }

    this.isConnected = false;
    this.onConnectedCb = null;
    this.onMessageCb = null;
    this.onOpponentLeftCb = null;
    this.onErrorCb = null;
  }
}

export const realtimeTTT = new RealtimeTicTacToeManager();
