/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ['class'],
  content: [
    './index.html',
    './src/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        background: '#0b0f19',
        card: '#131b2e',
        'card-hover': '#1a243d',
        navy: {
          800: '#1e293b',
          900: '#0f172a',
          950: '#0b0f19',
        },
        primary: {
          DEFAULT: '#8b5cf6',
          foreground: '#ffffff',
          dark: '#7c3aed',
          light: '#a78bfa',
        },
        electric: {
          blue: '#00d2ff',
          cyan: '#06b6d4',
          indigo: '#6366f1',
        },
        success: '#10b981',
        warning: '#f59e0b',
        danger: '#ef4444',
      },
      borderRadius: {
        lg: '1rem',
        md: '0.75rem',
        sm: '0.5rem',
      },
      keyframes: {
        'fade-in': {
          '0%': { opacity: '0', transform: 'translateY(6px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'pulse-glow': {
          '0%, 100%': { boxShadow: '0 0 15px rgba(139, 92, 246, 0.4)' },
          '50%': { boxShadow: '0 0 25px rgba(6, 182, 212, 0.6)' },
        },
        'combo-pop': {
          '0%': { transform: 'scale(0.8)', opacity: '0' },
          '50%': { transform: 'scale(1.2)' },
          '100%': { transform: 'scale(1)', opacity: '1' },
        },
      },
      animation: {
        'fade-in': 'fade-in 0.25s ease-out',
        'pulse-glow': 'pulse-glow 2s infinite',
        'combo-pop': 'combo-pop 0.3s ease-out',
      },
    },
  },
  plugins: [],
};
