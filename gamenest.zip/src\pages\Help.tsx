import React, { useState } from 'react';
import { HelpCircle, ChevronDown, MessageSquare, Shield, Coins, Users } from 'lucide-react';

interface FAQItem {
  question: string;
  answer: string;
  category: string;
}

export const Help: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs: FAQItem[] = [
    {
      category: 'Gameplay',
      question: 'How do I play Tic Tac Toe with a friend?',
      answer:
        'Open Tic Tac Toe Pro, select the "2 Players" tab, click "Generate Room Code", and share the 6-character code with your friend. They open the same page, enter your code in the "Join" tab, and both boards will synchronize in real time!',
    },
    {
      category: 'Rewards',
      question: 'How do I earn GameNest points?',
      answer:
        'You earn points by playing games! For example, defeating the Tic Tac Toe robot awards +50 points, and clearing lines or triggering combos in Combo Block Puzzle awards bonus combo points. You can also receive daily login bonuses.',
    },
    {
      category: 'Rewards',
      question: 'How does the ₹100 reward redemption work?',
      answer:
        'Once you accumulate 10,000 points (100 points = ₹1), you can visit the "Redeem" tab and request a ₹100 withdrawal to your UPI ID. All requests are reviewed by administrators and transferred directly via UPI.',
    },
    {
      category: 'AI Opponents',
      question: 'Can I beat the Extreme Robot in Tic Tac Toe?',
      answer:
        'The Extreme robot runs the mathematical Minimax algorithm, which evaluates every possible game scenario. Under optimal play, Extreme will never lose: you can achieve a victory against Easy, a tight battle against Hard, and an honorable draw against Extreme!',
    },
    {
      category: 'Security',
      question: 'Is GameNest a real-money gambling platform?',
      answer:
        'No. GameNest is strictly a casual, skill-based gaming website with zero cash deposits, zero wagering, and zero gambling mechanics. All games are 100% free to play.',
    },
    {
      category: 'Account',
      question: 'Are my mobile number and UPI ID safe?',
      answer:
        'Yes. Your payment details are strictly restricted using PostgreSQL Row Level Security (RLS) policies and encrypted server-side storage. Only authorized system administrators can access them during payout processing.',
    },
  ];

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-fade-in">
      {/* Header */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-purple-950/40 to-slate-900 border border-slate-800 p-5 sm:p-6">
        <div className="flex items-center gap-2 text-purple-400 text-xs font-bold uppercase tracking-wider mb-1">
          <HelpCircle className="w-4 h-4" />
          <span>Support & Guidance</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-white">Help & Frequently Asked Questions</h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Got questions about games, rules, multiplayer rooms, or reward redemptions? Find answers here.
        </p>
      </div>

      {/* Accordion FAQ */}
      <div className="space-y-3">
        {faqs.map((faq, idx) => {
          const isOpen = openIndex === idx;
          return (
            <div
              key={idx}
              className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden transition-all duration-150"
            >
              <button
                onClick={() => setOpenIndex(isOpen ? null : idx)}
                className="w-full p-4 sm:p-5 flex items-center justify-between text-left gap-4 hover:bg-slate-800/30 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <span className="w-2 h-2 rounded-full bg-purple-500 shrink-0" />
                  <span className="text-sm sm:text-base font-bold text-white">{faq.question}</span>
                </div>
                <ChevronDown
                  className={`w-4 h-4 text-slate-400 transition-transform duration-200 shrink-0 ${
                    isOpen ? 'rotate-180 text-purple-400' : ''
                  }`}
                />
              </button>

              {isOpen && (
                <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-300 border-t border-slate-800/50 leading-relaxed">
                  <p>{faq.answer}</p>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Contact Support Banner */}
      <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-600/20 text-purple-400 flex items-center justify-center">
            <MessageSquare className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white">Need more help?</h4>
            <p className="text-xs text-slate-400">Our support team is available 24/7 for bug reports & inquiries.</p>
          </div>
        </div>
        <a
          href="mailto:support@gamenest.test"
          className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white border border-slate-700 transition-colors"
        >
          Contact Support
        </a>
      </div>
    </div>
  );
};
