# 🎮 GameNest — Mobile-First Casual Gaming Platform

Welcome to **GameNest**, a mobile-first casual gaming platform featuring real-time multiplayer, single-player block puzzle challenges, secure points tracking, and reward redemptions.

---

## 🚀 Beginner Quick-Start Guide (3 Simple Steps)

If you are new to web development, don't worry! Follow these 3 easy steps to run the game on your computer or phone:

### Step 1: Open the Project
Open PowerShell or your terminal and change to the project directory:
```bash
cd C:\Users\user\.gemini\antigravity\scratch\gamenest
```

### Step 2: Start the Local Development Server
Run this command:
```bash
npm run dev
```
You will see output like this:
```
  VITE v5.4.1  ready in 250 ms

  ➜  Local:   http://localhost:5173/
  ➜  Network: http://192.168.x.x:5173/
```

### Step 3: Open in Your Browser
- Click or open **`http://localhost:5173`** in your browser (Google Chrome, Edge, Safari, or Firefox).
- To test mobile view: Press `F12` on your keyboard, then click the **Mobile Device Toggle** icon (or press `Ctrl+Shift+M`) to view it as an Android phone (Pixel 7 / Samsung Galaxy).

---

## 📁 Project Folder Structure

Here is how the project files are organized:

```
gamenest/
├── public/                 # Static assets (favicons, game art, icons)
├── src/
│   ├── components/         # Reusable UI components
│   │   ├── common/         # GameCard, SectionHeader, StatusBadge
│   │   ├── games/          # Game-specific boards (BlockPuzzle, TicTacToe)
│   │   ├── layout/         # Header, MobileNav, Footer
│   │   └── ui/             # Buttons, Dialogs, Inputs, Modals
│   ├── game-logic/         # Pure testable game rules and AI algorithms
│   │   ├── block-puzzle/   # Shape definitions, line clearing, scoring
│   │   └── tic-tac-toe/    # Win check, Easy AI, Hard AI, Minimax Extreme AI
│   ├── lib/                # Supabase client, helper functions, constants
│   ├── pages/              # 11 Main Screens
│   │   ├── Home.tsx        # Portal homepage with featured games and banner
│   │   ├── Games.tsx       # All Games catalog with search and filters
│   │   ├── TicTacToe.tsx   # Tic Tac Toe (Robot + Realtime Multiplayer)
│   │   ├── BlockPuzzle.tsx # 10x10 Block Puzzle game
│   │   ├── Wallet.tsx      # Points wallet and transaction ledger
│   │   ├── Redeem.tsx      # ₹100 Reward redemption workflow
│   │   ├── Profile.tsx     # Player stats, history, and settings
│   │   ├── Help.tsx        # Frequently Asked Questions and support
│   │   ├── Privacy.tsx     # Privacy Policy
│   │   ├── Terms.tsx       # Terms and Conditions
│   │   ├── AdminLogin.tsx  # Secure Admin Login
│   │   └── admin/          # Admin Dashboard (Overview, Withdrawals, Users, Games)
│   ├── stores/             # Client state management (Zustand)
│   ├── types/              # TypeScript data types
│   ├── test/               # Automated test suites
│   ├── App.tsx             # Main routing and navigation layout
│   ├── index.css           # Tailwind CSS and theme design tokens
│   └── main.tsx            # Application entry point
├── supabase/
│   └── migrations/         # PostgreSQL database schemas and RLS security policies
├── .env.example            # Template for environment variables (safe to share)
└── package.json            # Project dependencies and run scripts
```

---

## 🗄️ Database Design Overview

GameNest uses PostgreSQL via Supabase with **Row Level Security (RLS)** protecting all tables:

1. **`profiles`**: Stores player display name, avatar, points balance (integer), and admin status.
2. **`games`**: Stores game catalog (Tic Tac Toe, Block Puzzle, Fruit Crash), visibility, and rewards status.
3. **`game_sessions`**: Tracks active gameplay time with server-side heartbeats to prevent cheat scripts.
4. **`multiplayer_rooms`**: Stores online 2-player rooms, 6-character room codes, host, guest, and board state.
5. **`game_moves`**: Records every move sequentially with server-side validation.
6. **`points_ledger`**: Immutable financial ledger tracking every point earned or spent.
7. **`reward_config`**: Server-side configuration for reward rules and the cash redemption feature flag.
8. **`withdrawal_requests`**: Withdrawal tickets (₹100 / 10,000 paise) submitted for review.
9. **`withdrawal_details`**: Restrictive admin-only table protecting sensitive UPI IDs and mobile numbers.
10. **`admin_audit_logs`**: Permanent record of every approval, rejection, or setting change made by admins.

---

## 🔑 Supabase Connection Guide (When you are ready for Phase 2)

You do **not** need Supabase right now to play offline or against the robot. When moving to Phase 2:

1. Go to [https://supabase.com](https://supabase.com) and create a free account.
2. Click **New Project** and name it `GameNest`.
3. In the Supabase sidebar, click **Project Settings** (gear icon) -> **API**.
4. Copy the **Project URL** and paste it into `.env`:
   ```
   VITE_SUPABASE_URL=https://your-id.supabase.co
   ```
5. Copy the **`anon` `public` key** and paste it into `.env`:
   ```
   VITE_SUPABASE_ANON_KEY=eyJhbGciOi...
   ```
6. **IMPORTANT:** Never copy or put the `service_role` secret in `.env` or any frontend file.

---

## 🧪 Running Automated Tests

To test game logic, AI algorithms, and rule enforcement:
```bash
npm run test
```
All tests should pass before deploying any phase!

---

## 🌐 Deploy to GitHub & Netlify (Step-by-Step)

### Step 1: Upload to GitHub
1. Go to [https://github.com/new](https://github.com/new) and create a new repository named `gamenest`.
2. Extract the `gamenest.zip` on your computer.
3. In your project folder, run:
   ```bash
   git init
   git add .
   git commit -m "feat: complete GameNest platform with real-time multiplayer, fruit crash, block puzzle, and admin lock"
   git branch -M main
   git remote add origin https://github.com/YOUR_GITHUB_USERNAME/gamenest.git
   git push -u origin main
   ```
*(Alternatively, you can drag and drop the unzipped files directly into the GitHub website!)*

### Step 2: Deploy on Netlify (100% Free)
1. Go to [https://app.netlify.com](https://app.netlify.com) and log in (or sign up with GitHub).
2. Click **"Add new site"** ➔ **"Import an existing project"** (or choose **"Deploy manually"** and drag the `dist` folder).
3. Connect your GitHub account and select your `gamenest` repository.
4. Netlify will automatically detect the settings:
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`
5. Click **"Environment variables"** ➔ **"Add a variable"**:
   - `VITE_SUPABASE_URL` = `https://ejabkqxbajzsnimeiprb.supabase.co`
   - `VITE_SUPABASE_ANON_KEY` = `sb_publishable_reEmpUrSjumALpG7DmrVOw_-nkEKRHV`
6. Click **"Deploy gamenest"**.
7. In ~60 seconds, your site is live with an SSL HTTPS URL (e.g. `https://gamenest-xyz.netlify.app`)!

> **Note**: The included `netlify.toml` and `public/_redirects` already configure the single-page application (SPA) rewrite rules so direct visits to `/tic-tac-toe`, `/block-puzzle`, `/fruit-crash`, and `/admin` work smoothly without 404 errors.

