import { describe, it, expect } from 'vitest';
import {
  checkWinner,
  getAvailableMoves,
  getAIMove,
  BoardState,
  Player,
  WINNING_COMBOS,
} from '../game-logic/tic-tac-toe';

describe('Tic Tac Toe Rule Engine', () => {
  it('detects wins across all 3 rows', () => {
    // Row 0
    expect(checkWinner(['X', 'X', 'X', null, null, null, null, null, null]).winner).toBe('X');
    // Row 1
    expect(checkWinner([null, null, null, 'O', 'O', 'O', null, null, null]).winner).toBe('O');
    // Row 2
    expect(checkWinner([null, null, null, null, null, null, 'X', 'X', 'X']).winner).toBe('X');
  });

  it('detects wins across all 3 columns', () => {
    // Col 0
    expect(checkWinner(['X', null, null, 'X', null, null, 'X', null, null]).winner).toBe('X');
    // Col 1
    expect(checkWinner([null, 'O', null, null, 'O', null, null, 'O', null]).winner).toBe('O');
    // Col 2
    expect(checkWinner([null, null, 'X', null, null, 'X', null, null, 'X']).winner).toBe('X');
  });

  it('detects wins across both diagonals', () => {
    // Main diagonal
    expect(checkWinner(['O', null, null, null, 'O', null, null, null, 'O']).winner).toBe('O');
    // Anti-diagonal
    expect(checkWinner([null, null, 'X', null, 'X', null, 'X', null, null]).winner).toBe('X');
  });

  it('detects draw correctly when board is full with no winner', () => {
    const drawBoard: BoardState = [
      'X', 'O', 'X',
      'X', 'O', 'O',
      'O', 'X', 'X',
    ];
    const result = checkWinner(drawBoard);
    expect(result.winner).toBe('draw');
    expect(result.winningLine).toBeNull();
  });

  it('reports in-progress game when no winner and cells remain', () => {
    const activeBoard: BoardState = [
      'X', 'O', null,
      null, 'X', null,
      null, null, null,
    ];
    const result = checkWinner(activeBoard);
    expect(result.winner).toBeNull();
  });

  it('returns correct available empty cells', () => {
    const board: BoardState = ['X', null, 'O', null, 'X', null, null, null, 'O'];
    const moves = getAvailableMoves(board);
    expect(moves).toEqual([1, 3, 5, 6, 7]);
  });
});

describe('Tic Tac Toe AI Difficulties', () => {
  it('Hard AI blocks immediate human winning threat', () => {
    // Human (X) threatens on indices [0, 1]
    const board: BoardState = [
      'X', 'X', null,
      'O', null, null,
      null, null, null,
    ];
    const move = getAIMove(board, 'O', 'hard');
    expect(move).toBe(2); // must block cell 2
  });

  it('Hard AI takes immediate win when available', () => {
    // AI (O) has [0, 3] and needs [6] to win
    const board: BoardState = [
      'O', 'X', 'X',
      'O', 'X', null,
      null, null, null,
    ];
    const move = getAIMove(board, 'O', 'hard');
    expect(move).toBe(6); // must take win
  });

  it('PROVES: Extreme Minimax AI never loses across 50 simulated games', () => {
    let aiLosses = 0;
    let aiWins = 0;
    let draws = 0;

    for (let sim = 0; sim < 50; sim++) {
      let board: BoardState = Array(9).fill(null);
      let currentTurn: Player = sim % 2 === 0 ? 'X' : 'O'; // Alternate starting player
      const humanPlayer: Player = 'X';
      const aiPlayer: Player = 'O';

      while (checkWinner(board).winner === null) {
        if (currentTurn === humanPlayer) {
          // Simulated human player plays random or aggressive moves
          const empty = getAvailableMoves(board);
          if (empty.length === 0) break;
          const randomMove = empty[Math.floor(Math.random() * empty.length)];
          board[randomMove] = humanPlayer;
          currentTurn = aiPlayer;
        } else {
          // Extreme AI turn
          const aiMove = getAIMove(board, aiPlayer, 'extreme');
          expect(aiMove).toBeGreaterThanOrEqual(0);
          expect(board[aiMove]).toBeNull();
          board[aiMove] = aiPlayer;
          currentTurn = humanPlayer;
        }
      }

      const final = checkWinner(board);
      if (final.winner === humanPlayer) {
        aiLosses++;
      } else if (final.winner === aiPlayer) {
        aiWins++;
      } else if (final.winner === 'draw') {
        draws++;
      }
    }

    // Mathematical verification: Minimax AI must NEVER lose (0 losses)
    expect(aiLosses).toBe(0);
    expect(aiWins + draws).toBe(50);
  });
});
