import React from 'react';
import { Link } from 'react-router-dom';
import { Gamepad2, ShieldCheck, Heart, Shield } from 'lucide-react';
import { useAuthStore } from '../../stores/useAuthStore';

export const Footer: React.FC = () => {
  const { user } = useAuthStore();
  const isSuperAdmin = user?.email?.toLowerCase() === 'bishawjitbadsha@gmail.com';
  return (
    <footer className="w-full border-t border-slate-800/80 bg-slate-950/80 text-slate-400 text-xs py-8 px-4 sm:px-6 mb-16 md:mb-0">
      <div className="max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 mb-6">
        {/* Brand column */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-purple-600 flex items-center justify-center text-white">
              <Gamepad2 className="w-4 h-4" />
            </div>
            <span className="font-bold text-white text-base">GameNest</span>
          </div>
          <p className="text-slate-400 text-xs leading-relaxed">
            A safe, mobile-first casual gaming playground. Play puzzles, challenge your friends, and accumulate reward points with fair play.
          </p>
        </div>

        {/* Quick Games */}
        <div className="space-y-2">
          <h4 className="font-semibold text-slate-200 text-sm">Quick Play</h4>
          <ul className="space-y-1.5">
            <li>
              <Link to="/tic-tac-toe" className="hover:text-purple-400 transition-colors">
                Tic Tac Toe (Robot & 2P)
              </Link>
            </li>
            <li>
              <Link to="/block-puzzle" className="hover:text-purple-400 transition-colors">
                Combo Block Puzzle
              </Link>
            </li>
            <li>
              <Link to="/games" className="hover:text-purple-400 transition-colors">
                Fruit Crash (Coming Soon)
              </Link>
            </li>
          </ul>
        </div>

        {/* Support & Legal */}
        <div className="space-y-2">
          <h4 className="font-semibold text-slate-200 text-sm">Support & Legal</h4>
          <ul className="space-y-1.5">
            <li>
              <Link to="/help" className="hover:text-purple-400 transition-colors">
                Help & FAQs
              </Link>
            </li>
            <li>
              <Link to="/privacy" className="hover:text-purple-400 transition-colors">
                Privacy Policy
              </Link>
            </li>
            <li>
              <Link to="/terms" className="hover:text-purple-400 transition-colors">
                Terms & Conditions
              </Link>
            </li>
          </ul>
        </div>

        {/* Admin & Security */}
        <div className="space-y-2">
          <h4 className="font-semibold text-slate-200 text-sm">Security & Staff</h4>
          <p className="flex items-center gap-1.5 text-emerald-400 font-medium">
            <ShieldCheck className="w-4 h-4" />
            Fair Play & Anti-Cheat Active
          </p>
          {isSuperAdmin && (
            <div>
              <Link
                to="/admin"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-950/60 border border-rose-500/40 hover:border-rose-400 text-rose-300 hover:text-white transition-colors text-xs font-bold"
              >
                <Shield className="w-3.5 h-3.5" />
                Admin Dashboard
              </Link>
            </div>
          )}
        </div>
      </div>

      <div className="max-w-7xl mx-auto pt-6 border-t border-slate-800/60 flex flex-col sm:flex-row items-center justify-between gap-3 text-slate-500">
        <p>© {new Date().getFullYear()} GameNest. All rights reserved. Zero real-money wagering or gambling.</p>
        <p className="flex items-center gap-1">
          Built with <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" /> for mobile & desktop gamers
        </p>
      </div>
    </footer>
  );
};
