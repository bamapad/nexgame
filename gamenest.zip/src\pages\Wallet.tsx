import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Coins,
  TrendingUp,
  ArrowDownLeft,
  ArrowUpRight,
  ShieldCheck,
  Info,
  Clock,
  Sparkles,
  ArrowRight,
} from 'lucide-react';
import { useAuthStore } from '../stores/useAuthStore';
import { Button } from '../components/ui/Button';

export const Wallet: React.FC = () => {
  const navigate = useNavigate();
  const { user, transactions, rewardConfig } = useAuthStore();

  const currentPoints = user ? user.pointsBalance : 0;
  const totalEarned = user ? user.totalEarnedPoints : 0;
  const totalSpent = user ? user.totalSpentPoints : 0;
  const targetPoints = rewardConfig.requiredPoints;
  const progressPercent = Math.min(100, Math.round((currentPoints / targetPoints) * 100));

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fade-in">
      {/* Page Header */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-purple-950/40 to-slate-900 border border-slate-800 p-5 sm:p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-purple-400 text-xs font-bold uppercase tracking-wider mb-1">
            <Coins className="w-4 h-4" />
            <span>Financial & Activity Ledger</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white">Points Wallet</h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Real-time auditable ledger of your game rewards and redemption requests.
          </p>
        </div>

        <Button
          size="md"
          variant="electric"
          onClick={() => navigate('/redeem')}
          rightIcon={<ArrowRight className="w-4 h-4" />}
          className="w-full sm:w-auto font-bold"
        >
          Redeem Rewards
        </Button>
      </div>

      {/* 3 Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 sm:gap-4">
        {/* Available Balance */}
        <div className="rounded-2xl bg-slate-900/90 border border-purple-500/40 p-4 sm:p-5 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between text-xs font-bold text-purple-300 uppercase tracking-wider">
            <span>Available Points</span>
            <div className="w-7 h-7 rounded-lg bg-yellow-500/20 text-yellow-400 flex items-center justify-center">
              <Coins className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 text-2xl sm:text-3xl font-black text-white">
            {currentPoints.toLocaleString()} <span className="text-xs text-purple-400 font-semibold">pts</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Equivalent value: ₹{((currentPoints / targetPoints) * 100).toFixed(0)}
          </p>
        </div>

        {/* Total Earned */}
        <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-4 sm:p-5 shadow-lg">
          <div className="flex items-center justify-between text-xs font-bold text-slate-400 uppercase tracking-wider">
            <span>Total Earned</span>
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 text-2xl sm:text-3xl font-black text-emerald-400">
            +{totalEarned.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">All-time accumulated gameplay points</p>
        </div>

        {/* Total Spent / Redeemed */}
        <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-4 sm:p-5 shadow-lg">
          <div className="flex items-center justify-between text-xs font-bold text-slate-400 uppercase tracking-wider">
            <span>Spent / Redeemed</span>
            <div className="w-7 h-7 rounded-lg bg-slate-800 text-slate-400 flex items-center justify-center">
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 text-2xl sm:text-3xl font-black text-slate-300">
            {totalSpent.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Withdrawn via UPI or rewards</p>
        </div>
      </div>

      {/* Progress to ₹100 Card */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 sm:p-5 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-yellow-400" />
            <h3 className="text-sm sm:text-base font-bold text-white">
              Reward Progress: ₹{(rewardConfig.rewardPaise / 100).toFixed(0)} UPI Cash
            </h3>
          </div>
          <span className="text-xs font-extrabold text-purple-400">{progressPercent}%</span>
        </div>

        <div className="w-full h-3 rounded-full bg-slate-950 overflow-hidden border border-slate-800">
          <div
            className="h-full bg-gradient-to-r from-purple-600 via-indigo-500 to-cyan-400 rounded-full transition-all duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        <div className="flex items-center justify-between text-xs text-slate-400">
          <span>{currentPoints.toLocaleString()} points earned</span>
          <span>{targetPoints.toLocaleString()} points required</span>
        </div>
      </div>

      {/* Activity & Points Rules Banner */}
      <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-4 space-y-2 text-xs text-slate-400">
        <div className="flex items-center gap-1.5 text-slate-300 font-bold">
          <Info className="w-4 h-4 text-cyan-400" />
          <span>Fair Play Rules & Server Points Verification</span>
        </div>
        <ul className="list-disc list-inside space-y-1 pl-1 leading-relaxed">
          <li>Points are awarded exclusively for verified active gameplay and combo achievements.</li>
          <li>Server session heartbeats require foreground interaction to prevent background botting.</li>
          <li>Daily point limit: max {rewardConfig.dailyMaxPoints} pts/day to ensure fair gameplay.</li>
          <li>Ad clicks or page reloads never award points.</li>
        </ul>
      </div>

      {/* Transaction History Table */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl">
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
            <Clock className="w-4 h-4 text-purple-400" />
            <span>Transaction Ledger</span>
          </h2>
          <span className="text-xs text-slate-400">{transactions.length} Transactions</span>
        </div>

        {transactions.length > 0 ? (
          <div className="divide-y divide-slate-800/80">
            {transactions.map((tx) => {
              const isPositive = tx.amount > 0;
              return (
                <div
                  key={tx.id}
                  className="p-3.5 sm:p-4 flex items-center justify-between hover:bg-slate-800/30 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                        isPositive
                          ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                          : 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                      }`}
                    >
                      {isPositive ? (
                        <ArrowDownLeft className="w-4 h-4" />
                      ) : (
                        <ArrowUpRight className="w-4 h-4" />
                      )}
                    </div>
                    <div>
                      <p className="text-xs sm:text-sm font-semibold text-slate-200">
                        {tx.description}
                      </p>
                      <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5">
                        <span>{new Date(tx.createdAt).toLocaleDateString()}</span>
                        <span>•</span>
                        <span className="capitalize">{tx.type.replace('_', ' ')}</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span
                      className={`font-black text-sm sm:text-base ${
                        isPositive ? 'text-emerald-400' : 'text-slate-300'
                      }`}
                    >
                      {isPositive ? `+${tx.amount}` : tx.amount} pts
                    </span>
                    <span className="block text-[10px] text-slate-500 font-mono">
                      Bal: {tx.balanceAfter}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="py-12 text-center text-slate-400 text-xs">
            No transactions recorded yet. Play a game to earn points!
          </div>
        )}
      </div>
    </div>
  );
};
