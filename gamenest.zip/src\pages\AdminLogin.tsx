import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, Lock, Mail, AlertTriangle, ArrowRight } from 'lucide-react';
import { useAuthStore } from '../stores/useAuthStore';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';

export const AdminLogin: React.FC = () => {
  const navigate = useNavigate();
  const { login } = useAuthStore();

  const [email, setEmail] = useState('bishawjitbadsha@gmail.com');
  const [password, setPassword] = useState('Admin@2026Secure!');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    setTimeout(() => {
      const cleanEmail = email.toLowerCase().trim();
      // Only bishawjitbadsha@gmail.com can log in as admin
      if (cleanEmail === 'bishawjitbadsha@gmail.com' && password === 'Admin@2026Secure!') {
        login(cleanEmail, 'Bishawjit Badsha');
        setIsLoading(false);
        navigate('/admin');
      } else {
        setIsLoading(false);
        setError('Access denied. Administrator privileges are strictly restricted to bishawjitbadsha@gmail.com.');
      }
    }, 600);
  };

  return (
    <div className="max-w-md mx-auto py-8 space-y-6 animate-fade-in">
      {/* Icon & Title */}
      <div className="text-center space-y-2">
        <div className="w-14 h-14 rounded-2xl bg-rose-500/20 text-rose-400 border border-rose-500/40 flex items-center justify-center mx-auto shadow-lg shadow-rose-600/20">
          <Shield className="w-7 h-7" />
        </div>
        <h1 className="text-2xl font-black text-white">Administrator Portal</h1>
        <p className="text-xs text-slate-400">
          Restricted access. Only <span className="text-purple-400 font-mono">bishawjitbadsha@gmail.com</span> is authorized.
        </p>
      </div>

      {/* Login Card */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-2xl space-y-5">
        {error && (
          <div className="p-3.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            label="Admin Email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="bishawjitbadsha@gmail.com"
            leftIcon={<Mail className="w-4 h-4" />}
            required
          />

          <Input
            label="Password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••••••••••"
            leftIcon={<Lock className="w-4 h-4" />}
            required
          />

          <Button
            type="submit"
            size="lg"
            variant="danger"
            fullWidth
            isLoading={isLoading}
            rightIcon={<ArrowRight className="w-4 h-4" />}
            className="font-bold"
          >
            Authenticate Admin
          </Button>
        </form>

        <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 text-[11px] text-slate-400 space-y-1">
          <p className="font-semibold text-slate-300">Authorized Operator Account:</p>
          <p>Email: <code className="text-purple-300 font-mono">bishawjitbadsha@gmail.com</code></p>
          <p>Password: <code className="text-purple-300 font-mono">Admin@2026Secure!</code></p>
        </div>
      </div>
    </div>
  );
};
