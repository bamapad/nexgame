import React from 'react';

export interface BadgeProps {
  children: React.ReactNode;
  variant?: 'available' | 'coming_soon' | 'points' | 'category' | 'outline' | 'admin';
  className?: string;
  icon?: React.ReactNode;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'category',
  className = '',
  icon,
}) => {
  const baseStyles = 'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold tracking-wide';

  const variantStyles = {
    available: 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30',
    coming_soon: 'bg-amber-500/15 text-amber-400 border border-amber-500/30',
    points: 'bg-purple-500/20 text-purple-300 border border-purple-500/40 font-bold',
    category: 'bg-slate-800/90 text-slate-300 border border-slate-700/60',
    outline: 'bg-transparent text-slate-400 border border-slate-700',
    admin: 'bg-rose-500/20 text-rose-300 border border-rose-500/40',
  };

  return (
    <span className={`${baseStyles} ${variantStyles[variant]} ${className}`}>
      {icon && <span className="inline-flex shrink-0">{icon}</span>}
      {children}
    </span>
  );
};
