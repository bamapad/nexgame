import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import {
  ArrowLeft,
  RotateCcw,
  Bot,
  Users,
  Trophy,
  Copy,
  Check,
  Share2,
  Sparkles,
  Zap,
  Radio,
  Loader2,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import {
  BoardState,
  Player,
  Difficulty,
  checkWinner,
  getAIMove,
  GameResult,
} from '../game-logic/tic-tac-toe';
import { useAuthStore } from '../stores/useAuthStore';
import { realtimeTTT, RoomSyncEvent } from '../lib/realtimeTicTacToe';
import { sounds } from '../lib/soundEffects';
import { Button } from '../components/ui/Button';

export const TicTacToe: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { user, awardPoints, addPlaytime } = useAuthStore();

  // Mode Selection: 'robot' | 'multiplayer'
  const [gameMode, setGameMode] = useState<'robot' | 'multiplayer'>('robot');
  const [multiplayerTab, setMultiplayerTab] = useState<'create' | 'join'>('create');

  // Robot Game Settings
  const [humanSymbol, setHumanSymbol] = useState<Player>('X');
  const [difficulty, setDifficulty] = useState<Difficulty>('hard');
  const robotSymbol: Player = humanSymbol === 'X' ? 'O' : 'X';

  // Game Play State
  const [board, setBoard] = useState<BoardState>(Array(9).fill(null));
  const [turn, setTurn] = useState<Player>('X');
  const [result, setResult] = useState<GameResult>({ winner: null, winningLine: null });
  const [isAiThinking, setIsAiThinking] = useState(false);
  const [stats, setStats] = useState({ wins: 0, losses: 0, draws: 0 });

  // Real-Time Multiplayer Room State
  const [roomCode, setRoomCode] = useState<string>('');
  const [joinInputCode, setJoinInputCode] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [isRoomActive, setIsRoomActive] = useState(false);
  const [multiplayerStatus, setMultiplayerStatus] = useState<
    'idle' | 'connecting' | 'waiting_for_friend' | 'connected' | 'opponent_left'
  >('idle');
  const [opponentName, setOpponentName] = useState<string>('Opponent');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Auto-detect room code from URL query param ?room=XXXXXX
  useEffect(() => {
    const roomParam = searchParams.get('room');
    if (roomParam) {
      setGameMode('multiplayer');
      setMultiplayerTab('join');
      setJoinInputCode(roomParam.trim().toUpperCase().slice(0, 6));
    }
  }, [searchParams]);

  // Track active playtime while playing
  useEffect(() => {
    const interval = setInterval(() => {
      if (document.visibilityState === 'visible' && !result.winner) {
        addPlaytime(5); // Add 5 seconds of active foreground play
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [result.winner, addPlaytime]);

  // Haptic feedback
  const triggerHaptic = () => {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      navigator.vibrate(15);
    }
  };

  // Reset board
  const handleReset = useCallback((broadcast: boolean = true) => {
    setBoard(Array(9).fill(null));
    setTurn('X');
    setResult({ winner: null, winningLine: null });
    setIsAiThinking(false);

    if (broadcast && gameMode === 'multiplayer' && isRoomActive) {
      realtimeTTT.sendReset();
    }
  }, [gameMode, isRoomActive]);

  // Switch human symbol
  const handleSelectSymbol = (symbol: Player) => {
    setHumanSymbol(symbol);
    handleReset(false);
  };

  // Robot AI Effect
  useEffect(() => {
    if (gameMode !== 'robot') return;
    if (result.winner !== null) return;
    if (turn !== robotSymbol) return;

    setIsAiThinking(true);
    const delay = difficulty === 'extreme' ? 350 : difficulty === 'hard' ? 450 : 300;

    const timer = setTimeout(() => {
      const bestMove = getAIMove(board, robotSymbol, difficulty);
      if (bestMove >= 0 && board[bestMove] === null) {
        const nextBoard = [...board];
        nextBoard[bestMove] = robotSymbol;
        const outcome = checkWinner(nextBoard);

        sounds.playPlaceTile();
        setBoard(nextBoard);
        setTurn(humanSymbol);
        setIsAiThinking(false);

        if (outcome.winner) {
          setResult(outcome);
          if (outcome.winner === robotSymbol) {
            setStats((prev) => ({ ...prev, losses: prev.losses + 1 }));
          } else if (outcome.winner === 'draw') {
            setStats((prev) => ({ ...prev, draws: prev.draws + 1 }));
          }
        }
      } else {
        setIsAiThinking(false);
      }
    }, delay);

    return () => clearTimeout(timer);
  }, [turn, board, gameMode, difficulty, humanSymbol, robotSymbol, result]);

  // Cleanup multiplayer channel on unmount
  useEffect(() => {
    return () => {
      realtimeTTT.disconnect();
    };
  }, []);

  // Handle incoming real-time multiplayer message
  const handleRemoteMessage = useCallback(
    (event: RoomSyncEvent) => {
      if (event.type === 'player_joined') {
        setMultiplayerStatus('connected');
        setOpponentName(event.senderName || 'Opponent');
        sounds.playComboBlast(2);
      } else if (event.type === 'room_sync') {
        if (event.boardState) setBoard(event.boardState);
        if (event.nextTurn) setTurn(event.nextTurn);
        if (event.senderName) setOpponentName(event.senderName);
        setMultiplayerStatus('connected');
      } else if (event.type === 'player_move') {
        if (event.cellIndex !== undefined) {
          sounds.playPlaceTile();
          setBoard((prev) => {
            const next = event.boardState ? [...event.boardState] : [...prev];
            if (!event.boardState) {
              next[event.cellIndex!] = event.senderSymbol;
            }
            const outcome = checkWinner(next);
            if (outcome.winner) {
              setResult(outcome);
              if (outcome.winner === event.senderSymbol) {
                setStats((s) => ({ ...s, losses: s.losses + 1 }));
              } else if (outcome.winner === 'draw') {
                setStats((s) => ({ ...s, draws: s.draws + 1 }));
              }
            }
            return next;
          });
          setTurn(event.nextTurn || (event.senderSymbol === 'X' ? 'O' : 'X'));
        }
      } else if (event.type === 'player_reset') {
        sounds.playPlaceTile();
        handleReset(false);
      } else if (event.type === 'player_leave') {
        setMultiplayerStatus('opponent_left');
        setErrorMessage(`${event.senderName || 'Opponent'} has left the match.`);
      }
    },
    [handleReset]
  );

  // Handle cell click by human
  const handleCellClick = (index: number) => {
    if (board[index] !== null) return;
    if (result.winner !== null) return;
    if (isAiThinking) return;

    // In multiplayer mode, enforce that it's strictly YOUR turn
    if (gameMode === 'multiplayer' && isRoomActive) {
      if (multiplayerStatus === 'waiting_for_friend') {
        setErrorMessage('Waiting for your friend to join the room before making a move.');
        return;
      }
      if (multiplayerStatus === 'connecting') {
        setErrorMessage('Still connecting to room. Please wait...');
        return;
      }
      if (turn !== humanSymbol) {
        setErrorMessage(`It is ${opponentName}'s turn (${turn}). Please wait!`);
        return;
      }
    }

    setErrorMessage(null);
    triggerHaptic();
    sounds.playPlaceTile();

    const nextBoard = [...board];
    nextBoard[index] = turn;
    const outcome = checkWinner(nextBoard);
    const nextTurn = turn === 'X' ? 'O' : 'X';

    setBoard(nextBoard);
    setTurn(nextTurn);

    // If multiplayer, immediately broadcast move to opponent
    if (gameMode === 'multiplayer' && isRoomActive) {
      realtimeTTT.sendMove(index, nextBoard, nextTurn);
    }

    if (outcome.winner) {
      setResult(outcome);
      if (outcome.winner === humanSymbol) {
        const pts = gameMode === 'multiplayer' ? 8 : difficulty === 'extreme' ? 10 : difficulty === 'hard' ? 7 : 5;
        setStats((prev) => ({ ...prev, wins: prev.wins + 1 }));
        awardPoints(pts, `Won Tic Tac Toe match!`);
        sounds.playComboBlast(3);
        try {
          confetti({ particleCount: 75, spread: 60, origin: { y: 0.6 } });
        } catch (e) {}
      } else if (outcome.winner === 'draw') {
        setStats((prev) => ({ ...prev, draws: prev.draws + 1 }));
      }
    }
  };

  // Host: Create Room
  const handleCreateRoom = () => {
    setErrorMessage(null);

    // Generate clean 6-character room code (readable, no confusing chars)
    const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
    let code = '';
    for (let i = 0; i < 6; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    setRoomCode(code);
    setIsRoomActive(true);
    setHumanSymbol('X'); // Host is always X
    setMultiplayerStatus('waiting_for_friend');
    handleReset(false);

    // Connect to Supabase Realtime channel with Presence
    const myName = user?.displayName || 'Host';
    realtimeTTT.connect({
      roomCode: code,
      role: 'host',
      symbol: 'X',
      name: myName,
      onConnected: (opponent) => {
        setMultiplayerStatus('connected');
        setOpponentName(opponent || 'Friend');
        sounds.playComboBlast(2);
        try {
          confetti({ particleCount: 50, spread: 50, origin: { y: 0.6 } });
        } catch (e) {}
      },
      onMessage: handleRemoteMessage,
      onOpponentLeft: (opponent) => {
        setMultiplayerStatus('opponent_left');
        setErrorMessage(`${opponent || 'Opponent'} has left the room.`);
      },
      onError: (err) => {
        setErrorMessage(err);
      },
    });
  };

  // Guest: Join Room
  const handleJoinRoom = () => {
    const cleanCode = joinInputCode.trim().toUpperCase();
    if (cleanCode.length !== 6) {
      setErrorMessage('Please enter a valid 6-character room code.');
      return;
    }
    setErrorMessage(null);

    setRoomCode(cleanCode);
    setIsRoomActive(true);
    setHumanSymbol('O'); // Guest is always O
    setMultiplayerStatus('connecting');
    handleReset(false);

    // Connect to Supabase Realtime channel with Presence
    const myName = user?.displayName || 'Guest';
    realtimeTTT.connect({
      roomCode: cleanCode,
      role: 'guest',
      symbol: 'O',
      name: myName,
      onConnected: (opponent) => {
        setMultiplayerStatus('connected');
        setOpponentName(opponent || 'Host');
        sounds.playComboBlast(2);
        try {
          confetti({ particleCount: 50, spread: 50, origin: { y: 0.6 } });
        } catch (e) {}
      },
      onMessage: handleRemoteMessage,
      onOpponentLeft: (opponent) => {
        setMultiplayerStatus('opponent_left');
        setErrorMessage(`${opponent || 'Host'} has left the room.`);
      },
      onError: (err) => {
        setErrorMessage(err);
        setMultiplayerStatus('idle');
        setIsRoomActive(false);
      },
    });
  };

  // Copy code to clipboard
  const handleCopyCode = () => {
    navigator.clipboard.writeText(roomCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Share link with room code
  const handleShareLink = () => {
    const url = `${window.location.origin}/tic-tac-toe?room=${roomCode}`;
    if (typeof navigator !== 'undefined' && navigator.share) {
      navigator
        .share({
          title: 'Play Tic Tac Toe with me on GameNest!',
          text: `Join my Tic Tac Toe room with code: ${roomCode}`,
          url: url,
        })
        .catch(() => handleCopyCode());
    } else {
      navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  // Leave active room
  const handleLeaveRoom = () => {
    realtimeTTT.disconnect();
    setIsRoomActive(false);
    setRoomCode('');
    setMultiplayerStatus('idle');
    handleReset(false);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-5 animate-fade-in">
      {/* Top Navigation Bar */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => {
            realtimeTTT.disconnect();
            navigate('/games');
          }}
          className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Games</span>
        </button>

        <div className="flex items-center gap-2">
          {/* Mode Switcher */}
          <div className="bg-slate-900 p-1 rounded-xl border border-slate-800 flex items-center gap-1">
            <button
              onClick={() => {
                realtimeTTT.disconnect();
                setGameMode('robot');
                setIsRoomActive(false);
                handleReset(false);
              }}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                gameMode === 'robot' ? 'bg-purple-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Bot className="w-3.5 h-3.5" />
              <span>Robot</span>
            </button>
            <button
              onClick={() => {
                setGameMode('multiplayer');
                handleReset(false);
              }}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                gameMode === 'multiplayer' ? 'bg-purple-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Online 2P</span>
            </button>
          </div>
        </div>
      </div>

      {/* Game Title & Stats Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-black text-white">Tic Tac Toe Pro</h1>
            <span className="px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-[10px] font-bold uppercase">
              {gameMode === 'robot' ? `${difficulty} AI` : 'Live Multiplayer'}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            {gameMode === 'robot'
              ? 'Play against the robot to earn verified reward points.'
              : 'Real-time live room synchronization with instant moves.'}
          </p>
        </div>

        {/* Score Counter */}
        <div className="flex items-center gap-3 bg-slate-950/80 px-4 py-2 rounded-xl border border-slate-800 text-xs">
          <div className="text-center">
            <span className="text-slate-400 block text-[10px]">WINS</span>
            <span className="font-extrabold text-emerald-400 text-sm">{stats.wins}</span>
          </div>
          <div className="w-px h-6 bg-slate-800" />
          <div className="text-center">
            <span className="text-slate-400 block text-[10px]">DRAWS</span>
            <span className="font-extrabold text-slate-300 text-sm">{stats.draws}</span>
          </div>
          <div className="w-px h-6 bg-slate-800" />
          <div className="text-center">
            <span className="text-slate-400 block text-[10px]">LOSSES</span>
            <span className="font-extrabold text-rose-400 text-sm">{stats.losses}</span>
          </div>
        </div>
      </div>

      {/* Robot Settings (When in Robot Mode) */}
      {gameMode === 'robot' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-900/60 p-3.5 rounded-2xl border border-slate-800">
          {/* Symbol Selector */}
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs text-slate-300 font-medium">Your Symbol:</span>
            <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800">
              <button
                onClick={() => handleSelectSymbol('X')}
                className={`w-10 h-8 rounded-lg font-black text-sm transition-all ${
                  humanSymbol === 'X' ? 'bg-purple-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                X
              </button>
              <button
                onClick={() => handleSelectSymbol('O')}
                className={`w-10 h-8 rounded-lg font-black text-sm transition-all ${
                  humanSymbol === 'O' ? 'bg-cyan-500 text-slate-950 shadow-md font-bold' : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                O
              </button>
            </div>
          </div>

          {/* Difficulty Selector */}
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs text-slate-300 font-medium">Robot Level:</span>
            <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
              {(['easy', 'hard', 'extreme'] as Difficulty[]).map((level) => (
                <button
                  key={level}
                  onClick={() => {
                    setDifficulty(level);
                    handleReset(false);
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold capitalize transition-all ${
                    difficulty === level
                      ? level === 'extreme'
                        ? 'bg-rose-600 text-white'
                        : 'bg-purple-600 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {level}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Multiplayer Room Creation / Join Panel (When in 2P Mode & No Active Room) */}
      {gameMode === 'multiplayer' && !isRoomActive && (
        <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-5 space-y-4">
          <div className="flex border-b border-slate-800 pb-3 gap-4">
            <button
              onClick={() => {
                setMultiplayerTab('create');
                setErrorMessage(null);
              }}
              className={`text-sm font-bold pb-1 transition-colors ${
                multiplayerTab === 'create' ? 'text-purple-400 border-b-2 border-purple-500' : 'text-slate-400'
              }`}
            >
              Create New Room
            </button>
            <button
              onClick={() => {
                setMultiplayerTab('join');
                setErrorMessage(null);
              }}
              className={`text-sm font-bold pb-1 transition-colors ${
                multiplayerTab === 'join' ? 'text-purple-400 border-b-2 border-purple-500' : 'text-slate-400'
              }`}
            >
              Join Room With Code
            </button>
          </div>

          {multiplayerTab === 'create' ? (
            <div className="space-y-3">
              <p className="text-xs text-slate-300">
                Click below to create a room. You will play as <strong>X</strong> and get a 6-character code to share with your friend on WhatsApp, phone, or browser.
              </p>
              <Button
                variant="electric"
                size="md"
                onClick={handleCreateRoom}
                leftIcon={<Zap className="w-4 h-4" />}
                className="w-full sm:w-auto font-bold"
              >
                Generate Room Code
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              <p className="text-xs text-slate-300">
                Enter the 6-character room code from your friend to join as <strong>O</strong>.
              </p>
              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  type="text"
                  maxLength={6}
                  value={joinInputCode}
                  onChange={(e) => setJoinInputCode(e.target.value.toUpperCase())}
                  placeholder="e.g. 7K9X2B"
                  className="min-h-[46px] px-4 rounded-xl bg-slate-950 border border-slate-700 text-center uppercase tracking-widest font-mono text-lg font-bold text-white focus:outline-none focus:border-cyan-400"
                />
                <Button variant="primary" size="md" onClick={handleJoinRoom}>
                  Join Room
                </Button>
              </div>
            </div>
          )}

          {errorMessage && (
            <p className="text-xs text-rose-400 bg-rose-500/10 p-2.5 rounded-xl border border-rose-500/20">
              ⚠️ {errorMessage}
            </p>
          )}
        </div>
      )}

      {/* Multiplayer Active Room Status Bar */}
      {gameMode === 'multiplayer' && isRoomActive && (
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3.5 bg-gradient-to-r from-purple-950/40 to-slate-900 rounded-2xl border border-purple-500/40 shadow-lg">
          <div className="flex items-center gap-3">
            <span className="text-xs text-slate-400">Room Code:</span>
            <span className="font-mono text-xl font-black text-cyan-400 tracking-widest bg-slate-950 px-3 py-1 rounded-lg border border-slate-800">
              {roomCode}
            </span>
            <span
              className={`text-[10px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1.5 ${
                multiplayerStatus === 'connected'
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
              }`}
            >
              <Radio className="w-3 h-3 animate-pulse" />
              <span>
                {multiplayerStatus === 'connected'
                  ? `Matched: ${opponentName}`
                  : multiplayerStatus === 'waiting_for_friend'
                  ? 'Waiting for Friend...'
                  : 'Connecting...'}
              </span>
            </span>
          </div>

          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="secondary"
              onClick={handleCopyCode}
              leftIcon={copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              className="text-xs"
            >
              {copied ? 'Copied!' : 'Copy Code'}
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={handleShareLink}
              leftIcon={<Share2 className="w-3.5 h-3.5" />}
              className="text-xs"
            >
              Share
            </Button>
            <Button size="sm" variant="danger" onClick={handleLeaveRoom} className="text-xs">
              Leave
            </Button>
          </div>
        </div>
      )}

      {/* Waiting for Friend Banner */}
      {gameMode === 'multiplayer' && isRoomActive && multiplayerStatus === 'waiting_for_friend' && (
        <div className="p-4 bg-gradient-to-r from-purple-950/60 to-slate-900 border border-purple-500/40 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <div className="flex items-center gap-2.5">
            <Loader2 className="w-5 h-5 text-cyan-400 animate-spin flex-shrink-0" />
            <div>
              <p className="text-sm font-bold text-white">Waiting for your friend to join...</p>
              <p className="text-xs text-slate-400">
                Share room code <span className="font-mono text-cyan-300 font-bold tracking-wider">{roomCode}</span> with them!
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="secondary"
              onClick={handleCopyCode}
              leftIcon={copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            >
              {copied ? 'Copied' : 'Copy'}
            </Button>
            <Button size="sm" variant="primary" onClick={handleShareLink} leftIcon={<Share2 className="w-3.5 h-3.5" />}>
              Share Link
            </Button>
          </div>
        </div>
      )}

      {/* Opponent Left Notice */}
      {gameMode === 'multiplayer' && isRoomActive && multiplayerStatus === 'opponent_left' && (
        <div className="p-4 bg-rose-500/10 border border-rose-500/30 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <div>
            <h4 className="text-sm font-bold text-rose-400">Opponent Left the Match</h4>
            <p className="text-xs text-slate-400 mt-0.5">The other player disconnected or closed their window.</p>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="primary" onClick={handleCreateRoom}>
              New Room
            </Button>
            <Button
              size="sm"
              variant="secondary"
              onClick={() => {
                realtimeTTT.disconnect();
                setGameMode('robot');
                setIsRoomActive(false);
                handleReset(false);
              }}
            >
              Play vs Robot
            </Button>
          </div>
        </div>
      )}

      {/* Error / Status Toast */}
      {errorMessage && (
        <div className="text-xs text-rose-400 bg-rose-500/10 p-2.5 rounded-xl border border-rose-500/20">
          ⚠️ {errorMessage}
        </div>
      )}

      {/* Turn & Status Indicator */}
      <div className="flex items-center justify-between px-2">
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">Current Turn:</span>
          <span
            className={`font-black text-sm px-2.5 py-0.5 rounded-lg ${
              turn === 'X' ? 'bg-purple-600/20 text-purple-400 border border-purple-500/40' : 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40'
            }`}
          >
            {gameMode === 'multiplayer' && isRoomActive && multiplayerStatus === 'waiting_for_friend'
              ? 'Waiting for Player...'
              : gameMode === 'multiplayer' && isRoomActive && multiplayerStatus === 'connecting'
              ? 'Connecting...'
              : turn === humanSymbol
              ? `Your Turn (${turn})`
              : gameMode === 'robot'
              ? `Robot (${turn})`
              : `${opponentName} (${turn})`}
          </span>
          {isAiThinking && (
            <span className="text-xs text-slate-400 animate-pulse flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              Thinking...
            </span>
          )}
        </div>

        <button
          onClick={() => handleReset(true)}
          className="flex items-center gap-1 text-xs text-slate-400 hover:text-white transition-colors p-1"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Board</span>
        </button>
      </div>

      {/* 3x3 Tic Tac Toe Grid */}
      <div className="relative w-full max-w-[340px] sm:max-w-[380px] mx-auto aspect-square p-3 sm:p-4 rounded-3xl bg-slate-900 border-2 border-slate-800 shadow-2xl">
        <div className="grid grid-cols-3 grid-rows-3 gap-2.5 sm:gap-3 w-full h-full">
          {board.map((cell, idx) => {
            const isWinningCell = result.winningLine?.includes(idx);
            return (
              <button
                key={idx}
                onClick={() => handleCellClick(idx)}
                disabled={cell !== null || result.winner !== null || isAiThinking}
                aria-label={`Cell ${idx + 1}: ${cell || 'Empty'}`}
                className={`relative flex items-center justify-center rounded-2xl transition-all duration-150 select-none ${
                  cell === null
                    ? 'bg-slate-950/80 hover:bg-slate-800/80 active:scale-95 border border-slate-800/80'
                    : isWinningCell
                    ? 'bg-emerald-500/20 border-2 border-emerald-400 shadow-lg shadow-emerald-500/30 animate-pulse'
                    : 'bg-slate-950 border border-slate-800'
                }`}
              >
                {cell === 'X' && (
                  <span className="text-4xl sm:text-5xl font-black bg-gradient-to-tr from-purple-500 to-pink-500 bg-clip-text text-transparent drop-shadow">
                    X
                  </span>
                )}
                {cell === 'O' && (
                  <span className="text-4xl sm:text-5xl font-black bg-gradient-to-tr from-cyan-400 to-blue-500 bg-clip-text text-transparent drop-shadow">
                    O
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Game Result Modal/Overlay */}
        {result.winner !== null && (
          <div className="absolute inset-2 sm:inset-3 rounded-2xl bg-slate-950/90 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center animate-fade-in z-20 space-y-3">
            {result.winner === 'draw' ? (
              <>
                <div className="w-14 h-14 rounded-full bg-slate-800 flex items-center justify-center text-slate-300 text-2xl">
                  🤝
                </div>
                <h3 className="text-xl sm:text-2xl font-black text-white">It's a Draw!</h3>
                <p className="text-xs text-slate-400 max-w-xs">A tightly fought match!</p>
              </>
            ) : result.winner === humanSymbol ? (
              <>
                <div className="w-14 h-14 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                  <Trophy className="w-7 h-7" />
                </div>
                <h3 className="text-xl sm:text-2xl font-black text-emerald-400">Victory! You Won!</h3>
                <p className="text-xs text-slate-300 flex items-center gap-1 font-semibold">
                  <Sparkles className="w-4 h-4 text-yellow-300" />
                  <span>Points Added to Your Wallet!</span>
                </p>
              </>
            ) : (
              <>
                <div className="w-14 h-14 rounded-full bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 text-2xl">
                  {gameMode === 'robot' ? '🤖' : '⚔️'}
                </div>
                <h3 className="text-xl sm:text-2xl font-black text-rose-400">
                  {gameMode === 'robot' ? 'Robot Takes the Round!' : `${opponentName} Won the Match!`}
                </h3>
              </>
            )}

            <div className="flex items-center gap-3 pt-2">
              <Button size="md" variant="primary" onClick={() => handleReset(true)} leftIcon={<RotateCcw className="w-4 h-4" />}>
                Play Again
              </Button>
              <Button size="md" variant="secondary" onClick={() => navigate('/games')}>
                All Games
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
