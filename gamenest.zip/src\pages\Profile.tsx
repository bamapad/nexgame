import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  User,
  Trophy,
  Coins,
  Shield,
  Edit2,
  LogOut,
  Sparkles,
  Gamepad2,
  Calendar,
  CheckCircle,
} from 'lucide-react';
import { useAuthStore } from '../stores/useAuthStore';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Modal } from '../components/ui/Modal';

export const Profile: React.FC = () => {
  const navigate = useNavigate();
  const { user, login, logout, updateProfile, allUsers } = useAuthStore();

  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editName, setEditName] = useState(user?.displayName || '');
  const [isSwitchUserOpen, setIsSwitchUserOpen] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (editName.trim()) {
      updateProfile({ displayName: editName.trim() });
      setIsEditModalOpen(false);
    }
  };

  const winRate =
    user && user.gamesPlayed > 0 ? Math.round((user.gamesWon / user.gamesPlayed) * 100) : 0;

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-fade-in">
      {/* Header Profile Card */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-purple-950/40 to-slate-900 border border-slate-800 p-5 sm:p-7 shadow-xl relative overflow-hidden">
        {/* Glow */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col sm:flex-row items-center sm:items-start gap-5 text-center sm:text-left">
          {/* Avatar */}
          <div className="relative">
            <img
              src={user?.avatarUrl || 'https://api.dicebear.com/7.x/bottts/svg?seed=guest'}
              alt={user?.displayName || 'Player'}
              className="w-24 h-24 rounded-2xl object-cover ring-2 ring-purple-500/50 shadow-2xl bg-slate-950"
            />
            {user?.isAdmin && (
              <span className="absolute -bottom-2 -right-2 px-2 py-0.5 rounded-md bg-rose-600 text-white text-[10px] font-black uppercase tracking-wider shadow">
                Admin
              </span>
            )}
          </div>

          {/* Details */}
          <div className="flex-1 space-y-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h1 className="text-2xl font-black text-white">{user?.displayName || 'Guest Player'}</h1>
                <p className="text-xs text-slate-400 font-mono mt-0.5">{user?.email || 'guest@gamenest.test'}</p>
              </div>

              <div className="flex items-center gap-2 justify-center">
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => {
                    setEditName(user?.displayName || '');
                    setIsEditModalOpen(true);
                  }}
                  leftIcon={<Edit2 className="w-3.5 h-3.5" />}
                  className="text-xs"
                >
                  Edit
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setIsSwitchUserOpen(true)}
                  className="text-xs text-purple-300"
                >
                  Switch User
                </Button>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-4 pt-2 text-xs text-slate-400">
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-500" />
                Joined {user ? new Date(user.createdAt).toLocaleDateString() : 'Today'}
              </span>
              <span className="flex items-center gap-1 text-yellow-300 font-semibold">
                <Coins className="w-3.5 h-3.5" />
                {user?.pointsBalance.toLocaleString()} points
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Gameplay Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 text-center">
          <Gamepad2 className="w-5 h-5 text-purple-400 mx-auto mb-1" />
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Played</span>
          <span className="text-2xl font-black text-white">{user?.gamesPlayed || 0}</span>
        </div>

        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 text-center">
          <Trophy className="w-5 h-5 text-emerald-400 mx-auto mb-1" />
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Victories</span>
          <span className="text-2xl font-black text-emerald-400">{user?.gamesWon || 0}</span>
        </div>

        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 text-center">
          <Sparkles className="w-5 h-5 text-cyan-400 mx-auto mb-1" />
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Win Rate</span>
          <span className="text-2xl font-black text-cyan-400">{winRate}%</span>
        </div>

        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 text-center">
          <Coins className="w-5 h-5 text-yellow-400 mx-auto mb-1" />
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Total Points</span>
          <span className="text-2xl font-black text-yellow-300">
            {user?.totalEarnedPoints.toLocaleString() || 0}
          </span>
        </div>
      </div>

      {/* Account Settings & Quick Navigation */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 divide-y divide-slate-800/80 overflow-hidden">
        <div className="p-4 flex items-center justify-between hover:bg-slate-800/30 transition-colors">
          <div>
            <h3 className="text-sm font-semibold text-white">Points Wallet & Transactions</h3>
            <p className="text-xs text-slate-400">View real-time balance and gameplay earnings</p>
          </div>
          <Button size="sm" variant="secondary" onClick={() => navigate('/wallet')}>
            Open Wallet
          </Button>
        </div>

        <div className="p-4 flex items-center justify-between hover:bg-slate-800/30 transition-colors">
          <div>
            <h3 className="text-sm font-semibold text-white">Redeem Rewards</h3>
            <p className="text-xs text-slate-400">Request ₹100 withdrawal to your UPI ID</p>
          </div>
          <Button size="sm" variant="electric" onClick={() => navigate('/redeem')}>
            Redeem
          </Button>
        </div>

        {user?.isAdmin && user.email?.toLowerCase() === 'bishawjitbadsha@gmail.com' && (
          <div className="p-4 flex items-center justify-between bg-rose-950/20 hover:bg-rose-950/30 transition-colors">
            <div>
              <h3 className="text-sm font-semibold text-rose-300 flex items-center gap-1.5">
                <Shield className="w-4 h-4 text-rose-400" />
                <span>Admin Management Panel</span>
              </h3>
              <p className="text-xs text-slate-400">Review withdrawals, users, and reward rules</p>
            </div>
            <Button size="sm" variant="danger" onClick={() => navigate('/admin')}>
              Admin Panel
            </Button>
          </div>
        )}
      </div>

      {/* Edit Profile Modal */}
      <Modal isOpen={isEditModalOpen} onClose={() => setIsEditModalOpen(false)} title="Edit Profile">
        <form onSubmit={handleSaveProfile} className="space-y-4">
          <Input
            label="Display Name"
            value={editName}
            onChange={(e) => setEditName(e.target.value)}
            placeholder="Your gamer tag"
          />
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="ghost" size="md" onClick={() => setIsEditModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" size="md" type="submit">
              Save Changes
            </Button>
          </div>
        </form>
      </Modal>

      {/* Switch Demo User Modal (Helpful for testing 2-player multiplayer & Admin) */}
      <Modal
        isOpen={isSwitchUserOpen}
        onClose={() => setIsSwitchUserOpen(false)}
        title="Switch Account (Testing Mode)"
      >
        <div className="space-y-3">
          <p className="text-xs text-slate-400">
            Select one of the simulated accounts below to quickly test as a standard player, a high-earner with 10,000+ points, or the system administrator:
          </p>
          <div className="space-y-2">
            {allUsers.map((u) => (
              <button
                key={u.id}
                onClick={() => {
                  login(u.email, u.displayName);
                  setIsSwitchUserOpen(false);
                }}
                className={`w-full p-3 rounded-xl border flex items-center justify-between text-left transition-all ${
                  user?.id === u.id
                    ? 'bg-purple-950/60 border-purple-500 text-white'
                    : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <img src={u.avatarUrl} alt={u.displayName} className="w-9 h-9 rounded-full object-cover" />
                  <div>
                    <span className="font-bold text-sm block">{u.displayName}</span>
                    <span className="text-xs text-slate-500 font-mono">{u.email}</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-xs font-bold text-yellow-400">{u.pointsBalance} pts</span>
                  {u.isAdmin && <span className="block text-[10px] text-rose-400 font-extrabold uppercase">Admin</span>}
                </div>
              </button>
            ))}
          </div>
        </div>
      </Modal>
    </div>
  );
};
