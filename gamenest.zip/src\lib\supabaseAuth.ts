import { supabase, isSupabaseConfigured } from './supabase';
import { UserProfile } from '../types';

export const ADMIN_EMAIL = 'bishawjitbadsha@gmail.com';

/**
 * Initiates Google OAuth Sign-In (Official Google Identity flow)
 * Only requests standard email & profile scope with zero extra permissions
 */
export async function signInWithGoogle() {
  if (!isSupabaseConfigured || !supabase) {
    throw new Error('Supabase is not configured. Please check your .env settings.');
  }

  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: 'google',
    options: {
      redirectTo: window.location.origin,
      queryParams: {
        access_type: 'offline',
        prompt: 'select_account',
      },
    },
  });

  if (error) throw error;
  return data;
}

/**
 * Signs out the current user
 */
export async function signOut() {
  if (!isSupabaseConfigured || !supabase) return;
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

/**
 * Fetches the user profile from public.profiles
 */
export async function fetchUserProfile(userId: string): Promise<UserProfile | null> {
  if (!isSupabaseConfigured || !supabase) return null;

  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single();

  if (error || !data) return null;

  const isAdmin = data.email?.toLowerCase() === ADMIN_EMAIL.toLowerCase();

  return {
    id: data.id,
    displayName: data.display_name,
    email: data.email,
    avatarUrl: data.avatar_url || `https://api.dicebear.com/7.x/bottts/svg?seed=${data.id}`,
    pointsBalance: Number(data.points_balance),
    totalEarnedPoints: Number(data.total_earned_points),
    totalSpentPoints: Number(data.total_spent_points),
    isAdmin,
    gamesPlayed: Number(data.games_played),
    gamesWon: Number(data.games_won),
    createdAt: data.created_at,
    ipAddress: data.ip_address || '127.0.0.1',
    playtimeSeconds: Number(data.playtime_seconds || 0),
  };
}
