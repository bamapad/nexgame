-- ============================================================================
-- GAMENEST UPDATE: ADMIN ACCESS RESTRICTION, PLAYTIME & 0 STARTER POINTS
-- Run this in Supabase SQL Editor to apply the latest security updates
-- ============================================================================

-- 1. Add IP Address and Playtime tracking columns to profiles
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS ip_address TEXT DEFAULT '127.0.0.1',
ADD COLUMN IF NOT EXISTS playtime_seconds BIGINT DEFAULT 0 CHECK (playtime_seconds >= 0);

-- 2. Update default points to 0 on profiles
ALTER TABLE public.profiles 
ALTER COLUMN points_balance SET DEFAULT 0,
ALTER COLUMN total_earned_points SET DEFAULT 0;

-- 3. Reset existing admin flags and grant admin ONLY to bishawjitbadsha@gmail.com
UPDATE public.profiles
SET is_admin = (LOWER(email) = 'bishawjitbadsha@gmail.com');

-- 4. Update the is_admin() security function to check ONLY bishawjitbadsha@gmail.com
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = auth.uid() 
          AND LOWER(email) = 'bishawjitbadsha@gmail.com'
          AND is_admin = TRUE
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 5. Update automatic profile creation trigger for Google Auth:
-- - Initial points balance is strictly 0
-- - Admin role granted ONLY if email is bishawjitbadsha@gmail.com
-- - Saves IP address and initializes playtime to 0
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
    is_owner BOOLEAN;
BEGIN
    is_owner := (LOWER(NEW.email) = 'bishawjitbadsha@gmail.com');

    INSERT INTO public.profiles (
        id, 
        display_name, 
        email, 
        avatar_url, 
        points_balance, 
        total_earned_points, 
        is_admin,
        ip_address,
        playtime_seconds
    )
    VALUES (
        NEW.id,
        COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1)),
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'avatar_url', 'https://api.dicebear.com/7.x/bottts/svg?seed=' || NEW.id),
        0, -- Initial points strictly 0 upon signup
        0,
        is_owner,
        COALESCE(inet_client_addr()::TEXT, '127.0.0.1'),
        0  -- Initial playtime is 0 (48 hours minimum required before redemption)
    )
    ON CONFLICT (id) DO UPDATE SET
        display_name = EXCLUDED.display_name,
        avatar_url = EXCLUDED.avatar_url,
        is_admin = is_owner;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recreate trigger
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 6. Helper function for admin to reset user reward points back to 0
CREATE OR REPLACE FUNCTION public.admin_reset_user_points(target_user_id UUID)
RETURNS VOID AS $$
BEGIN
    -- Verify caller is bishawjitbadsha@gmail.com
    IF NOT public.is_admin() THEN
        RAISE EXCEPTION 'Unauthorized: Only bishawjitbadsha@gmail.com can reset reward points.';
    END IF;

    -- Record in points_ledger before resetting
    INSERT INTO public.points_ledger (user_id, amount, type, description, balance_after)
    SELECT target_user_id, -points_balance, 'admin_adjustment', 'Points reset to 0 by Administrator', 0
    FROM public.profiles
    WHERE id = target_user_id;

    -- Reset balance to 0
    UPDATE public.profiles
    SET points_balance = 0
    WHERE id = target_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
