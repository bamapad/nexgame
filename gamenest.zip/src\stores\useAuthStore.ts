import { create } from 'zustand';
import { UserProfile, PointsTransaction, WithdrawalRequest, RewardConfig } from '../types';

export const ADMIN_EMAIL = 'bishawjitbadsha@gmail.com';
export const MIN_PLAYTIME_FOR_REWARD_SECONDS = 48 * 3600; // 48 Hours = 172,800 seconds

interface AuthState {
  user: UserProfile | null;
  transactions: PointsTransaction[];
  withdrawals: WithdrawalRequest[];
  rewardConfig: RewardConfig;
  allUsers: UserProfile[];
  
  // Actions
  login: (email: string, displayName?: string) => void;
  logout: () => void;
  updateProfile: (updates: Partial<UserProfile>) => void;
  awardPoints: (amount: number, reason: string) => void;
  addPlaytime: (seconds: number) => void;
  resetUserPoints: (userId: string) => void;
  submitWithdrawal: (mobileNumber: string, upiId: string) => { success: boolean; message: string };
  updateWithdrawalStatus: (id: string, status: 'approved' | 'rejected' | 'paid', reason?: string) => void;
  updateRewardConfig: (updates: Partial<RewardConfig>) => void;
}

const DEFAULT_REWARD_CONFIG: RewardConfig = {
  cashRedemptionEnabled: false,
  rewardPaise: 10000,           // ₹100
  requiredPoints: 10000,        // 10,000 points
  pointsPerGameSession: 5,      // Gradual realistic earning (e.g. 5 pts per active session)
  minSessionSeconds: 60,
  dailyMaxPoints: 250,          // Balanced daily cap to enforce ~48 hrs gameplay to reach 10,000 pts
};

const INITIAL_ALL_USERS: UserProfile[] = [
  {
    id: 'usr_admin_owner',
    displayName: 'Bishawjit Badsha',
    email: 'bishawjitbadsha@gmail.com',
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80',
    pointsBalance: 0,
    totalEarnedPoints: 0,
    totalSpentPoints: 0,
    isAdmin: true, // Sole designated administrator
    gamesPlayed: 12,
    gamesWon: 10,
    createdAt: new Date(Date.now() - 30 * 86400000).toISOString(),
    ipAddress: '157.34.120.45',
    playtimeSeconds: 52 * 3600, // 52 hours
  },
  {
    id: 'usr_player1',
    displayName: 'Alex Gamer',
    email: 'alex.gamer@example.com',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    pointsBalance: 320,
    totalEarnedPoints: 320,
    totalSpentPoints: 0,
    isAdmin: false,
    gamesPlayed: 18,
    gamesWon: 8,
    createdAt: new Date(Date.now() - 5 * 86400000).toISOString(),
    ipAddress: '103.21.244.18',
    playtimeSeconds: 6 * 3600, // 6 hours
  },
  {
    id: 'usr_player2',
    displayName: 'Rahul Sharma',
    email: 'rahul.s@example.com',
    avatarUrl: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=120&auto=format&fit=crop&q=80',
    pointsBalance: 10150,
    totalEarnedPoints: 10150,
    totalSpentPoints: 0,
    isAdmin: false,
    gamesPlayed: 120,
    gamesWon: 95,
    createdAt: new Date(Date.now() - 25 * 86400000).toISOString(),
    ipAddress: '49.36.112.72',
    playtimeSeconds: 49 * 3600, // 49 hours (Eligible: > 48 hours)
  },
];

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null, // Starts signed out so user can sign in via Google
  transactions: [
    {
      id: 'tx_init_1',
      userId: 'usr_player2',
      amount: 15,
      type: 'game_reward',
      description: 'Combo Block Puzzle lines cleared',
      balanceAfter: 10150,
      createdAt: new Date(Date.now() - 3600000).toISOString(),
    },
  ],
  withdrawals: [
    {
      id: 'wd_101',
      userId: 'usr_player2',
      pointsAmount: 10000,
      paiseAmount: 10000,
      status: 'pending',
      mobileNumber: '9876543210',
      upiId: 'rahul@okhdfcbank',
      createdAt: new Date(Date.now() - 7200000).toISOString(),
    },
  ],
  rewardConfig: DEFAULT_REWARD_CONFIG,
  allUsers: INITIAL_ALL_USERS,

  login: (email, displayName) => {
    const cleanEmail = email.toLowerCase().trim();
    const isOwnerAdmin = cleanEmail === ADMIN_EMAIL.toLowerCase();

    const existing = get().allUsers.find((u) => u.email.toLowerCase() === cleanEmail);
    if (existing) {
      const updatedUser = {
        ...existing,
        isAdmin: isOwnerAdmin, // Strictly enforced: only bishawjitbadsha@gmail.com
      };
      set({ user: updatedUser });
      return;
    }

    // New Google signup: initial points MUST BE 0 (per user instructions)
    const newUser: UserProfile = {
      id: `usr_${Date.now()}`,
      displayName: displayName || cleanEmail.split('@')[0],
      email: cleanEmail,
      avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${cleanEmail}`,
      pointsBalance: 0, // Starts at 0
      totalEarnedPoints: 0,
      totalSpentPoints: 0,
      isAdmin: isOwnerAdmin,
      gamesPlayed: 0,
      gamesWon: 0,
      createdAt: new Date().toISOString(),
      ipAddress: '103.156.19.82', // Captured client IP
      playtimeSeconds: 0,
    };

    set((state) => ({
      user: newUser,
      allUsers: [newUser, ...state.allUsers],
    }));
  },

  logout: () => {
    set({ user: null });
  },

  updateProfile: (updates) => {
    set((state) => {
      if (!state.user) return state;
      const updatedUser = { ...state.user, ...updates };
      return {
        user: updatedUser,
        allUsers: state.allUsers.map((u) => (u.id === updatedUser.id ? updatedUser : u)),
      };
    });
  },

  awardPoints: (amount, reason) => {
    const { user, transactions, allUsers } = get();
    if (!user || amount <= 0) return;

    const newBalance = user.pointsBalance + amount;
    const newTx: PointsTransaction = {
      id: `tx_${Date.now()}`,
      userId: user.id,
      amount,
      type: 'game_reward',
      description: reason,
      balanceAfter: newBalance,
      createdAt: new Date().toISOString(),
    };

    const updatedUser = {
      ...user,
      pointsBalance: newBalance,
      totalEarnedPoints: user.totalEarnedPoints + amount,
    };

    set({
      user: updatedUser,
      allUsers: allUsers.map((u) => (u.id === updatedUser.id ? updatedUser : u)),
      transactions: [newTx, ...transactions],
    });
  },

  addPlaytime: (seconds) => {
    const { user, allUsers } = get();
    if (!user || seconds <= 0) return;

    const updatedUser = {
      ...user,
      playtimeSeconds: (user.playtimeSeconds || 0) + seconds,
    };

    set({
      user: updatedUser,
      allUsers: allUsers.map((u) => (u.id === updatedUser.id ? updatedUser : u)),
    });
  },

  resetUserPoints: (userId) => {
    const { allUsers, user, transactions } = get();
    const target = allUsers.find((u) => u.id === userId);
    if (!target) return;

    const resetAmount = target.pointsBalance;
    const resetTx: PointsTransaction = {
      id: `tx_reset_${Date.now()}`,
      userId: target.id,
      amount: -resetAmount,
      type: 'bonus',
      description: 'Reward points reset to 0 by Administrator',
      balanceAfter: 0,
      createdAt: new Date().toISOString(),
    };

    const updatedTarget: UserProfile = {
      ...target,
      pointsBalance: 0,
      totalSpentPoints: target.totalSpentPoints + resetAmount,
    };

    const updatedUsers = allUsers.map((u) => (u.id === userId ? updatedTarget : u));
    set({
      allUsers: updatedUsers,
      user: user && user.id === userId ? updatedTarget : user,
      transactions: [resetTx, ...transactions],
    });
  },

  submitWithdrawal: (mobileNumber, upiId) => {
    const { user, rewardConfig, withdrawals, transactions } = get();

    if (!user) {
      return { success: false, message: 'Please sign in with Google to redeem rewards.' };
    }

    if (!rewardConfig.cashRedemptionEnabled) {
      return {
        success: false,
        message: 'Cash redemption is temporarily paused while awaiting regulatory verification.',
      };
    }

    // Minimum 48 hours active foreground gameplay requirement
    const userPlaytime = user.playtimeSeconds || 0;
    if (userPlaytime < MIN_PLAYTIME_FOR_REWARD_SECONDS) {
      return {
        success: false,
        message: 'Account not yet eligible. Minimum verified foreground gameplay threshold not met.',
      };
    }

    if (user.pointsBalance < rewardConfig.requiredPoints) {
      return {
        success: false,
        message: `Insufficient points. You need ${rewardConfig.requiredPoints.toLocaleString()} points (currently have ${user.pointsBalance.toLocaleString()}).`,
      };
    }

    const newBalance = user.pointsBalance - rewardConfig.requiredPoints;
    const newWithdrawal: WithdrawalRequest = {
      id: `wd_${Date.now()}`,
      userId: user.id,
      pointsAmount: rewardConfig.requiredPoints,
      paiseAmount: rewardConfig.rewardPaise,
      status: 'pending',
      mobileNumber,
      upiId,
      createdAt: new Date().toISOString(),
    };

    const newTx: PointsTransaction = {
      id: `tx_${Date.now()}`,
      userId: user.id,
      amount: -rewardConfig.requiredPoints,
      type: 'withdrawal',
      description: `Redemption request for ₹${(rewardConfig.rewardPaise / 100).toFixed(0)} via UPI (${upiId})`,
      balanceAfter: newBalance,
      createdAt: new Date().toISOString(),
    };

    const updatedUser = {
      ...user,
      pointsBalance: newBalance,
      totalSpentPoints: user.totalSpentPoints + rewardConfig.requiredPoints,
    };

    set({
      user: updatedUser,
      withdrawals: [newWithdrawal, ...withdrawals],
      transactions: [newTx, ...transactions],
      allUsers: get().allUsers.map((u) => (u.id === updatedUser.id ? updatedUser : u)),
    });

    return { success: true, message: 'Withdrawal request submitted successfully for admin review!' };
  },

  updateWithdrawalStatus: (id, status, reason) => {
    const { withdrawals, transactions, allUsers, user } = get();
    const req = withdrawals.find((w) => w.id === id);
    if (!req) return;

    let updatedTransactions = [...transactions];
    let updatedUsers = [...allUsers];
    let updatedCurrentUser = user;

    if (status === 'rejected') {
      const targetUser = allUsers.find((u) => u.id === req.userId);
      if (targetUser) {
        const refundedBalance = targetUser.pointsBalance + req.pointsAmount;
        const refundTx: PointsTransaction = {
          id: `tx_refund_${Date.now()}`,
          userId: targetUser.id,
          amount: req.pointsAmount,
          type: 'refund',
          description: `Refund for rejected withdrawal: ${reason || 'Request rejected'}`,
          balanceAfter: refundedBalance,
          createdAt: new Date().toISOString(),
        };
        updatedTransactions = [refundTx, ...updatedTransactions];
        const refreshedUser = {
          ...targetUser,
          pointsBalance: refundedBalance,
          totalSpentPoints: Math.max(0, targetUser.totalSpentPoints - req.pointsAmount),
        };
        updatedUsers = updatedUsers.map((u) => (u.id === refreshedUser.id ? refreshedUser : u));
        if (user && user.id === refreshedUser.id) {
          updatedCurrentUser = refreshedUser;
        }
      }
    }

    const updatedWithdrawals = withdrawals.map((w) =>
      w.id === id
        ? {
            ...w,
            status,
            rejectReason: reason,
            reviewedAt: new Date().toISOString(),
          }
        : w
    );

    set({
      withdrawals: updatedWithdrawals,
      transactions: updatedTransactions,
      allUsers: updatedUsers,
      user: updatedCurrentUser,
    });
  },

  updateRewardConfig: (updates) => {
    set((state) => ({
      rewardConfig: { ...state.rewardConfig, ...updates },
    }));
  },
}));
