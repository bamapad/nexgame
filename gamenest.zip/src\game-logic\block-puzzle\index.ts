export const GRID_SIZE = 8; // 8x8 optimal for mobile Android screens

export type Grid = (string | null)[][]; // cell holds color string or null

export interface BlockShape {
  id: string;
  name: string;
  matrix: number[][]; // 2D array of 0 and 1
  color: string;
}

export const SHAPES: BlockShape[] = [
  // 1x1 Dot
  {
    id: 'dot_1',
    name: 'Dot',
    matrix: [[1]],
    color: '#f59e0b', // Amber
  },
  // 2x1 & 1x2 Dominoes
  {
    id: 'h_2',
    name: '2-Horizontal',
    matrix: [[1, 1]],
    color: '#06b6d4', // Cyan
  },
  {
    id: 'v_2',
    name: '2-Vertical',
    matrix: [[1], [1]],
    color: '#06b6d4',
  },
  // 3x1 & 1x3
  {
    id: 'h_3',
    name: '3-Horizontal',
    matrix: [[1, 1, 1]],
    color: '#3b82f6', // Blue
  },
  {
    id: 'v_3',
    name: '3-Vertical',
    matrix: [[1], [1], [1]],
    color: '#3b82f6',
  },
  // 4x1 & 1x4
  {
    id: 'h_4',
    name: '4-Horizontal',
    matrix: [[1, 1, 1, 1]],
    color: '#8b5cf6', // Purple
  },
  {
    id: 'v_4',
    name: '4-Vertical',
    matrix: [[1], [1], [1], [1]],
    color: '#8b5cf6',
  },
  // 2x2 Square
  {
    id: 'sq_2',
    name: 'Square',
    matrix: [
      [1, 1],
      [1, 1],
    ],
    color: '#10b981', // Emerald
  },
  // 3x3 Square
  {
    id: 'sq_3',
    name: 'Big Square',
    matrix: [
      [1, 1, 1],
      [1, 1, 1],
      [1, 1, 1],
    ],
    color: '#f43f5e', // Rose
  },
  // L-Shapes
  {
    id: 'l_corner',
    name: 'Corner',
    matrix: [
      [1, 0],
      [1, 1],
    ],
    color: '#ec4899', // Pink
  },
  {
    id: 'l_3x2',
    name: 'L-Shape',
    matrix: [
      [1, 0],
      [1, 0],
      [1, 1],
    ],
    color: '#a855f7', // Violet
  },
  // T-Shape
  {
    id: 't_shape',
    name: 'T-Shape',
    matrix: [
      [1, 1, 1],
      [0, 1, 0],
    ],
    color: '#eab308', // Yellow
  },
];

/**
 * Creates an empty 8x8 grid
 */
export function createEmptyGrid(): Grid {
  return Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(null));
}

/**
 * Validates if shape fits on the grid without overlapping or exceeding bounds
 */
export function canPlacePiece(grid: Grid, shape: BlockShape, startRow: number, startCol: number): boolean {
  const numRows = shape.matrix.length;
  const numCols = shape.matrix[0].length;

  for (let r = 0; r < numRows; r++) {
    for (let c = 0; c < numCols; c++) {
      if (shape.matrix[r][c] === 1) {
        const targetR = startRow + r;
        const targetC = startCol + c;

        // Out of bounds
        if (targetR < 0 || targetR >= GRID_SIZE || targetC < 0 || targetC >= GRID_SIZE) {
          return false;
        }

        // Cell already occupied
        if (grid[targetR][targetC] !== null) {
          return false;
        }
      }
    }
  }

  return true;
}

/**
 * Places shape onto the grid and returns new grid
 */
export function placePiece(grid: Grid, shape: BlockShape, startRow: number, startCol: number): Grid {
  const newGrid = grid.map((row) => [...row]);
  const numRows = shape.matrix.length;
  const numCols = shape.matrix[0].length;

  for (let r = 0; r < numRows; r++) {
    for (let c = 0; c < numCols; c++) {
      if (shape.matrix[r][c] === 1) {
        newGrid[startRow + r][startCol + c] = shape.color;
      }
    }
  }

  return newGrid;
}

export interface LineClearResult {
  newGrid: Grid;
  clearedRows: number[];
  clearedCols: number[];
  linesCleared: number;
  pointsEarned: number;
  comboMultiplier: number;
}

/**
 * Scans for complete rows & columns, clears them, and calculates score
 */
export function checkAndClearLines(grid: Grid, currentCombo: number = 0): LineClearResult {
  const rowsToClear: number[] = [];
  const colsToClear: number[] = [];

  // Check rows
  for (let r = 0; r < GRID_SIZE; r++) {
    if (grid[r].every((cell) => cell !== null)) {
      rowsToClear.push(r);
    }
  }

  // Check columns
  for (let c = 0; c < GRID_SIZE; c++) {
    let colFull = true;
    for (let r = 0; r < GRID_SIZE; r++) {
      if (grid[r][c] === null) {
        colFull = false;
        break;
      }
    }
    if (colFull) {
      colsToClear.push(c);
    }
  }

  const linesCleared = rowsToClear.length + colsToClear.length;

  if (linesCleared === 0) {
    return {
      newGrid: grid,
      clearedRows: [],
      clearedCols: [],
      linesCleared: 0,
      pointsEarned: 0,
      comboMultiplier: 0,
    };
  }

  // Create cleared grid
  const newGrid = grid.map((row) => [...row]);

  // Clear completed rows
  for (const r of rowsToClear) {
    for (let c = 0; c < GRID_SIZE; c++) {
      newGrid[r][c] = null;
    }
  }

  // Clear completed columns
  for (const c of colsToClear) {
    for (let r = 0; r < GRID_SIZE; r++) {
      newGrid[r][c] = null;
    }
  }

  // Scoring formula: linesCleared * 100 * comboMultiplier
  const comboMultiplier = currentCombo + linesCleared;
  const pointsEarned = linesCleared * 100 * comboMultiplier;

  return {
    newGrid,
    clearedRows: rowsToClear,
    clearedCols: colsToClear,
    linesCleared,
    pointsEarned,
    comboMultiplier,
  };
}

/**
 * Checks if at least one piece can be placed anywhere on the grid
 */
export function hasValidMovesRemaining(grid: Grid, pieces: BlockShape[]): boolean {
  for (const piece of pieces) {
    for (let r = 0; r < GRID_SIZE; r++) {
      for (let c = 0; c < GRID_SIZE; c++) {
        if (canPlacePiece(grid, piece, r, c)) {
          return true;
        }
      }
    }
  }
  return false;
}

/**
 * Generates a batch of 3 random shapes
 */
export function getRandomShapeBatch(): BlockShape[] {
  const result: BlockShape[] = [];
  for (let i = 0; i < 3; i++) {
    const randomIdx = Math.floor(Math.random() * SHAPES.length);
    result.push({ ...SHAPES[randomIdx], id: `${SHAPES[randomIdx].id}_${Date.now()}_${i}` });
  }
  return result;
}
