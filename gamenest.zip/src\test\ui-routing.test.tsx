import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import React from 'react';
import { MemoryRouter } from 'react-router-dom';
import { Home } from '../pages/Home';
import { Games } from '../pages/Games';
import { Help } from '../pages/Help';
import { Privacy } from '../pages/Privacy';
import { Terms } from '../pages/Terms';
import { AdminLogin } from '../pages/AdminLogin';

describe('Phase 1 UI Screens and Navigation', () => {
  it('renders Home screen with header, search, and sections', () => {
    render(
      <MemoryRouter>
        <Home />
      </MemoryRouter>
    );

    expect(screen.getByText(/Reward Points Balance/i)).toBeInTheDocument();
    expect(screen.getByText(/Combo Block Puzzle & Tic Tac Toe Online/i)).toBeInTheDocument();
    expect(screen.getByText(/Popular Games/i)).toBeInTheDocument();
    expect(screen.getByText(/Play Tic Tac Toe With Friends/i)).toBeInTheDocument();
    expect(screen.getByText(/Coming Soon to GameNest/i)).toBeInTheDocument();
  });

  it('renders All Games screen with search and filters', () => {
    render(
      <MemoryRouter>
        <Games />
      </MemoryRouter>
    );

    expect(screen.getByRole('heading', { name: /All Games/i })).toBeInTheDocument();
    expect(screen.getByPlaceholderText(/Search by title or category.../i)).toBeInTheDocument();
  });

  it('renders Help FAQ accordion with gameplay and rewards info', () => {
    render(
      <MemoryRouter>
        <Help />
      </MemoryRouter>
    );

    expect(screen.getByText(/Help & Frequently Asked Questions/i)).toBeInTheDocument();
    expect(screen.getByText(/How do I play Tic Tac Toe with a friend\?/i)).toBeInTheDocument();
    expect(screen.getByText(/How do I earn GameNest points\?/i)).toBeInTheDocument();
  });

  it('renders Privacy Policy with RLS and data protection disclosures', () => {
    render(
      <MemoryRouter>
        <Privacy />
      </MemoryRouter>
    );

    expect(screen.getByRole('heading', { name: /Privacy Policy/i })).toBeInTheDocument();
    expect(screen.getAllByText(/Row Level Security/i).length).toBeGreaterThan(0);
  });

  it('renders Terms and Conditions with fair play rules', () => {
    render(
      <MemoryRouter>
        <Terms />
      </MemoryRouter>
    );

    expect(screen.getByRole('heading', { name: /Terms and Conditions/i })).toBeInTheDocument();
    expect(screen.getByText(/Casual Entertainment Only/i)).toBeInTheDocument();
  });

  it('renders Admin Login screen with security notice', () => {
    render(
      <MemoryRouter>
        <AdminLogin />
      </MemoryRouter>
    );

    expect(screen.getByRole('heading', { name: /Administrator Portal/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Authenticate Admin/i })).toBeInTheDocument();
  });
});
