import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/layout/Layout';
import { Home } from './pages/Home';
import { Games } from './pages/Games';
import { TicTacToe } from './pages/TicTacToe';
import { BlockPuzzle } from './pages/BlockPuzzle';
import { FruitCrash } from './pages/FruitCrash';
import { Wallet } from './pages/Wallet';
import { Redeem } from './pages/Redeem';
import { Profile } from './pages/Profile';
import { Help } from './pages/Help';
import { Privacy } from './pages/Privacy';
import { Terms } from './pages/Terms';
import { AdminLogin } from './pages/AdminLogin';
import { AdminDashboard } from './pages/admin/AdminDashboard';

export const App: React.FC = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="games" element={<Games />} />
          <Route path="tic-tac-toe" element={<TicTacToe />} />
          <Route path="block-puzzle" element={<BlockPuzzle />} />
          <Route path="fruit-crash" element={<FruitCrash />} />
          <Route path="wallet" element={<Wallet />} />
          <Route path="redeem" element={<Redeem />} />
          <Route path="profile" element={<Profile />} />
          <Route path="help" element={<Help />} />
          <Route path="privacy" element={<Privacy />} />
          <Route path="terms" element={<Terms />} />
          <Route path="admin/login" element={<AdminLogin />} />
          <Route path="admin" element={<AdminDashboard />} />
          {/* Catch-all route redirects to Home */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
};

export default App;
