import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, Gamepad2, Wallet, User } from 'lucide-react';
import { useAuthStore } from '../../stores/useAuthStore';

export const MobileNav: React.FC = () => {
  const { user } = useAuthStore();

  const navItems = [
    { to: '/', label: 'Home', icon: Home },
    { to: '/games', label: 'Games', icon: Gamepad2 },
    { to: '/wallet', label: 'Wallet', icon: Wallet },
    { to: '/profile', label: 'Profile', icon: User },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#0b0f19]/95 backdrop-blur-xl border-t border-slate-800/90 px-2 py-1 safe-area-pb">
      <div className="flex items-center justify-around max-w-md mx-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              className={({ isActive }) =>
                `flex flex-col items-center justify-center min-w-[64px] min-h-[52px] py-1 rounded-xl transition-all duration-150 ${
                  isActive
                    ? 'text-purple-400 font-bold scale-105'
                    : 'text-slate-400 hover:text-slate-200'
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <div
                    className={`relative p-1 rounded-xl transition-colors ${
                      isActive ? 'bg-purple-500/15 text-purple-400 shadow-sm shadow-purple-500/20' : ''
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    {item.label === 'Wallet' && user && user.pointsBalance > 0 && (
                      <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-yellow-400 rounded-full animate-ping" />
                    )}
                  </div>
                  <span className="text-[11px] mt-0.5 tracking-tight font-medium">{item.label}</span>
                </>
              )}
            </NavLink>
          );
        })}
      </div>
    </nav>
  );
};
