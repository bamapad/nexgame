import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Star, Users, Play, Clock, Sparkles } from 'lucide-react';
import { Game } from '../../types';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { OriginalGameArt } from './OriginalGameArt';

interface GameCardProps {
  game: Game;
  variant?: 'standard' | 'compact' | 'featured';
}

export const GameCard: React.FC<GameCardProps> = ({ game, variant = 'standard' }) => {
  const navigate = useNavigate();
  const isAvailable = game.status === 'available';

  const handlePlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isAvailable) {
      navigate(`/${game.slug}`);
    }
  };

  const artType =
    game.slug === 'tic-tac-toe'
      ? 'tic-tac-toe'
      : game.slug === 'block-puzzle'
      ? 'block-puzzle'
      : 'fruit-crash';

  return (
    <div
      onClick={() => isAvailable && navigate(`/${game.slug}`)}
      className={`group relative flex flex-col rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-purple-500/40 shadow-lg shadow-black/40 overflow-hidden transition-all duration-200 ${
        isAvailable ? 'cursor-pointer hover:-translate-y-1 hover:shadow-purple-500/10' : 'opacity-90'
      }`}
    >
      {/* Thumbnail Artwork Header */}
      <div className="relative w-full aspect-[16/10] bg-slate-950 overflow-hidden">
        <OriginalGameArt
          type={artType}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />

        {/* Gradient Overlay for Title Legibility */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-black/20" />

        {/* Top Badges */}
        <div className="absolute top-2.5 left-2.5 right-2.5 flex items-center justify-between pointer-events-none">
          <Badge
            variant={isAvailable ? 'available' : 'coming_soon'}
            className="shadow-md backdrop-blur-md"
          >
            {isAvailable ? '● Available' : '⏳ Coming Soon'}
          </Badge>

          {game.rewardsEnabled && (
            <Badge variant="points" className="shadow-md backdrop-blur-md">
              <Sparkles className="w-3 h-3 text-yellow-300" />
              <span>+{game.pointsReward} pts</span>
            </Badge>
          )}
        </div>

        {/* Floating Quick Play Overlay on Hover (Desktop) */}
        {isAvailable && (
          <div className="hidden sm:flex absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 items-center justify-center transition-opacity backdrop-blur-[2px]">
            <span className="w-12 h-12 rounded-full bg-purple-600 text-white flex items-center justify-center shadow-lg shadow-purple-600/50 scale-90 group-hover:scale-100 transition-transform">
              <Play className="w-6 h-6 fill-white ml-0.5" />
            </span>
          </div>
        )}
      </div>

      {/* Card Content */}
      <div className="flex-1 flex flex-col p-3.5 sm:p-4 justify-between space-y-3">
        <div>
          {/* Metadata Row: Category & Rating */}
          <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
            <span className="uppercase tracking-wider font-semibold text-purple-400">
              {game.category}
            </span>
            <div className="flex items-center gap-1 text-amber-400 font-semibold">
              <Star className="w-3 h-3 fill-amber-400" />
              <span>{game.rating.toFixed(1)}</span>
            </div>
          </div>

          {/* Title */}
          <h3 className="font-bold text-base sm:text-lg text-white group-hover:text-purple-300 transition-colors line-clamp-1">
            {game.title}
          </h3>

          {/* Description */}
          <p className="text-xs text-slate-400 line-clamp-2 mt-1 leading-relaxed">
            {game.description}
          </p>
        </div>

        {/* Bottom Bar: Player count & Play Button */}
        <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 text-xs text-slate-400 font-medium">
            <Users className="w-3.5 h-3.5 text-slate-500" />
            <span className="truncate max-w-[100px]">{game.playersCount}</span>
          </div>

          <Button
            size="sm"
            variant={isAvailable ? 'primary' : 'secondary'}
            disabled={!isAvailable}
            onClick={handlePlay}
            leftIcon={isAvailable ? <Play className="w-3.5 h-3.5 fill-current" /> : <Clock className="w-3.5 h-3.5" />}
            className="text-xs px-3 font-semibold"
          >
            {isAvailable ? 'Play Now' : 'Coming Soon'}
          </Button>
        </div>
      </div>
    </div>
  );
};
