import { describe, it, expect } from 'vitest';
import {
  createEmptyGrid,
  canPlacePiece,
  placePiece,
  checkAndClearLines,
  hasValidMovesRemaining,
  SHAPES,
  GRID_SIZE,
} from '../game-logic/block-puzzle';

describe('Block Puzzle Game Logic', () => {
  it('creates an empty 8x8 grid', () => {
    const grid = createEmptyGrid();
    expect(grid.length).toBe(GRID_SIZE);
    expect(grid[0].length).toBe(GRID_SIZE);
    expect(grid.every((row) => row.every((cell) => cell === null))).toBe(true);
  });

  it('allows valid placement within bounds', () => {
    const grid = createEmptyGrid();
    const square2x2 = SHAPES.find((s) => s.id === 'sq_2')!;
    expect(canPlacePiece(grid, square2x2, 0, 0)).toBe(true);
    expect(canPlacePiece(grid, square2x2, 6, 6)).toBe(true);
  });

  it('rejects placement that overflows bounds', () => {
    const grid = createEmptyGrid();
    const square2x2 = SHAPES.find((s) => s.id === 'sq_2')!;
    // Row 7 + 2 = 9 > 8
    expect(canPlacePiece(grid, square2x2, 7, 0)).toBe(false);
    expect(canPlacePiece(grid, square2x2, 0, 7)).toBe(false);
  });

  it('rejects placement overlapping occupied cells', () => {
    let grid = createEmptyGrid();
    const dot = SHAPES.find((s) => s.id === 'dot_1')!;
    grid = placePiece(grid, dot, 2, 2);
    expect(grid[2][2]).toBe(dot.color);

    const square2x2 = SHAPES.find((s) => s.id === 'sq_2')!;
    expect(canPlacePiece(grid, square2x2, 1, 1)).toBe(false); // overlaps (2,2)
    expect(canPlacePiece(grid, square2x2, 2, 2)).toBe(false);
  });

  it('clears completed horizontal row and awards score', () => {
    let grid = createEmptyGrid();
    // Fill row 3 completely except cell 7
    for (let c = 0; c < 7; c++) {
      grid[3][c] = '#10b981';
    }
    const dot = SHAPES.find((s) => s.id === 'dot_1')!;
    grid = placePiece(grid, dot, 3, 7);

    const result = checkAndClearLines(grid, 0);
    expect(result.linesCleared).toBe(1);
    expect(result.clearedRows).toEqual([3]);
    expect(result.pointsEarned).toBe(100);
    // Row 3 should now be empty (null)
    expect(result.newGrid[3].every((c) => c === null)).toBe(true);
  });

  it('clears completed vertical column and cross-intersection simultaneously', () => {
    let grid = createEmptyGrid();
    // Fill entire row 0 and entire col 0
    for (let i = 0; i < GRID_SIZE; i++) {
      grid[0][i] = '#3b82f6';
      grid[i][0] = '#3b82f6';
    }

    const result = checkAndClearLines(grid, 0);
    expect(result.linesCleared).toBe(2);
    expect(result.clearedRows).toContain(0);
    expect(result.clearedCols).toContain(0);
    expect(result.comboMultiplier).toBe(2);
    expect(result.pointsEarned).toBe(400); // 2 lines * 100 * 2 combo = 400
  });

  it('detects game over when no pieces can fit', () => {
    // Fill entire grid except one cell (0, 0)
    let grid = createEmptyGrid();
    for (let r = 0; r < GRID_SIZE; r++) {
      for (let c = 0; c < GRID_SIZE; c++) {
        grid[r][c] = '#8b5cf6';
      }
    }
    grid[0][0] = null; // single empty cell

    const square3x3 = SHAPES.find((s) => s.id === 'sq_3')!;
    const bigPieceBatch = [square3x3];

    // Square 3x3 cannot fit into 1 single cell -> Game Over!
    expect(hasValidMovesRemaining(grid, bigPieceBatch)).toBe(false);

    // But a Dot 1x1 can fit!
    const dot = SHAPES.find((s) => s.id === 'dot_1')!;
    expect(hasValidMovesRemaining(grid, [dot])).toBe(true);
  });
});
