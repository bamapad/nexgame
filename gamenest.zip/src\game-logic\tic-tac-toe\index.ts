export type Player = 'X' | 'O';
export type CellValue = Player | null;
export type BoardState = CellValue[]; // 9 cells, indexed 0-8
export type Difficulty = 'easy' | 'hard' | 'extreme';

export interface GameResult {
  winner: Player | 'draw' | null;
  winningLine: number[] | null;
}

export const WINNING_COMBOS = [
  [0, 1, 2], // rows
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6], // columns
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8], // diagonals
  [2, 4, 6],
];

/**
 * Checks board state and returns winner & winning line indices
 */
export function checkWinner(board: BoardState): GameResult {
  for (const combo of WINNING_COMBOS) {
    const [a, b, c] = combo;
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return { winner: board[a], winningLine: combo };
    }
  }

  const isFull = board.every((cell) => cell !== null);
  if (isFull) {
    return { winner: 'draw', winningLine: null };
  }

  return { winner: null, winningLine: null };
}

/**
 * Returns list of empty cell indices (0-8)
 */
export function getAvailableMoves(board: BoardState): number[] {
  const moves: number[] = [];
  for (let i = 0; i < board.length; i++) {
    if (board[i] === null) {
      moves.push(i);
    }
  }
  return moves;
}

/**
 * Easy AI: Random with occasional awareness (makes mistakes)
 */
export function getEasyMove(board: BoardState, aiPlayer: Player): number {
  const empty = getAvailableMoves(board);
  if (empty.length === 0) return -1;

  // 30% chance to notice a winning move
  if (Math.random() < 0.3) {
    for (const idx of empty) {
      const copy = [...board];
      copy[idx] = aiPlayer;
      if (checkWinner(copy).winner === aiPlayer) {
        return idx;
      }
    }
  }

  // Otherwise pick random available cell
  return empty[Math.floor(Math.random() * empty.length)];
}

/**
 * Hard AI: Tactical (win, block, center, corners, forks)
 */
export function getHardMove(board: BoardState, aiPlayer: Player): number {
  const humanPlayer: Player = aiPlayer === 'X' ? 'O' : 'X';
  const empty = getAvailableMoves(board);
  if (empty.length === 0) return -1;

  // 1. Can AI win immediately?
  for (const idx of empty) {
    const copy = [...board];
    copy[idx] = aiPlayer;
    if (checkWinner(copy).winner === aiPlayer) return idx;
  }

  // 2. Can human win immediately? Block them!
  for (const idx of empty) {
    const copy = [...board];
    copy[idx] = humanPlayer;
    if (checkWinner(copy).winner === humanPlayer) return idx;
  }

  // 3. Take Center if available (cell 4)
  if (board[4] === null) return 4;

  // 4. Take opposite corner or any corner
  const corners = [0, 2, 6, 8].filter((c) => board[c] === null);
  if (corners.length > 0) {
    return corners[Math.floor(Math.random() * corners.length)];
  }

  // 5. Take any remaining edge
  return empty[Math.floor(Math.random() * empty.length)];
}

/**
 * Extreme AI: Minimax algorithm (Provably Unbeatable)
 * Evaluates the full game tree. The robot will never lose.
 */
export function getMinimaxMove(board: BoardState, aiPlayer: Player): number {
  const humanPlayer: Player = aiPlayer === 'X' ? 'O' : 'X';
  const empty = getAvailableMoves(board);
  if (empty.length === 0) return -1;

  // If first move on empty board, center or corner is optimal and faster
  if (empty.length === 9) {
    return 4; // Center
  }

  let bestScore = -Infinity;
  let bestMove = empty[0];

  for (const move of empty) {
    const copy = [...board];
    copy[move] = aiPlayer;
    const score = minimax(copy, 0, false, aiPlayer, humanPlayer);
    if (score > bestScore) {
      bestScore = score;
      bestMove = move;
    }
  }

  return bestMove;
}

function minimax(
  board: BoardState,
  depth: number,
  isMaximizing: boolean,
  aiPlayer: Player,
  humanPlayer: Player
): number {
  const result = checkWinner(board);

  if (result.winner === aiPlayer) {
    return 10 - depth;
  }
  if (result.winner === humanPlayer) {
    return depth - 10;
  }
  if (result.winner === 'draw') {
    return 0;
  }

  const empty = getAvailableMoves(board);

  if (isMaximizing) {
    let maxEval = -Infinity;
    for (const move of empty) {
      board[move] = aiPlayer;
      const evaluation = minimax(board, depth + 1, false, aiPlayer, humanPlayer);
      board[move] = null;
      maxEval = Math.max(maxEval, evaluation);
    }
    return maxEval;
  } else {
    let minEval = Infinity;
    for (const move of empty) {
      board[move] = humanPlayer;
      const evaluation = minimax(board, depth + 1, true, aiPlayer, humanPlayer);
      board[move] = null;
      minEval = Math.min(minEval, evaluation);
    }
    return minEval;
  }
}

/**
 * Universal move selector based on chosen difficulty
 */
export function getAIMove(board: BoardState, aiPlayer: Player, difficulty: Difficulty): number {
  switch (difficulty) {
    case 'easy':
      return getEasyMove(board, aiPlayer);
    case 'hard':
      return getHardMove(board, aiPlayer);
    case 'extreme':
      return getMinimaxMove(board, aiPlayer);
  }
}
