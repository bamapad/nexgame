import React from 'react';
import { Shield, Lock, Eye, CheckCircle2 } from 'lucide-react';

export const Privacy: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-fade-in text-slate-300">
      {/* Header */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-purple-950/40 to-slate-900 border border-slate-800 p-5 sm:p-6">
        <div className="flex items-center gap-2 text-purple-400 text-xs font-bold uppercase tracking-wider mb-1">
          <Shield className="w-4 h-4" />
          <span>Legal & Transparency</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-white">Privacy Policy</h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Last Updated: October 2026. How GameNest respects and safeguards your personal data.
        </p>
      </div>

      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-6 text-sm leading-relaxed">
        <section className="space-y-2">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Lock className="w-4 h-4 text-purple-400" />
            1. Information We Collect
          </h2>
          <p>
            GameNest collects minimal data required to provide gameplay and process reward redemptions:
          </p>
          <ul className="list-disc list-inside space-y-1 text-xs text-slate-400 pl-2">
            <li><strong>Account Data:</strong> Display name, email address, and avatar image.</li>
            <li><strong>Game Activity:</strong> Session timestamps, moves, scores, and won matches.</li>
            <li><strong>Redemption Data:</strong> When submitting a ₹100 withdrawal, you provide a mobile phone number and UPI ID. We do NOT collect credit/debit card numbers or bank account passwords.</li>
          </ul>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Eye className="w-4 h-4 text-purple-400" />
            2. How We Use Your Information
          </h2>
          <p>
            Your details are used exclusively for:
          </p>
          <ul className="list-disc list-inside space-y-1 text-xs text-slate-400 pl-2">
            <li>Operating the real-time multiplayer room synchronization.</li>
            <li>Validating active gameplay sessions and calculating points rewards.</li>
            <li>Verifying and disbursing approved reward payouts via UPI.</li>
            <li>Preventing fraudulent multi-accounting or automated botting.</li>
          </ul>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            3. Data Protection & Row Level Security (RLS)
          </h2>
          <p>
            All player data stored in our PostgreSQL database is fortified by strict Row Level Security (RLS) policies. Private withdrawal credentials are isolated in an encrypted table accessible only by authorized administrators. Other players can NEVER view your phone number or UPI ID.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-bold text-white">4. Contacting Us Regarding Privacy</h2>
          <p className="text-xs text-slate-400">
            For data inquiries, correction requests, or account deletion, please email our privacy compliance team at <span className="text-purple-400 font-mono">privacy@gamenest.test</span>.
          </p>
        </section>
      </div>
    </div>
  );
};
