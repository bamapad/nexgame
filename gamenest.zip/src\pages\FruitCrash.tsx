import React, { useRef, useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, RotateCcw, Pause, Play, Trophy, Sparkles, Heart, Volume2, VolumeX } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sounds } from '../lib/soundEffects';
import { useAuthStore } from '../stores/useAuthStore';
import { Button } from '../components/ui/Button';
import { Modal } from '../components/ui/Modal';

interface Fruit {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  rotation: number;
  vRot: number;
  type: 'watermelon' | 'strawberry' | 'orange' | 'banana' | 'bomb';
  color: string;
  sliced: boolean;
  sliceAngle?: number;
  halves?: {
    x1: number;
    y1: number;
    vx1: number;
    vy1: number;
    x2: number;
    y2: number;
    vx2: number;
    vy2: number;
  };
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  alpha: number;
}

interface TrailPoint {
  x: number;
  y: number;
  time: number;
}

const FRUIT_TYPES = [
  { type: 'watermelon', color: '#10b981', innerColor: '#ef4444', radius: 34, points: 10 },
  { type: 'strawberry', color: '#f43f5e', innerColor: '#ffe4e6', radius: 24, points: 15 },
  { type: 'orange', color: '#f97316', innerColor: '#ffedd5', radius: 28, points: 10 },
  { type: 'banana', color: '#eab308', innerColor: '#fef08a', radius: 26, points: 12 },
];

export const FruitCrash: React.FC = () => {
  const navigate = useNavigate();
  const { awardPoints, addPlaytime } = useAuthStore();
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const [score, setScore] = useState(0);
  const [bestScore, setBestScore] = useState(() => {
    return parseInt(localStorage.getItem('gamenest_fruit_best_score') || '0', 10);
  });
  const [lives, setLives] = useState(3);
  const [isGameOver, setIsGameOver] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [comboCount, setComboCount] = useState(0);
  const [comboToast, setComboToast] = useState<string | null>(null);
  const [isMuted, setIsMuted] = useState(sounds.getIsMuted());

  // Game references for smooth 60fps loop
  const fruitsRef = useRef<Fruit[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const trailRef = useRef<TrailPoint[]>([]);
  const isMouseDownRef = useRef(false);
  const animationFrameRef = useRef<number | null>(null);
  const spawnTimerRef = useRef(0);
  const comboWindowRef = useRef({ count: 0, timer: 0 });

  // Best score sync
  useEffect(() => {
    if (score > bestScore) {
      setBestScore(score);
      localStorage.setItem('gamenest_fruit_best_score', score.toString());
    }
  }, [score, bestScore]);

  // Playtime tracking
  useEffect(() => {
    const interval = setInterval(() => {
      if (document.visibilityState === 'visible' && !isGameOver && !isPaused) {
        addPlaytime(5);
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [isGameOver, isPaused, addPlaytime]);

  // Reset Game
  const resetGame = useCallback(() => {
    fruitsRef.current = [];
    particlesRef.current = [];
    trailRef.current = [];
    setScore(0);
    setLives(3);
    setIsGameOver(false);
    setIsPaused(false);
    setComboCount(0);
    setComboToast(null);
  }, []);

  // Spawn new fruit
  const spawnFruit = (width: number, height: number) => {
    const isBomb = Math.random() < 0.18; // 18% chance of bomb
    const x = width * 0.15 + Math.random() * (width * 0.7);
    const y = height + 30;

    // Upward velocity with arc towards center
    const targetX = width * 0.5 + (Math.random() - 0.5) * (width * 0.4);
    const vx = (targetX - x) * 0.015;
    const vy = -(height * 0.018 + Math.random() * 4); // Upward impulse

    if (isBomb) {
      fruitsRef.current.push({
        id: Date.now() + Math.random(),
        x,
        y,
        vx,
        vy,
        radius: 28,
        rotation: 0,
        vRot: (Math.random() - 0.5) * 0.1,
        type: 'bomb',
        color: '#1e293b',
        sliced: false,
      });
    } else {
      const template = FRUIT_TYPES[Math.floor(Math.random() * FRUIT_TYPES.length)];
      fruitsRef.current.push({
        id: Date.now() + Math.random(),
        x,
        y,
        vx,
        vy,
        radius: template.radius,
        rotation: 0,
        vRot: (Math.random() - 0.5) * 0.08,
        type: template.type as any,
        color: template.color,
        sliced: false,
      });
    }
  };

  // Create fruit splatter particles
  const createJuiceParticles = (x: number, y: number, color: string) => {
    for (let i = 0; i < 16; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 2 + Math.random() * 6;
      particlesRef.current.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        color,
        size: 3 + Math.random() * 5,
        alpha: 1,
      });
    }
  };

  // Slice intersection test (line segment to circle)
  const checkSlice = (p1: TrailPoint, p2: TrailPoint) => {
    let slicedInSwipe = 0;

    fruitsRef.current.forEach((fruit) => {
      if (fruit.sliced) return;

      // Distance from circle center to line segment p1-p2
      const dx = p2.x - p1.x;
      const dy = p2.y - p1.y;
      const lenSq = dx * dx + dy * dy;

      if (lenSq === 0) return;

      let t = ((fruit.x - p1.x) * dx + (fruit.y - p1.y) * dy) / lenSq;
      t = Math.max(0, Math.min(1, t));

      const closestX = p1.x + t * dx;
      const closestY = p1.y + t * dy;

      const distSq = (fruit.x - closestX) * (fruit.x - closestX) + (fruit.y - closestY) * (fruit.y - closestY);

      if (distSq <= fruit.radius * fruit.radius) {
        // HIT!
        fruit.sliced = true;
        slicedInSwipe++;

        if (fruit.type === 'bomb') {
          sounds.playBombExplode();
          createJuiceParticles(fruit.x, fruit.y, '#f59e0b');
          setLives((prev) => {
            const next = prev - 1;
            if (next <= 0) {
              setIsGameOver(true);
            }
            return Math.max(0, next);
          });
        } else {
          sounds.playFruitSlice();
          createJuiceParticles(fruit.x, fruit.y, fruit.color);

          // Split halves physics
          const sliceAngle = Math.atan2(dy, dx);
          fruit.sliceAngle = sliceAngle;
          fruit.halves = {
            x1: fruit.x - Math.sin(sliceAngle) * 8,
            y1: fruit.y + Math.cos(sliceAngle) * 8,
            vx1: fruit.vx - Math.sin(sliceAngle) * 3,
            vy1: fruit.vy - 1,
            x2: fruit.x + Math.sin(sliceAngle) * 8,
            y2: fruit.y - Math.cos(sliceAngle) * 8,
            vx2: fruit.vx + Math.sin(sliceAngle) * 3,
            vy2: fruit.vy - 1,
          };

          setScore((prev) => prev + 10);
        }
      }
    });

    if (slicedInSwipe > 0) {
      comboWindowRef.current.count += slicedInSwipe;
      comboWindowRef.current.timer = 15; // frames to accumulate combo

      if (comboWindowRef.current.count >= 3) {
        const comboBonus = comboWindowRef.current.count * 5;
        setScore((prev) => prev + comboBonus);
        setComboCount(comboWindowRef.current.count);
        setComboToast(`🔥 ${comboWindowRef.current.count}x COMBO BLADE! (+${comboBonus} pts)`);
        sounds.playComboBlast(comboWindowRef.current.count);

        awardPoints(3, `Sliced ${comboWindowRef.current.count}x Fruit Combo!`);

        try {
          confetti({
            particleCount: 25,
            spread: 50,
            origin: { y: 0.5 },
          });
        } catch (e) {}

        setTimeout(() => setComboToast(null), 1500);
      }
    }
  };

  // Main 60 FPS Render & Physics Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = (canvas.width = canvas.parentElement?.clientWidth || 400);
    let height = (canvas.height = canvas.parentElement?.clientHeight || 500);

    const handleResize = () => {
      if (!canvas.parentElement) return;
      width = canvas.width = canvas.parentElement.clientWidth;
      height = canvas.height = canvas.parentElement.clientHeight;
    };
    window.addEventListener('resize', handleResize);

    const GRAVITY = 0.28;

    const gameLoop = () => {
      if (!isPaused && !isGameOver) {
        ctx.clearRect(0, 0, width, height);

        // 1. Spawning
        spawnTimerRef.current++;
        if (spawnTimerRef.current % 45 === 0) {
          spawnFruit(width, height);
          if (Math.random() < 0.4) spawnFruit(width, height); // Double spawn
        }

        // Combo window countdown
        if (comboWindowRef.current.timer > 0) {
          comboWindowRef.current.timer--;
          if (comboWindowRef.current.timer === 0) {
            comboWindowRef.current.count = 0;
          }
        }

        // 2. Update & Draw Particles
        for (let i = particlesRef.current.length - 1; i >= 0; i--) {
          const p = particlesRef.current[i];
          p.x += p.vx;
          p.y += p.vy;
          p.vy += 0.2; // particle gravity
          p.alpha -= 0.025;

          if (p.alpha <= 0) {
            particlesRef.current.splice(i, 1);
            continue;
          }

          ctx.save();
          ctx.globalAlpha = p.alpha;
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }

        // 3. Update & Draw Fruits
        for (let i = fruitsRef.current.length - 1; i >= 0; i--) {
          const fruit = fruitsRef.current[i];

          if (!fruit.sliced) {
            // Whole flying fruit
            fruit.x += fruit.vx;
            fruit.y += fruit.vy;
            fruit.vy += GRAVITY;
            fruit.rotation += fruit.vRot;

            // Missed fruit check (dropped off bottom screen)
            if (fruit.y > height + 50 && fruit.vy > 0) {
              if (fruit.type !== 'bomb') {
                setLives((prev) => {
                  const next = prev - 1;
                  if (next <= 0) setIsGameOver(true);
                  return Math.max(0, next);
                });
              }
              fruitsRef.current.splice(i, 1);
              continue;
            }

            // Draw Fruit
            ctx.save();
            ctx.translate(fruit.x, fruit.y);
            ctx.rotate(fruit.rotation);

            if (fruit.type === 'bomb') {
              // Draw Bomb
              ctx.fillStyle = '#0f172a';
              ctx.beginPath();
              ctx.arc(0, 0, fruit.radius, 0, Math.PI * 2);
              ctx.fill();
              ctx.strokeStyle = '#ef4444';
              ctx.lineWidth = 3;
              ctx.stroke();

              // Fuse
              ctx.strokeStyle = '#f59e0b';
              ctx.lineWidth = 2.5;
              ctx.beginPath();
              ctx.moveTo(0, -fruit.radius);
              ctx.quadraticCurveTo(8, -fruit.radius - 10, 12, -fruit.radius - 12);
              ctx.stroke();

              // Spark
              ctx.fillStyle = Math.random() < 0.5 ? '#f59e0b' : '#ef4444';
              ctx.beginPath();
              ctx.arc(12, -fruit.radius - 12, 3.5, 0, Math.PI * 2);
              ctx.fill();
            } else {
              // Draw Colorful Fruit
              ctx.fillStyle = fruit.color;
              ctx.beginPath();
              ctx.arc(0, 0, fruit.radius, 0, Math.PI * 2);
              ctx.fill();

              // Fruit Highlight / Shine
              ctx.fillStyle = 'rgba(255, 255, 255, 0.35)';
              ctx.beginPath();
              ctx.arc(-fruit.radius * 0.3, -fruit.radius * 0.3, fruit.radius * 0.35, 0, Math.PI * 2);
              ctx.fill();
            }
            ctx.restore();
          } else if (fruit.halves) {
            // Sliced Halves flying apart
            fruit.halves.x1 += fruit.halves.vx1;
            fruit.halves.y1 += fruit.halves.vy1;
            fruit.halves.vy1 += GRAVITY * 1.2;

            fruit.halves.x2 += fruit.halves.vx2;
            fruit.halves.y2 += fruit.halves.vy2;
            fruit.halves.vy2 += GRAVITY * 1.2;

            // Half 1
            ctx.save();
            ctx.translate(fruit.halves.x1, fruit.halves.y1);
            ctx.rotate(fruit.sliceAngle || 0);
            ctx.fillStyle = fruit.color;
            ctx.beginPath();
            ctx.arc(0, 0, fruit.radius * 0.9, 0, Math.PI);
            ctx.fill();
            ctx.restore();

            // Half 2
            ctx.save();
            ctx.translate(fruit.halves.x2, fruit.halves.y2);
            ctx.rotate((fruit.sliceAngle || 0) + Math.PI);
            ctx.fillStyle = fruit.color;
            ctx.beginPath();
            ctx.arc(0, 0, fruit.radius * 0.9, 0, Math.PI);
            ctx.fill();
            ctx.restore();

            // Remove if off screen
            if (fruit.halves.y1 > height + 80 && fruit.halves.y2 > height + 80) {
              fruitsRef.current.splice(i, 1);
            }
          }
        }

        // 4. Draw Neon Blade Trail
        const now = Date.now();
        trailRef.current = trailRef.current.filter((pt) => now - pt.time < 180);

        if (trailRef.current.length >= 2) {
          ctx.save();
          ctx.strokeStyle = '#00f0ff';
          ctx.shadowColor = '#00d2ff';
          ctx.shadowBlur = 12;
          ctx.lineCap = 'round';
          ctx.lineJoin = 'round';

          for (let i = 1; i < trailRef.current.length; i++) {
            const p1 = trailRef.current[i - 1];
            const p2 = trailRef.current[i];
            const age = now - p2.time;
            const widthScale = Math.max(1, (1 - age / 180) * 8);

            ctx.lineWidth = widthScale;
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();

            // Test slice intersection
            checkSlice(p1, p2);
          }
          ctx.restore();
        }
      }

      animationFrameRef.current = requestAnimationFrame(gameLoop);
    };

    animationFrameRef.current = requestAnimationFrame(gameLoop);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isPaused, isGameOver]);

  // Touch and Mouse handlers for fast, responsive slicing
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    isMouseDownRef.current = true;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    trailRef.current = [{ x, y, time: Date.now() }];
    sounds.playBladeSwipe();
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isMouseDownRef.current) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    trailRef.current.push({ x, y, time: Date.now() });
    if (trailRef.current.length % 5 === 0) {
      sounds.playBladeSwipe();
    }
  };

  const handlePointerUp = () => {
    isMouseDownRef.current = false;
  };

  return (
    <div className="max-w-xl mx-auto space-y-4 animate-fade-in no-select">
      {/* Header Controls */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => navigate('/games')}
          className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Games</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              const next = !isMuted;
              sounds.setMuted(next);
              setIsMuted(next);
            }}
            className={`p-2 rounded-xl border transition-colors ${
              isMuted
                ? 'bg-rose-950/40 border-rose-500/40 text-rose-300'
                : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white'
            }`}
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
          <button
            onClick={() => setIsPaused((prev) => !prev)}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
          >
            {isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
          </button>
          <button
            onClick={resetGame}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Score, Best & Lives Status */}
      <div className="grid grid-cols-3 gap-2 rounded-2xl bg-gradient-to-r from-slate-900 via-purple-950/40 to-slate-900 border border-slate-800 p-3 sm:p-4 text-center">
        <div>
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">SCORE</span>
          <span className="text-xl sm:text-2xl font-black text-white">{score}</span>
        </div>

        <div>
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">BEST</span>
          <span className="text-xl sm:text-2xl font-black text-amber-400 flex items-center justify-center gap-1">
            <Trophy className="w-4 h-4" />
            {bestScore}
          </span>
        </div>

        <div>
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">LIVES</span>
          <div className="flex items-center justify-center gap-1 mt-1">
            {[1, 2, 3].map((heart) => (
              <Heart
                key={heart}
                className={`w-5 h-5 transition-transform ${
                  heart <= lives ? 'text-rose-500 fill-rose-500 scale-100' : 'text-slate-700 scale-90'
                }`}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Floating Combo Toast */}
      {comboToast && (
        <div className="bg-gradient-to-r from-orange-500 to-rose-600 text-white font-black text-xs sm:text-sm text-center py-2 px-4 rounded-full shadow-lg shadow-orange-500/40 animate-combo-pop border border-orange-400/30">
          {comboToast}
        </div>
      )}

      {/* 60 FPS Interactive HTML5 Canvas Container */}
      <div className="relative w-full aspect-[4/5] sm:aspect-square max-h-[500px] rounded-3xl bg-slate-950 border-2 border-slate-800 shadow-2xl overflow-hidden cursor-crosshair touch-none">
        <canvas
          ref={canvasRef}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          className="w-full h-full block"
        />

        {/* Swipe instruction overlay */}
        {score === 0 && (
          <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center text-center p-4">
            <span className="text-2xl animate-bounce">⚔️</span>
            <p className="text-xs font-bold text-cyan-400 mt-2 uppercase tracking-widest drop-shadow">
              Swipe across fruits to slice!
            </p>
            <p className="text-[10px] text-rose-400 mt-0.5 font-semibold drop-shadow">
              Avoid bombs (💣) & don't drop fruits!
            </p>
          </div>
        )}
      </div>

      {/* Pause Modal */}
      <Modal isOpen={isPaused} onClose={() => setIsPaused(false)} title="Game Paused">
        <div className="space-y-4 text-center">
          <p className="text-sm text-slate-400">Current Score: {score}</p>
          <div className="flex items-center justify-center gap-3">
            <Button variant="electric" size="md" onClick={() => setIsPaused(false)} leftIcon={<Play className="w-4 h-4" />}>
              Resume
            </Button>
            <Button variant="secondary" size="md" onClick={resetGame} leftIcon={<RotateCcw className="w-4 h-4" />}>
              Restart
            </Button>
          </div>
        </div>
      </Modal>

      {/* Game Over Modal */}
      <Modal isOpen={isGameOver} onClose={resetGame} title="Game Over!">
        <div className="space-y-4 text-center">
          <div className="w-14 h-14 rounded-full bg-rose-500/20 text-rose-400 mx-auto flex items-center justify-center text-2xl border border-rose-500/40">
            🍉
          </div>
          <div>
            <h3 className="text-2xl font-black text-white">Sliced!</h3>
            <p className="text-sm text-slate-400 mt-1">
              Final Score: <strong className="text-white">{score}</strong>
            </p>
            {score >= bestScore && score > 0 && (
              <p className="text-xs text-amber-400 font-bold mt-1 flex items-center justify-center gap-1">
                <Sparkles className="w-3.5 h-3.5" /> New High Score!
              </p>
            )}
          </div>

          <div className="flex items-center justify-center gap-3 pt-2">
            <Button variant="primary" size="md" onClick={resetGame} leftIcon={<RotateCcw className="w-4 h-4" />}>
              Play Again
            </Button>
            <Button variant="secondary" size="md" onClick={() => navigate('/games')}>
              All Games
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
