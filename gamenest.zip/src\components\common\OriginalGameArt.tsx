import React from 'react';

interface GameArtProps {
  type: 'tic-tac-toe' | 'block-puzzle' | 'fruit-crash';
  className?: string;
}

export const OriginalGameArt: React.FC<GameArtProps> = ({ type, className = 'w-full h-full' }) => {
  if (type === 'tic-tac-toe') {
    return (
      <svg
        viewBox="0 0 300 200"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={className}
        preserveAspectRatio="xMidYMid slice"
      >
        <defs>
          <linearGradient id="ttt-bg" x1="0" y1="0" x2="300" y2="200" gradientUnits="userSpaceOnUse">
            <stop stopColor="#0f172a" />
            <stop offset="1" stopColor="#1e1b4b" />
          </linearGradient>
          <linearGradient id="neon-x" x1="0" y1="0" x2="1" y2="1">
            <stop stopColor="#a855f7" />
            <stop offset="1" stopColor="#ec4899" />
          </linearGradient>
          <linearGradient id="neon-o" x1="0" y1="0" x2="1" y2="1">
            <stop stopColor="#00d2ff" />
            <stop offset="1" stopColor="#3b82f6" />
          </linearGradient>
          <filter id="glow-x" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="4" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
          <filter id="glow-o" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="4" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>
        <rect width="300" height="200" fill="url(#ttt-bg)" />

        {/* 3x3 Grid Lines */}
        <line x1="120" y1="30" x2="120" y2="170" stroke="#334155" strokeWidth="4" strokeLinecap="round" />
        <line x1="180" y1="30" x2="180" y2="170" stroke="#334155" strokeWidth="4" strokeLinecap="round" />
        <line x1="60" y1="75" x2="240" y2="75" stroke="#334155" strokeWidth="4" strokeLinecap="round" />
        <line x1="60" y1="125" x2="240" y2="125" stroke="#334155" strokeWidth="4" strokeLinecap="round" />

        {/* Glowing X in top-left */}
        <g filter="url(#glow-x)">
          <line x1="75" y1="42" x2="105" y2="68" stroke="url(#neon-x)" strokeWidth="6" strokeLinecap="round" />
          <line x1="105" y1="42" x2="75" y2="68" stroke="url(#neon-x)" strokeWidth="6" strokeLinecap="round" />
        </g>

        {/* Glowing O in center */}
        <circle cx="150" cy="100" r="16" stroke="url(#neon-o)" strokeWidth="6" fill="none" filter="url(#glow-o)" />

        {/* Glowing X in bottom-right */}
        <g filter="url(#glow-x)">
          <line x1="195" y1="138" x2="225" y2="162" stroke="url(#neon-x)" strokeWidth="6" strokeLinecap="round" />
          <line x1="225" y1="138" x2="195" y2="162" stroke="url(#neon-x)" strokeWidth="6" strokeLinecap="round" />
        </g>

        {/* Winning Strike Indicator */}
        <line x1="65" y1="35" x2="235" y2="168" stroke="#f43f5e" strokeWidth="3" strokeDasharray="6 4" opacity="0.6" />
      </svg>
    );
  }

  if (type === 'block-puzzle') {
    return (
      <svg
        viewBox="0 0 300 200"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={className}
        preserveAspectRatio="xMidYMid slice"
      >
        <defs>
          <linearGradient id="bp-bg" x1="0" y1="0" x2="300" y2="200" gradientUnits="userSpaceOnUse">
            <stop stopColor="#091124" />
            <stop offset="1" stopColor="#1e1035" />
          </linearGradient>
          <linearGradient id="tile-purple" x1="0" y1="0" x2="1" y2="1">
            <stop stopColor="#c084fc" />
            <stop offset="1" stopColor="#7e22ce" />
          </linearGradient>
          <linearGradient id="tile-cyan" x1="0" y1="0" x2="1" y2="1">
            <stop stopColor="#22d3ee" />
            <stop offset="1" stopColor="#0891b2" />
          </linearGradient>
          <linearGradient id="tile-amber" x1="0" y1="0" x2="1" y2="1">
            <stop stopColor="#fcd34d" />
            <stop offset="1" stopColor="#d97706" />
          </linearGradient>
          <linearGradient id="tile-emerald" x1="0" y1="0" x2="1" y2="1">
            <stop stopColor="#34d399" />
            <stop offset="1" stopColor="#059669" />
          </linearGradient>
          <filter id="tile-shadow" x="-10%" y="-10%" width="120%" height="120%">
            <feDropShadow dx="0" dy="2" stdDeviation="2" floodOpacity="0.5" />
          </filter>
        </defs>
        <rect width="300" height="200" fill="url(#bp-bg)" />

        {/* Grid Preview Tiles */}
        <g opacity="0.15">
          {Array.from({ length: 6 }).map((_, r) =>
            Array.from({ length: 9 }).map((__, c) => (
              <rect
                key={`${r}-${c}`}
                x={20 + c * 29}
                y={20 + r * 26}
                width="24"
                height="22"
                rx="4"
                stroke="#94a3b8"
                strokeWidth="1.5"
              />
            ))
          )}
        </g>

        {/* 2x2 Square Block */}
        <g filter="url(#tile-shadow)">
          <rect x="49" y="46" width="24" height="22" rx="4" fill="url(#tile-amber)" />
          <rect x="78" y="46" width="24" height="22" rx="4" fill="url(#tile-amber)" />
          <rect x="49" y="72" width="24" height="22" rx="4" fill="url(#tile-amber)" />
          <rect x="78" y="72" width="24" height="22" rx="4" fill="url(#tile-amber)" />
        </g>

        {/* L-Shape Polyomino */}
        <g filter="url(#tile-shadow)">
          <rect x="136" y="46" width="24" height="22" rx="4" fill="url(#tile-purple)" />
          <rect x="136" y="72" width="24" height="22" rx="4" fill="url(#tile-purple)" />
          <rect x="136" y="98" width="24" height="22" rx="4" fill="url(#tile-purple)" />
          <rect x="165" y="98" width="24" height="22" rx="4" fill="url(#tile-purple)" />
        </g>

        {/* T-Shape Polyomino */}
        <g filter="url(#tile-shadow)">
          <rect x="194" y="46" width="24" height="22" rx="4" fill="url(#tile-cyan)" />
          <rect x="223" y="46" width="24" height="22" rx="4" fill="url(#tile-cyan)" />
          <rect x="252" y="46" width="24" height="22" rx="4" fill="url(#tile-cyan)" />
          <rect x="223" y="72" width="24" height="22" rx="4" fill="url(#tile-cyan)" />
        </g>

        {/* Line Blast Particle Sparks */}
        <circle cx="100" cy="150" r="3" fill="#38bdf8" />
        <circle cx="180" cy="140" r="4" fill="#f43f5e" />
        <circle cx="210" cy="160" r="2.5" fill="#fbbf24" />
        <circle cx="240" cy="130" r="3.5" fill="#a855f7" />

        {/* Combo Blast Text Banner */}
        <rect x="90" y="145" width="120" height="28" rx="14" fill="#7c3aed" opacity="0.85" />
        <text x="150" y="163" fill="#ffffff" fontSize="11" fontWeight="bold" textAnchor="middle" letterSpacing="1">
          COMBO BLAST!
        </text>
      </svg>
    );
  }

  // Fruit Crash (Phase 6 Preview Artwork)
  return (
    <svg
      viewBox="0 0 300 200"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      preserveAspectRatio="xMidYMid slice"
    >
      <defs>
        <linearGradient id="fc-bg" x1="0" y1="0" x2="300" y2="200" gradientUnits="userSpaceOnUse">
          <stop stopColor="#0c1917" />
          <stop offset="1" stopColor="#1e293b" />
        </linearGradient>
        <linearGradient id="berry" x1="0" y1="0" x2="1" y2="1">
          <stop stopColor="#ff4b72" />
          <stop offset="1" stopColor="#d90429" />
        </linearGradient>
        <linearGradient id="orange" x1="0" y1="0" x2="1" y2="1">
          <stop stopColor="#ff9f1c" />
          <stop offset="1" stopColor="#f77f00" />
        </linearGradient>
        <linearGradient id="lemon" x1="0" y1="0" x2="1" y2="1">
          <stop stopColor="#ffe600" />
          <stop offset="1" stopColor="#ffb703" />
        </linearGradient>
        <linearGradient id="lime" x1="0" y1="0" x2="1" y2="1">
          <stop stopColor="#2ec4b6" />
          <stop offset="1" stopColor="#06d6a0" />
        </linearGradient>
      </defs>
      <rect width="300" height="200" fill="url(#fc-bg)" />

      {/* Floating Fruit Elements */}
      {/* Strawberry */}
      <g transform="translate(60, 60)">
        <path d="M20 5 C30 5, 38 15, 36 28 C34 40, 20 48, 20 48 C20 48, 6 40, 4 28 C2 15, 10 5, 20 5 Z" fill="url(#berry)" />
        <path d="M14 6 C17 3, 23 3, 26 6 C28 2, 33 4, 30 9 C25 8, 22 9, 20 12 C18 9, 15 8, 10 9 C7 4, 12 2, 14 6 Z" fill="#22c55e" />
        <circle cx="16" cy="22" r="1.5" fill="#fef08a" />
        <circle cx="24" cy="24" r="1.5" fill="#fef08a" />
        <circle cx="20" cy="32" r="1.5" fill="#fef08a" />
      </g>

      {/* Orange Slice */}
      <g transform="translate(130, 50)">
        <circle cx="30" cy="30" r="28" fill="url(#orange)" />
        <circle cx="30" cy="30" r="22" fill="#fff7ed" />
        <circle cx="30" cy="30" r="18" fill="url(#orange)" />
        <line x1="30" y1="12" x2="30" y2="48" stroke="#fff7ed" strokeWidth="2" />
        <line x1="12" y1="30" x2="48" y2="30" stroke="#fff7ed" strokeWidth="2" />
        <line x1="17" y1="17" x2="43" y2="43" stroke="#fff7ed" strokeWidth="2" />
        <line x1="17" y1="43" x2="43" y2="17" stroke="#fff7ed" strokeWidth="2" />
      </g>

      {/* Watermelon Wedge */}
      <g transform="translate(205, 65)">
        <path d="M5 10 A35 35 0 0 0 55 50 L5 10 Z" fill="#10b981" />
        <path d="M8 12 A32 32 0 0 0 52 46 L8 12 Z" fill="#ffffff" />
        <path d="M12 15 A28 28 0 0 0 48 42 L12 15 Z" fill="url(#berry)" />
        <circle cx="24" cy="25" r="1.5" fill="#0f172a" />
        <circle cx="32" cy="31" r="1.5" fill="#0f172a" />
        <circle cx="28" cy="20" r="1.5" fill="#0f172a" />
      </g>

      {/* Splash Droplets */}
      <circle cx="120" cy="140" r="4" fill="#00f0ff" opacity="0.7" />
      <circle cx="175" cy="145" r="5" fill="#ff007f" opacity="0.7" />
      <circle cx="200" cy="130" r="3" fill="#ffe600" opacity="0.8" />

      {/* Ribbon */}
      <rect x="70" y="145" width="160" height="28" rx="8" fill="#1e293b" stroke="#334155" strokeWidth="1" />
      <text x="150" y="163" fill="#38bdf8" fontSize="11" fontWeight="bold" textAnchor="middle" letterSpacing="2">
        CRASH & COMBOS
      </text>
    </svg>
  );
};
