import { supabase, isSupabaseConfigured } from './supabase';
import { BoardState, Player, checkWinner } from '../game-logic/tic-tac-toe';

export interface RemoteRoom {
  id: string;
  roomCode: string;
  hostId: string;
  guestId: string | null;
  currentTurn: Player;
  boardState: BoardState;
  status: 'waiting' | 'in_progress' | 'completed' | 'abandoned';
  winner: Player | 'draw' | null;
}

/**
 * Creates a new multiplayer room in Supabase
 */
export async function createMultiplayerRoom(hostId: string): Promise<RemoteRoom | null> {
  if (!isSupabaseConfigured || !supabase) return null;

  // Generate 6-char code
  const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
  let roomCode = '';
  for (let i = 0; i < 6; i++) {
    roomCode += chars.charAt(Math.floor(Math.random() * chars.length));
  }

  // Get Tic Tac Toe game ID
  const { data: gameData } = await supabase
    .from('games')
    .select('id')
    .eq('slug', 'tic-tac-toe')
    .single();

  if (!gameData) throw new Error('Game not found in database');

  const { data, error } = await supabase
    .from('multiplayer_rooms')
    .insert({
      room_code: roomCode,
      game_id: gameData.id,
      host_id: hostId,
      current_turn: 'X',
      board_state: Array(9).fill(null),
      status: 'waiting',
    })
    .select('*')
    .single();

  if (error || !data) throw error;

  return {
    id: data.id,
    roomCode: data.room_code,
    hostId: data.host_id,
    guestId: data.guest_id,
    currentTurn: data.current_turn as Player,
    boardState: data.board_state as BoardState,
    status: data.status,
    winner: data.winner === 'D' ? 'draw' : (data.winner as Player | null),
  };
}

/**
 * Joins an existing waiting room by code
 */
export async function joinMultiplayerRoom(guestId: string, roomCode: string): Promise<RemoteRoom | null> {
  if (!isSupabaseConfigured || !supabase) return null;

  const cleanCode = roomCode.trim().toUpperCase();

  // Find room
  const { data: room, error: fetchError } = await supabase
    .from('multiplayer_rooms')
    .select('*')
    .eq('room_code', cleanCode)
    .single();

  if (fetchError || !room) {
    throw new Error('Room code not found or has expired.');
  }

  if (room.status !== 'waiting') {
    throw new Error('This match has already started or completed.');
  }

  if (room.host_id === guestId) {
    return {
      id: room.id,
      roomCode: room.room_code,
      hostId: room.host_id,
      guestId: room.guest_id,
      currentTurn: room.current_turn as Player,
      boardState: room.board_state as BoardState,
      status: room.status,
      winner: room.winner === 'D' ? 'draw' : (room.winner as Player | null),
    };
  }

  // Assign guest and update status
  const { data: updated, error: updateError } = await supabase
    .from('multiplayer_rooms')
    .update({
      guest_id: guestId,
      status: 'in_progress',
    })
    .eq('id', room.id)
    .select('*')
    .single();

  if (updateError || !updated) throw updateError;

  return {
    id: updated.id,
    roomCode: updated.room_code,
    hostId: updated.host_id,
    guestId: updated.guest_id,
    currentTurn: updated.current_turn as Player,
    boardState: updated.board_state as BoardState,
    status: updated.status,
    winner: updated.winner === 'D' ? 'draw' : (updated.winner as Player | null),
  };
}

/**
 * Submits a validated move
 */
export async function submitMultiplayerMove(
  roomId: string,
  playerId: string,
  symbol: Player,
  cellIndex: number,
  currentBoard: BoardState
): Promise<RemoteRoom | null> {
  if (!isSupabaseConfigured || !supabase) return null;

  // Validate cell is empty
  if (currentBoard[cellIndex] !== null) {
    throw new Error('Cell is already occupied.');
  }

  const newBoard = [...currentBoard];
  newBoard[cellIndex] = symbol;

  const winResult = checkWinner(newBoard);
  const nextTurn: Player = symbol === 'X' ? 'O' : 'X';
  const newStatus = winResult.winner ? 'completed' : 'in_progress';
  const winnerValue = winResult.winner === 'draw' ? 'D' : winResult.winner;

  // Record move in game_moves table
  await supabase.from('game_moves').insert({
    room_id: roomId,
    player_id: playerId,
    move_number: newBoard.filter((c) => c !== null).length,
    symbol,
    cell_index: cellIndex,
  });

  // Update room
  const { data, error } = await supabase
    .from('multiplayer_rooms')
    .update({
      board_state: newBoard,
      current_turn: nextTurn,
      status: newStatus,
      winner: winnerValue,
    })
    .eq('id', roomId)
    .select('*')
    .single();

  if (error || !data) throw error;

  return {
    id: data.id,
    roomCode: data.room_code,
    hostId: data.host_id,
    guestId: data.guest_id,
    currentTurn: data.current_turn as Player,
    boardState: data.board_state as BoardState,
    status: data.status,
    winner: data.winner === 'D' ? 'draw' : (data.winner as Player | null),
  };
}

/**
 * Subscribes to live room updates via Supabase Realtime
 */
export function subscribeToRoom(roomId: string, onUpdate: (room: RemoteRoom) => void) {
  if (!isSupabaseConfigured || !supabase) return () => {};

  const channel = supabase
    .channel(`room:${roomId}`)
    .on(
      'postgres_changes',
      {
        event: 'UPDATE',
        schema: 'public',
        table: 'multiplayer_rooms',
        filter: `id=eq.${roomId}`,
      },
      (payload) => {
        const row = payload.new as any;
        onUpdate({
          id: row.id,
          roomCode: row.room_code,
          hostId: row.host_id,
          guestId: row.guest_id,
          currentTurn: row.current_turn as Player,
          boardState: row.board_state as BoardState,
          status: row.status,
          winner: row.winner === 'D' ? 'draw' : (row.winner as Player | null),
        });
      }
    )
    .subscribe();

  return () => {
    if (supabase) {
      supabase.removeChannel(channel);
    }
  };
}
